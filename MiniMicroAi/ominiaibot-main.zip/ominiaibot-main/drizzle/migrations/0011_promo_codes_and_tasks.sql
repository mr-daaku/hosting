CREATE TABLE public.promo_codes (code text PRIMARY KEY, reward_usdt numeric NOT NULL CHECK (reward_usdt > 0), max_uses int NOT NULL DEFAULT 0, used int NOT NULL DEFAULT 0, active boolean NOT NULL DEFAULT true, created_at timestamptz NOT NULL DEFAULT now());
GRANT ALL ON public.promo_codes TO service_role;
ALTER TABLE public.promo_codes ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.promo_claims (code text NOT NULL, user_id bigint NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY (code, user_id));
GRANT ALL ON public.promo_claims TO service_role;
ALTER TABLE public.promo_claims ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.tasks (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), kind text NOT NULL, link text NOT NULL, chat_ref text, title text NOT NULL, check_join boolean NOT NULL DEFAULT false, reward_usdt numeric NOT NULL, target int NOT NULL, done int NOT NULL DEFAULT 0, owner_id bigint, cost_usdt numeric NOT NULL DEFAULT 0, status text NOT NULL DEFAULT 'active', created_at timestamptz NOT NULL DEFAULT now());
GRANT ALL ON public.tasks TO service_role;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
CREATE INDEX tasks_status_idx ON public.tasks(status);
CREATE TABLE public.task_done (task_id uuid NOT NULL, user_id bigint NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY (task_id, user_id));
GRANT ALL ON public.task_done TO service_role;
ALTER TABLE public.task_done ENABLE ROW LEVEL SECURITY;
CREATE INDEX task_done_user_idx ON public.task_done(user_id);

CREATE OR REPLACE FUNCTION public.claim_promo(p_user bigint, p_code text) RETURNS numeric LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE r public.promo_codes;
BEGIN
  SELECT * INTO r FROM promo_codes WHERE code = upper(trim(p_code)) FOR UPDATE;
  IF NOT FOUND OR NOT r.active THEN RAISE EXCEPTION 'Invalid promo code'; END IF;
  IF r.max_uses > 0 AND r.used >= r.max_uses THEN RAISE EXCEPTION 'This promo code is fully used'; END IF;
  INSERT INTO promo_claims(code,user_id) VALUES (r.code,p_user) ON CONFLICT DO NOTHING;
  IF NOT FOUND THEN RAISE EXCEPTION 'You already used this promo code'; END IF;
  UPDATE promo_codes SET used = used + 1 WHERE code = r.code;
  UPDATE users SET usdt_balance = usdt_balance + r.reward_usdt WHERE tg_user_id = p_user AND NOT is_banned;
  IF NOT FOUND THEN RAISE EXCEPTION 'Account restricted'; END IF;
  RETURN r.reward_usdt;
END $$;

CREATE OR REPLACE FUNCTION public.complete_task(p_user bigint, p_task uuid) RETURNS numeric LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE t public.tasks;
BEGIN
  SELECT * INTO t FROM tasks WHERE id = p_task FOR UPDATE;
  IF NOT FOUND OR t.status <> 'active' OR t.done >= t.target THEN RAISE EXCEPTION 'This task is no longer available'; END IF;
  IF t.owner_id = p_user THEN RAISE EXCEPTION 'You cannot complete your own task'; END IF;
  INSERT INTO task_done(task_id,user_id) VALUES (p_task,p_user) ON CONFLICT DO NOTHING;
  IF NOT FOUND THEN RAISE EXCEPTION 'Task already completed'; END IF;
  UPDATE tasks SET done = done + 1, status = CASE WHEN done + 1 >= target THEN 'done' ELSE status END WHERE id = p_task;
  UPDATE users SET usdt_balance = usdt_balance + t.reward_usdt WHERE tg_user_id = p_user AND NOT is_banned;
  IF NOT FOUND THEN RAISE EXCEPTION 'Account restricted'; END IF;
  RETURN t.reward_usdt;
END $$;

CREATE OR REPLACE FUNCTION public.create_user_task(p_user bigint, p_kind text, p_link text, p_ref text, p_title text, p_check boolean, p_reward numeric, p_target int, p_cost numeric) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE nid uuid;
BEGIN
  UPDATE users SET usdt_balance = usdt_balance - p_cost WHERE tg_user_id = p_user AND NOT is_banned AND usdt_balance - admin_frozen >= p_cost;
  IF NOT FOUND THEN RAISE EXCEPTION 'Not enough USDT balance'; END IF;
  INSERT INTO tasks(kind,link,chat_ref,title,check_join,reward_usdt,target,owner_id,cost_usdt) VALUES (p_kind,p_link,p_ref,p_title,p_check,p_reward,p_target,p_user,p_cost) RETURNING id INTO nid;
  RETURN nid;
END $$;
REVOKE ALL ON FUNCTION public.claim_promo(bigint,text), public.complete_task(bigint,uuid), public.create_user_task(bigint,text,text,text,text,boolean,numeric,int,numeric) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_promo(bigint,text), public.complete_task(bigint,uuid), public.create_user_task(bigint,text,text,text,text,boolean,numeric,int,numeric) TO service_role;