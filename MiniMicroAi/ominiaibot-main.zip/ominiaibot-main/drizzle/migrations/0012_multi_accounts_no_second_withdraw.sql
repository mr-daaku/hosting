ALTER TABLE public.users ADD COLUMN IF NOT EXISTS dup_device boolean NOT NULL DEFAULT false;
UPDATE public.users SET dup_device = true, is_banned = false, ban_reason = NULL WHERE is_banned AND ban_reason = 'duplicate device';
CREATE OR REPLACE FUNCTION public.check_device_ip(p_user bigint, p_fp text, p_ip text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE owner bigint;
BEGIN
  IF p_ip IS NOT NULL AND EXISTS (SELECT 1 FROM ip_ban WHERE ip = p_ip AND banned) THEN
    PERFORM ban_user(p_user, 'banned ip', NULL);
    RETURN true;
  END IF;
  INSERT INTO device_ban(device_fingerprint, user_id) VALUES (p_fp, p_user) ON CONFLICT (device_fingerprint) DO NOTHING;
  SELECT user_id INTO owner FROM device_ban WHERE device_fingerprint = p_fp;
  IF owner IS DISTINCT FROM p_user THEN
    UPDATE users SET dup_device = true WHERE tg_user_id = p_user AND NOT dup_device;
    RETURN true;
  END IF;
  RETURN false;
END $$;
CREATE OR REPLACE FUNCTION public.withdraw_hold(p_user bigint, p_chain text, p_asset text, p_address text, p_amount numeric, p_fee numeric, p_free_cap numeric, p_needs_cap boolean)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE u users; v_id uuid; used numeric;
BEGIN
  SELECT * INTO u FROM users WHERE tg_user_id = p_user FOR UPDATE;
  IF u IS NULL OR u.is_banned THEN RAISE EXCEPTION 'Account restricted'; END IF;
  IF u.dup_device THEN RAISE EXCEPTION 'Withdrawal is allowed only from the first account on this device.'; END IF;
  IF EXISTS (SELECT 1 FROM withdrawals WHERE user_id = p_user AND status <> 'rejected' AND created_at > now() - interval '24 hours') THEN
    RAISE EXCEPTION 'You can withdraw once every 24 hours.';
  END IF;
  IF u.usdt_balance - u.admin_frozen < p_amount - 1e-9 THEN RAISE EXCEPTION 'Not enough balance'; END IF;
  IF p_needs_cap THEN
    SELECT coalesce(sum(amount), 0) INTO used FROM withdrawals WHERE user_id = p_user AND status <> 'rejected';
    IF used + p_amount > p_free_cap + 1e-9 THEN RAISE EXCEPTION 'Free withdrawal limit reached. Please make a deposit first.'; END IF;
  END IF;
  INSERT INTO withdrawals(user_id, chain, asset, address, amount, fee) VALUES (p_user, p_chain, p_asset, p_address, p_amount, p_fee) RETURNING id INTO v_id;
  UPDATE users SET usdt_balance = usdt_balance - p_amount, usdt_frozen = usdt_frozen + p_amount WHERE tg_user_id = p_user;
  RETURN v_id;
END $$;