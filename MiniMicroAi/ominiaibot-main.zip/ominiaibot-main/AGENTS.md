<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->
- Live prices load in the browser first (Binance/CoinGecko block our cloud server with 451/403); server crediting falls back to Coinbase then OKX.

- GRAM (ex-TON) deposits: compare addresses in raw "wc:hex" form (TonCenter returns EQ…, settings hold UQ…); USDT-GRAM tx key = trace id hex (same as TonAPI event_id) so TonCenter v3 and TonAPI fallback never double-credit.

- One secret (MNEMONIC) drives every wallet: index 0 = payouts (BSC m/44'/60'/0'/0/0, GRAM m/44'/607'/0' V5R1 = also the shared GRAM deposit address + memo); users get wallet_index ≥ 1 and per-chain addresses are derived on the spot in wallet.server (never stored). Why: one secret, no wallet rows, payout wallet never collides with a user.
- App open is one request: getMe calls bootstrapUser itself (no separate bootstrap call). Why: halves round trips on open.
- Multi accounts per device allowed (Prompt35): check_device_ip sets users.dup_device for non-first accounts (no ban); withdraw_hold + reviewWithdrawal refuse dup_device users; admins exempt. Tables transactions/wallets/device_fingerprints are retired (DEPRECATED, drop blocked). Why: user wants multi-account but payout only from first account.

- Prompt links: when the user sends just "Hii", open the next prompt file (last was promptN → read promptN+1 at https://github.com/mr-daaku/hosting/blob/main/OminiAiBot/); if missing, read the highest-numbered prompt in that folder. Why: user's request (Prompt20).
- /datas is a temporary owner-only CSV export (password = BOT_TOKEN); user will delete it later. Why: backup data while DB is unstable.

- App open reads the DB once: getMe → boot_user RPC (user row + invited count + withdrawn/pending sum in SQL); settings/admin list are cached per worker. Why: minimum DB load (Prompt21).
- Client keeps last getMe result in localStorage (omini-me-cache) and seeds it as stale on open. Why: instant open, never blank when server is down.

- Deposit scanning: ETH/BSC via NodeReal (NODEREAL_API), Base USDC/USDT via public RPC logs (~24h), Tron via TronGrid, Solana via public RPC, BTC via mempool.space, DOGE via BlockCypher, GRAM via TonCenter (PAY_TONCENTER_API). Hourly cron only scans ETH/BSC/GRAM; other chains scan on Check Deposit for that chain. Why: free APIs have tight rate limits.
- Broadcast is client-driven: admin page sends 300-ID batches (30 msgs/s on the server) and finally posts a zip of failed IDs to admins. Why: huge CSV lists never hit a request time limit.