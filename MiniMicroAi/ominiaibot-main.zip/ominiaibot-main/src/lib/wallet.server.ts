// Every address comes from the one MNEMONIC secret. Index 0 = payout wallet; users start at index 1.
import { HDNodeWallet, sha256, ripemd160, getBytes, concat } from "ethers";
import { bech32 } from "@scure/base";
import bs58 from "bs58";
import nacl from "tweetnacl";
import { pbkdf2Sync } from "crypto";
import { getED25519MasterKeyFromSeed, deriveED25519HardenedKey } from "@ton/crypto";

export function getMnemonic(): string {
  const m = (process.env["MNEMONIC"] || "").trim();
  if (m.split(/\s+/).length < 12) throw new Error("MNEMONIC is not configured");
  return m;
}

export function getEvmAddress(mnemonic: string, index: number): string {
  return HDNodeWallet.fromPhrase(mnemonic, undefined, `m/44'/60'/0'/0/${index}`).address;
}

// Slow seed step runs once per worker per path; each child address is then instant.
const bases = new Map<string, HDNodeWallet>();
function base(path: string) {
  let b = bases.get(path);
  if (!b) { b = HDNodeWallet.fromPhrase(getMnemonic(), undefined, path); bases.set(path, b); }
  return b;
}
const hash160 = (pub: string) => getBytes(ripemd160(sha256(pub)));
function b58check(payload: Uint8Array) {
  const sum = getBytes(sha256(sha256(payload))).slice(0, 4);
  return bs58.encode(getBytes(concat([payload, sum])));
}

/** ETH / BNB / Base deposit address. */
export function evmAddressFor(index: number): string { return base("m/44'/60'/0'/0").deriveChild(index).address; }
/** Tron (TRX / USDT TRC20): m/44'/195'/0'/0/i. */
export function tronAddressFor(index: number): string {
  const evm = base("m/44'/195'/0'/0").deriveChild(index).address;
  return b58check(getBytes(concat(["0x41", evm])));
}
/** Bitcoin native segwit (bc1…): m/84'/0'/0'/0/i. */
export function btcAddressFor(index: number): string {
  const pub = base("m/84'/0'/0'/0").deriveChild(index).publicKey;
  return bech32.encode("bc", [0, ...bech32.toWords(hash160(pub))]);
}
/** Dogecoin (D…): m/44'/3'/0'/0/i. */
export function dogeAddressFor(index: number): string {
  const pub = base("m/44'/3'/0'/0").deriveChild(index).publicKey;
  return b58check(getBytes(concat(["0x1e", hash160(pub)])));
}

let seedCache: Buffer | null = null;
const bip39Seed = () => (seedCache ??= pbkdf2Sync(getMnemonic().normalize("NFKD"), "mnemonic", 2048, 64, "sha512"));
async function ed25519(path: number[]) {
  let st = await getED25519MasterKeyFromSeed(bip39Seed());
  for (const i of path) st = await deriveED25519HardenedKey(st, i);
  return st.key;
}
/** Solana (Phantom style): m/44'/501'/i'/0'. */
export async function solAddressFor(index: number): Promise<string> {
  const kp = nacl.sign.keyPair.fromSeed(await ed25519([44, 501, index, 0]));
  return bs58.encode(kp.publicKey);
}
/** GRAM (TON) wallet seed: m/44'/607'/0' — one shared deposit + payout wallet (index 0). */
export async function tonSeed() { return ed25519([44, 607, 0]); }
let tonAddr: string | null = null;
export async function gramAddress(): Promise<string> {
  if (tonAddr) return tonAddr;
  const { WalletContractV5R1 } = await import("@ton/ton");
  const { keyPairFromSeed } = await import("@ton/crypto");
  const kp = keyPairFromSeed(await tonSeed());
  tonAddr = WalletContractV5R1.create({ workchain: 0, publicKey: kp.publicKey }).address.toString({ bounceable: false });
  return tonAddr;
}

export type DepositChain = "eth" | "bsc" | "base" | "tron" | "solana" | "btc" | "doge" | "ton";
export async function addressFor(chain: DepositChain, index: number): Promise<string> {
  switch (chain) {
    case "eth": case "bsc": case "base": return evmAddressFor(index);
    case "tron": return tronAddressFor(index);
    case "btc": return btcAddressFor(index);
    case "doge": return dogeAddressFor(index);
    case "solana": return solAddressFor(index);
    case "ton": return gramAddress();
  }
}

export function deriveAll(index: number) { return { evm: evmAddressFor(index) }; }

/** Which wallet number owns this EVM address (0..max), or null. */
export function findWalletIndex(address: string, max: number): number | null {
  const a = address.toLowerCase();
  for (let i = 0; i <= max; i++) if (evmAddressFor(i).toLowerCase() === a) return i;
  return null;
}
