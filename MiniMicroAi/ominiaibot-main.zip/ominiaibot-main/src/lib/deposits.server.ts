import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { getSettings, type Settings } from "./core.server";
import { notify } from "./telegram.server";
import { sha256, getBytes, concat } from "ethers";
import bs58 from "bs58";

type Found = { chain: string; asset: string; tx: string; amount: number; fake?: boolean };
const looksStable = (sym: unknown) => /^(USDT|USDC|USD₮|USD₮0|TETHER)/i.test(String(sym ?? "").trim());

const EVM = {
  eth: { chainid: 1, native: "ETH", tokens: { USDT: "0xdac17f958d2ee523a2206206994597c13d831ec7", USDC: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48" } },
  bsc: { chainid: 56, native: "BNB", tokens: { USDT: "0x55d398326f99059ff775485246999027b3197955", USDC: "0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d" } },
} as const;
const TON_USDT_MASTER = "0:b113a994b5024a16719f69139328eb759596c38a25f59028b146fecdc3621dfe";
const GECKO: Record<string, string> = { ETH: "ethereum", BNB: "binancecoin", TRX: "tron", SOL: "solana", BTC: "bitcoin", DOGE: "dogecoin", GRAM: "the-open-network" };

async function getJson(url: string, init?: RequestInit) {
  const r = await fetch(url, init);
  if (!r.ok) throw new Error(`${url.split("?")[0]} [${r.status}]`);
  return r.json() as Promise<any>;
}

let priceCache: { at: number; p: Record<string, number> } | null = null;
let inflight: Promise<{ values: Record<string, number>; updatedAt: number; stale: boolean }> | null = null;
/** Binance prices, cached 60s; concurrent callers share one request. */
export function prices() {
  if (priceCache && Date.now() - priceCache.at < 60000) return Promise.resolve({ values: priceCache.p, updatedAt: priceCache.at, stale: false });
  inflight ??= fetchPrices().finally(() => { inflight = null; });
  return inflight;
}
/** Coinbase public spot price — reachable from the server where Binance/CoinGecko block (451/403). */
async function coinbaseOne(sym: string) {
  try { const d = await getJson(`https://api.coinbase.com/v2/prices/${sym}-USD/spot`); const v = Number(d?.data?.amount); return v > 0 ? v : 0; } catch { return 0; }
}
async function okxOne(sym: string) {
  try { const d = await getJson(`https://www.okx.com/api/v5/market/ticker?instId=${sym}-USDT`); const v = Number(d?.data?.[0]?.last); return v > 0 ? v : 0; } catch { return 0; }
}
const MAIN = ["BNB", "ETH", "GRAM", "TRX", "SOL", "BTC", "DOGE"] as const; // TON was renamed to GRAM; Binance lists GRAMUSDT
async function fetchPrices(): Promise<{ values: Record<string, number>; updatedAt: number; stale: boolean }> {
  const p: Record<string, number> = {};
  // 1) Binance (same as price-ficher.js). Binance blocks many cloud servers, so it may fail here.
  for (const host of ["https://api.binance.com", "https://data-api.binance.vision"]) {
    try {
      const arr = await getJson(`${host}/api/v3/ticker/price?symbols=${encodeURIComponent(JSON.stringify(MAIN.map((s) => `${s}USDT`)))}`);
      for (const s of MAIN) { const r = (arr as any[]).find((x) => x.symbol === `${s}USDT`); if (Number(r?.price) > 0) p[s] = Number(r.price); }
      if (MAIN.every((s) => p[s])) break;
    } catch { /* blocked from this server, try next */ }
  }
  // 2) Coinbase, 3) OKX for anything still missing
  await Promise.all(MAIN.filter((s) => !p[s]).map(async (s) => { p[s] = (await coinbaseOne(s)) || (await okxOne(s)); }));
  // 4) CoinGecko last
  if (MAIN.some((s) => !p[s])) {
    try {
      const j = await getJson(`https://api.coingecko.com/api/v3/simple/price?ids=${Object.values(GECKO).join(",")}&vs_currencies=usd`);
      for (const [sym, id] of Object.entries(GECKO)) if (!p[sym]) p[sym] = Number(j[id]?.usd ?? 0);
    } catch { /* blocked */ }
  }
  for (const k of Object.keys(p)) if (!(p[k]! > 0)) delete p[k];
  if (Object.keys(p).length) { priceCache = { at: Date.now(), p: { ...(priceCache?.p ?? {}), ...p } }; return { values: priceCache.p, updatedAt: priceCache.at, stale: false }; }
  console.error("price: all sources failed");
  if (priceCache) return { values: priceCache.p, updatedAt: priceCache.at, stale: true };
  throw new Error("Live price is unavailable right now");
}

/** Per-source check used by /api/public/prices-check. */
export async function priceSourceReport() {
  const test = async (name: string, url: string, pick: (j: any) => unknown) => {
    const t = Date.now();
    try { const r = await fetch(url); const j = await r.json().catch(() => null); return { name, status: r.status, ok: r.ok, value: r.ok ? pick(j) : null, ms: Date.now() - t }; }
    catch (e) { return { name, status: 0, ok: false, value: String((e as Error).message), ms: Date.now() - t }; }
  };
  return Promise.all([
    test("binance", "https://api.binance.com/api/v3/ticker/price?symbol=BNBUSDT", (j) => j?.price),
    test("binance-vision", "https://data-api.binance.vision/api/v3/ticker/price?symbol=BNBUSDT", (j) => j?.price),
    test("coinbase", "https://api.coinbase.com/v2/prices/GRAM-USD/spot", (j) => j?.data?.amount),
    test("okx", "https://www.okx.com/api/v5/market/ticker?instId=BNB-USDT", (j) => j?.data?.[0]?.last),
    test("coingecko", "https://api.coingecko.com/api/v3/simple/price?ids=binancecoin&vs_currencies=usd", (j) => j?.binancecoin?.usd),
  ]);
}

/** BigInt-safe hex → decimal amount. */
function formatUnits(hex: string, decimals: number): number {
  let v: bigint;
  try { v = BigInt(hex || "0x0"); } catch { return 0; }
  const base = 10n ** BigInt(decimals);
  const whole = v / base;
  const frac = (v % base).toString().padStart(decimals, "0").replace(/0+$/, "");
  return Number(frac ? `${whole}.${frac}` : whole.toString());
}

async function knownTx(hashes: string[]) {
  if (!hashes.length) return new Set<string>();
  const { data } = await supabaseAdmin.from("deposits").select("tx_hash").in("tx_hash", hashes);
  return new Set((data ?? []).map((d) => d.tx_hash));
}

// One NodeReal key (NODEREAL_API) for both ETH and BSC.
const NODEREAL = { eth: { secret: "NODEREAL_API", host: "eth-mainnet", dec: 6 }, bsc: { secret: "NODEREAL_API", host: "bsc-mainnet", dec: 18 } } as const;

/** ETH & BSC via NodeReal nr_getTransactionByAddress — incoming only. */
async function scanEvm(address: string, chains: ("eth" | "bsc")[] = ["eth", "bsc"]): Promise<Found[]> {
  const out: Found[] = [];
  const me = address.toLowerCase();
  for (const chain of chains) {
    const key = process.env[NODEREAL[chain].secret];
    if (!key) { console.error(`${NODEREAL[chain].secret} not configured`); continue; }
    const cfg = EVM[chain];
    try {
      const j = await getJson(`https://${NODEREAL[chain].host}.nodereal.io/v1/${key}`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "nr_getTransactionByAddress",
          params: [{ category: ["external", "20"], address, order: "desc", maxCount: "0x64" }] }),
      });
      if (j.error) throw new Error(j.error.message);
      for (const t of (j.result?.transfers ?? []) as any[]) {
        const from = String(t.from ?? "").toLowerCase(), to = String(t.to ?? "").toLowerCase();
        if (from === me || to !== me) continue; // deposits only
        const tx = String(t.hash);
        if (t.category === "external") {
          const amount = formatUnits(t.value, 18);
          if (amount > 0) out.push({ chain, asset: cfg.native, tx, amount });
          continue;
        }
        const contract = String(t.contractAddress ?? "").toLowerCase();
        const sym = Object.entries(cfg.tokens).find(([, c]) => c === contract)?.[0];
        if (sym) out.push({ chain, asset: sym, tx, amount: formatUnits(t.value, NODEREAL[chain].dec) });
        else if (looksStable(t.asset)) out.push({ chain, asset: String(t.asset).slice(0, 10), tx, amount: formatUnits(t.value, Number(t.decimal ?? 18)), fake: true });
      }
    } catch (e) { console.error("evm scan", chain, e); }
  }
  return out;
}

/** Admin: every incoming/outgoing transfer for an EVM address on ETH + BSC (same NodeReal method as scanning). */
export async function inspectEvmAddress(address: string) {
  const me = address.toLowerCase();
  const rows: { chain: string; asset: string; amount: number; from: string; to: string; tx: string; direction: "in" | "out"; official: boolean; time: number | null }[] = [];
  const errors: string[] = [];
  for (const chain of ["bsc", "eth"] as const) {
    const key = process.env[NODEREAL[chain].secret];
    if (!key) { errors.push(`${chain}: API key missing`); continue; }
    const cfg = EVM[chain];
    try {
      const j = await getJson(`https://${NODEREAL[chain].host}.nodereal.io/v1/${key}`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "nr_getTransactionByAddress",
          params: [{ category: ["external", "20"], address, order: "desc", maxCount: "0x64" }] }),
      });
      if (j.error) throw new Error(j.error.message);
      for (const t of (j.result?.transfers ?? []) as any[]) {
        const from = String(t.from ?? "").toLowerCase(), to = String(t.to ?? "").toLowerCase();
        const contract = String(t.contractAddress ?? "").toLowerCase();
        const sym = t.category === "external" ? cfg.native : Object.entries(cfg.tokens).find(([, c]) => c === contract)?.[0];
        const dec = t.category === "external" ? 18 : sym ? NODEREAL[chain].dec : Number(t.decimal ?? 18);
        rows.push({ chain, asset: sym ?? String(t.asset || "TOKEN").slice(0, 12), amount: formatUnits(t.value, dec), from, to, tx: String(t.hash),
          direction: to === me ? "in" : "out", official: !!sym, time: t.blockTimeStamp ? Number(t.blockTimeStamp) * 1000 : null });
      }
    } catch (e) { errors.push(`${chain}: ${(e as Error).message}`); }
  }
  const { data: known } = await supabaseAdmin.from("deposits").select("tx_hash,status").in("tx_hash", rows.map((r) => r.tx).slice(0, 200));
  const st = new Map((known ?? []).map((k: any) => [k.tx_hash, k.status ?? "confirmed"]));
  return { rows: rows.map((r) => ({ ...r, recorded: st.get(r.tx) ?? null })), errors };
}

/** Any GRAM (ex-TON) address form (UQ…/EQ…/0:hex) → canonical "wc:hex" so bounceable & non-bounceable match. */
export function tonRaw(addr: string): string {
  const a = String(addr ?? "").trim();
  if (/^-?\d+:[0-9a-fA-F]{64}$/.test(a)) { const [wc, h] = a.split(":"); return `${Number(wc)}:${h!.toLowerCase()}`; }
  try {
    const buf = Buffer.from(a.replace(/-/g, "+").replace(/_/g, "/"), "base64");
    if (buf.length !== 36) return a.toLowerCase();
    return `${buf.readInt8(1)}:${buf.subarray(2, 34).toString("hex")}`;
  } catch { return a.toLowerCase(); }
}

/**
 * Plain-text comment from a TonCenter v2 message (same idea as ton-scan.js). TonCenter decodes text
 * comments into msg.dataText; msg.dataRaw is binary (jetton notifications, encrypted) → null.
 */
function tonMemo(m: any): string | null {
  const d = m?.msg_data;
  if (d?.["@type"] === "msg.dataText") {
    try { const t = Buffer.from(String(d.text ?? ""), "base64").toString("utf8").replace(/[^\x20-\x7E\u0900-\u097F]/g, "").trim(); if (t) return t; } catch { /* fall through */ }
    return typeof m.message === "string" && m.message.trim() ? m.message.trim() : null;
  }
  if (d?.["@type"] === "msg.dataRaw") return null;
  return typeof m?.message === "string" && m.message.trim() ? m.message.trim() : null;
}

const TON_USDT_FRIENDLY = "EQCxE6mUtQJKFnGfaROTKOt1lZbDiiX1kCixRv7Nw2Id_sDs";
const b64hex = (s: string) => { try { return Buffer.from(s, "base64").toString("hex"); } catch { return s; } };

async function withRetry<T>(fn: () => Promise<T>, tries = 3): Promise<T> {
  let last: unknown;
  for (let i = 0; i < tries; i++) {
    try { return await fn(); } catch (e) { last = e; await new Promise((r) => setTimeout(r, 800 * (i + 1))); }
  }
  throw last;
}

/** USDT on GRAM via TonCenter v3 (decoded comment). Tx key = trace id in hex (same as TonAPI event_id). */
async function scanTonUsdtCenter(tonAddress: string, key?: string): Promise<(Found & { memo: string })[]> {
  const out: (Found & { memo: string })[] = [];
  const me = tonRaw(tonAddress);
  const j = await withRetry(() => getJson(`https://toncenter.com/api/v3/jetton/transfers?owner_address=${encodeURIComponent(tonAddress)}&direction=in&limit=50&sort=desc`, key ? { headers: { "X-API-Key": key } } : undefined));
  for (const t of (j.jetton_transfers ?? []) as any[]) {
    if (t.transaction_aborted || tonRaw(t.destination) !== me) continue;
    const memo = String(t.decoded_forward_payload?.comment ?? t.comment ?? "").trim();
    if (!memo) continue;
    const master = tonRaw(t.jetton_master);
    const tx = t.trace_id ? b64hex(t.trace_id) : b64hex(t.transaction_hash);
    if (master === TON_USDT_MASTER) { out.push({ chain: "ton", asset: "USDT", tx, amount: Number(t.amount) / 1e6, memo }); continue; }
    const meta = j.metadata?.[t.jetton_master] ?? j.metadata?.[String(t.jetton_master).toUpperCase()];
    const info = meta?.token_info?.[0];
    if (looksStable(info?.symbol)) out.push({ chain: "ton", asset: String(info.symbol).slice(0, 10), tx, amount: Number(t.amount) / 10 ** Number(info?.extra?.decimals ?? 6), memo, fake: true });
  }
  return out;
}

/** Fallback: USDT jetton history via TonAPI (same method as scan.html). */
async function scanTonUsdtApi(tonAddress: string): Promise<(Found & { memo: string })[]> {
  const out: (Found & { memo: string })[] = [];
  const me = tonRaw(tonAddress);
  const j = await withRetry(() => getJson(`https://tonapi.io/v2/accounts/${encodeURIComponent(tonAddress)}/jettons/${TON_USDT_FRIENDLY}/history?limit=50`));
  for (const ev of j.events ?? []) {
    if (ev.in_progress) continue;
    for (const a of ev.actions ?? []) {
      const jt = a.JettonTransfer;
      if (a.status !== "ok" || a.type !== "JettonTransfer" || !jt?.comment) continue;
      if (tonRaw(jt.recipient?.address) !== me || tonRaw(jt.jetton?.address) !== TON_USDT_MASTER) continue;
      out.push({ chain: "ton", asset: "USDT", tx: String(ev.event_id), amount: Number(jt.amount) / 1e6, memo: String(jt.comment).trim() });
    }
  }
  return out;
}

/** GRAM (ex-TON): one shared address; native GRAM via TonCenter v2 (memo mandatory), USDT via TonCenter v3 → TonAPI. */
export async function scanTon(tonAddress: string): Promise<(Found & { memo: string })[]> {
  const out: (Found & { memo: string })[] = [];
  const me = tonRaw(tonAddress);
  const key = process.env["PAY_TONCENTER_API"]; // one TonCenter key for scanning + payouts
  try {
    const j = await withRetry(() => getJson(`https://toncenter.com/api/v2/getTransactions?address=${encodeURIComponent(tonAddress)}&limit=50&archival=true`, key ? { headers: { "X-API-Key": key } } : undefined));
    if (j.ok === false) throw new Error(String(j.error));
    for (const t of (j.result ?? []) as any[]) {
      const m = t.in_msg;
      // TonCenter returns the bounceable EQ… form while settings hold UQ…, so compare raw addresses.
      if (!m?.source || tonRaw(m.destination) !== me || m.bounced) continue;
      const amount = formatUnits("0x" + BigInt(m.value || "0").toString(16), 9);
      if (amount <= 0) continue;
      const memo = tonMemo(m);
      const tx = String(t.transaction_id?.hash ?? "");
      if (!memo) continue;
      out.push({ chain: "ton", asset: "GRAM", tx, amount, memo });
    }
  } catch (e) { console.error("gram scan", e); }
  let usdt: (Found & { memo: string })[] = [];
  try { usdt = await scanTonUsdtCenter(tonAddress, key); }
  catch (e) {
    console.error("gram usdt scan (toncenter)", e);
    try { usdt = await scanTonUsdtApi(tonAddress); } catch (e2) { console.error("gram usdt scan (tonapi)", e2); }
  }
  out.push(...usdt);
  return out;
}

async function rejectFake(userId: number, f: Found) {
  const { data } = await supabaseAdmin.from("deposits").upsert({
    user_id: userId, chain: f.chain, asset: f.asset, tx_hash: f.tx, amount: f.amount, usd_value: 0, coins_credited: 0, status: "fake",
  }, { onConflict: "tx_hash,asset", ignoreDuplicates: true }).select("id");
  if (data?.length)
    await notify(userId, `⚠️ <b>Fake token detected</b>\nA transfer of ${f.amount} "${f.asset}" on ${f.chain} is not the official USDT/USDC contract and was <b>not credited</b>.\nTx: <code>${f.tx}</code>`);
  return data?.length ? { ...f, usd: 0, coins: 0 } : null;
}

/** Native → USDT (live price) → coins (coin_rate). Deduped by tx hash. */
export async function credit(userId: number, f: Found, s: Settings, opts: { force?: boolean } = {}) {
  if (f.fake) return rejectFake(userId, f);
  const stable = f.asset === "USDT" || f.asset === "USDC";
  const p: Record<string, number> = stable ? {} : (await prices()).values;
  const usd = Math.round(f.amount * (stable ? 1 : p[f.asset] ?? 0) * 1e4) / 1e4;
  if (!opts.force && usd < Number(s.min_deposit_usd)) {
    const { data } = await supabaseAdmin.from("deposits").upsert({
      user_id: userId, chain: f.chain, asset: f.asset, tx_hash: f.tx, amount: f.amount, usd_value: usd, coins_credited: 0, status: "below_minimum",
    }, { onConflict: "tx_hash,asset", ignoreDuplicates: true }).select("id");
    return data?.length ? { ...f, usd, coins: 0, below: true } : null;
  }
  if (usd <= 0) return null;
  // No referral deposit bonus any more (p_ref_pct = 0).
  const { data, error } = await supabaseAdmin.rpc("credit_deposit", {
    p_user: userId, p_chain: f.chain, p_asset: f.asset, p_tx: f.tx, p_amount: f.amount, p_usd: usd,
    p_rate: Number(s.coin_rate), p_ref_pct: 0,
  });
  if (error) { console.error("credit", error); throw new Error(error.message); }
  if (data == null) return null;
  const coins = Number(data);
  await notify(userId, `✅ <b>Deposit confirmed</b>\n${f.amount} ${f.asset} (${f.chain}) ≈ $${usd} → <b>+${coins} coins</b>\nTx: <code>${f.tx}</code>`);
  return { ...f, usd, coins };
}

// ---------- Base (USDC / USDT) — public RPC logs, last ~24h ----------
const BASE_RPC = ["https://base-rpc.publicnode.com", "https://mainnet.base.org"];
const BASE_TOKENS = { USDC: "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913", USDT: "0xfde4c96c8593536e31f229ea8f37b2ada2699bb2" } as const;
const TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";
async function evmRpc(urls: string[], method: string, params: unknown[]) {
  let last: unknown;
  for (const url of urls) {
    try {
      const j = await getJson(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }) });
      if (j.error) throw new Error(j.error.message);
      return j.result;
    } catch (e) { last = e; }
  }
  throw last;
}
export async function scanBase(address: string): Promise<Found[]> {
  const out: Found[] = [];
  try {
    const head = Number(BigInt(await evmRpc(BASE_RPC, "eth_blockNumber", [])));
    const topicTo = "0x" + address.toLowerCase().slice(2).padStart(64, "0");
    for (const [sym, contract] of Object.entries(BASE_TOKENS)) {
      const logs = (await evmRpc(BASE_RPC, "eth_getLogs", [{ fromBlock: "0x" + Math.max(0, head - 43000).toString(16), toBlock: "latest", address: contract, topics: [TRANSFER_TOPIC, null, topicTo] }])) as any[];
      for (const l of logs ?? []) if (!l.removed) out.push({ chain: "base", asset: sym, tx: String(l.transactionHash), amount: formatUnits(l.data, 6) });
    }
  } catch (e) { console.error("base scan", e); }
  return out;
}

// ---------- Tron (TRX / USDT TRC20) — TronGrid ----------
const TRON_USDT = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";
export async function scanTron(address: string): Promise<Found[]> {
  const out: Found[] = [];
  const g = "https://api.trongrid.io/v1/accounts/" + address;
  try {
    const j = await withRetry(() => getJson(`${g}/transactions/trc20?only_to=true&only_confirmed=true&limit=50`));
    for (const t of (j.data ?? []) as any[]) {
      if (t.to !== address || t.type !== "Transfer") continue;
      const dec = Number(t.token_info?.decimals ?? 6);
      if (t.token_info?.address === TRON_USDT) out.push({ chain: "tron", asset: "USDT", tx: String(t.transaction_id), amount: Number(t.value) / 10 ** dec });
      else if (looksStable(t.token_info?.symbol)) out.push({ chain: "tron", asset: String(t.token_info.symbol).slice(0, 10), tx: String(t.transaction_id), amount: Number(t.value) / 10 ** dec, fake: true });
    }
  } catch (e) { console.error("tron trc20 scan", e); }
  try {
    const j = await withRetry(() => getJson(`${g}/transactions?only_to=true&only_confirmed=true&limit=50`));
    for (const t of (j.data ?? []) as any[]) {
      const c = t.raw_data?.contract?.[0];
      if (c?.type !== "TransferContract" || t.ret?.[0]?.contractRet !== "SUCCESS") continue;
      const v = c.parameter?.value;
      if (!v || tronB58(String(v.to_address)) !== address) continue;
      const amount = Number(v.amount) / 1e6;
      if (amount > 0) out.push({ chain: "tron", asset: "TRX", tx: String(t.txID), amount });
    }
  } catch (e) { console.error("tron trx scan", e); }
  return out;
}
/** Tron hex (41…) → base58 T… address. */
function tronB58(hex41: string) {
  try {
    const payload = getBytes("0x" + hex41.replace(/^0x/, ""));
    const sum = getBytes(sha256(sha256(payload))).slice(0, 4);
    return bs58.encode(getBytes(concat([payload, sum])));
  } catch { return hex41; }
}

// ---------- Solana (SOL / USDT / USDC) — public RPC ----------
const SOL_RPC = ["https://solana-rpc.publicnode.com", "https://api.mainnet-beta.solana.com"];
const SOL_MINTS: Record<string, string> = { Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB: "USDT", EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v: "USDC" };
export async function scanSolana(address: string): Promise<Found[]> {
  const out: Found[] = [];
  try {
    const accts = (await evmRpc(SOL_RPC, "getTokenAccountsByOwner", [address, { programId: "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA" }, { encoding: "jsonParsed" }])) as any;
    const watch = [address, ...((accts?.value ?? []) as any[]).filter((a) => SOL_MINTS[a.account?.data?.parsed?.info?.mint]).map((a) => String(a.pubkey))];
    const sigs = new Set<string>();
    for (const w of watch) {
      const list = (await evmRpc(SOL_RPC, "getSignaturesForAddress", [w, { limit: 20 }])) as any[];
      for (const x of list ?? []) if (!x.err && (x.confirmationStatus === "finalized" || x.confirmationStatus === "confirmed")) sigs.add(String(x.signature));
    }
    const known = await knownTx([...sigs]);
    for (const sig of [...sigs].filter((x) => !known.has(x)).slice(0, 15)) {
      const tx = (await evmRpc(SOL_RPC, "getTransaction", [sig, { encoding: "jsonParsed", maxSupportedTransactionVersion: 0 }])) as any;
      if (!tx || tx.meta?.err) continue;
      const keys = ((tx.transaction?.message?.accountKeys ?? []) as any[]).map((k) => String(k.pubkey ?? k));
      const i = keys.indexOf(address);
      if (i > 0) { // index 0 is the fee payer (= we sent it)
        const lamports = Number(tx.meta.postBalances?.[i] ?? 0) - Number(tx.meta.preBalances?.[i] ?? 0);
        if (lamports > 0) out.push({ chain: "solana", asset: "SOL", tx: sig, amount: lamports / 1e9 });
      }
      for (const post of (tx.meta?.postTokenBalances ?? []) as any[]) {
        const sym = SOL_MINTS[post.mint];
        if (!sym || post.owner !== address) continue;
        const pre = ((tx.meta.preTokenBalances ?? []) as any[]).find((p) => p.accountIndex === post.accountIndex);
        const delta = Number(post.uiTokenAmount?.uiAmountString ?? 0) - Number(pre?.uiTokenAmount?.uiAmountString ?? 0);
        if (delta > 0) out.push({ chain: "solana", asset: sym, tx: sig, amount: Math.round(delta * 1e6) / 1e6 });
      }
    }
  } catch (e) { console.error("solana scan", e); }
  return out;
}

// ---------- Bitcoin — mempool.space ----------
export async function scanBtc(address: string): Promise<Found[]> {
  const out: Found[] = [];
  try {
    const txs = (await withRetry(() => getJson(`https://mempool.space/api/address/${address}/txs`))) as any[];
    for (const t of txs ?? []) {
      if (!t.status?.confirmed) continue;
      if ((t.vin ?? []).some((v: any) => v.prevout?.scriptpubkey_address === address)) continue; // our own send
      const sats = (t.vout ?? []).filter((o: any) => o.scriptpubkey_address === address).reduce((a: number, o: any) => a + Number(o.value), 0);
      if (sats > 0) out.push({ chain: "btc", asset: "BTC", tx: String(t.txid), amount: sats / 1e8 });
    }
  } catch (e) { console.error("btc scan", e); }
  return out;
}

// ---------- Dogecoin — BlockCypher ----------
export async function scanDoge(address: string): Promise<Found[]> {
  const out: Found[] = [];
  try {
    const j = await withRetry(() => getJson(`https://api.blockcypher.com/v1/doge/main/addrs/${address}?limit=50&confirmations=1`));
    const refs = (j.txrefs ?? []) as any[];
    const spent = new Set(refs.filter((r) => r.tx_input_n >= 0).map((r) => r.tx_hash));
    const by = new Map<string, number>();
    for (const r of refs) if (r.tx_input_n === -1 && !spent.has(r.tx_hash)) by.set(r.tx_hash, (by.get(r.tx_hash) ?? 0) + Number(r.value));
    for (const [tx, v] of by) out.push({ chain: "doge", asset: "DOGE", tx, amount: v / 1e8 });
  } catch (e) { console.error("doge scan", e); }
  return out;
}

type UserRow = { tg_user_id: number; wallet_index: number; is_banned: boolean };
export const USER_SCAN_COLS = "tg_user_id,wallet_index,is_banned";
export const ALL_SCAN_CHAINS = ["eth", "bsc", "base", "tron", "solana", "btc", "doge", "ton"] as const;
export type ScanChain = (typeof ALL_SCAN_CHAINS)[number];

/** Scan the given chains for one user (default: every chain) and credit new deposits. */
export async function scanUser(u: UserRow, opts: { chains?: readonly ScanChain[]; tonCache?: (Found & { memo: string })[] } = {}) {
  if (u.is_banned || u.wallet_index < 1) return [];
  const chains = new Set(opts.chains ?? ALL_SCAN_CHAINS);
  const s = await getSettings();
  const w = await import("./wallet.server");
  const found: Found[] = [];
  const evm = w.evmAddressFor(u.wallet_index);
  const jobs: Promise<Found[]>[] = [];
  const evmChains = (["eth", "bsc"] as const).filter((c) => chains.has(c));
  if (evmChains.length) jobs.push(scanEvm(evm, evmChains));
  if (chains.has("base")) jobs.push(scanBase(evm));
  if (chains.has("tron")) jobs.push(scanTron(w.tronAddressFor(u.wallet_index)));
  if (chains.has("solana")) jobs.push(w.solAddressFor(u.wallet_index).then(scanSolana));
  if (chains.has("btc")) jobs.push(scanBtc(w.btcAddressFor(u.wallet_index)));
  if (chains.has("doge")) jobs.push(scanDoge(w.dogeAddressFor(u.wallet_index)));
  if (chains.has("ton")) {
    jobs.push((async () => {
      const ton = opts.tonCache ?? (await scanTon(await w.gramAddress()));
      const myMemo = `${s.memo_prefix}${u.tg_user_id}`.trim().toUpperCase();
      return myMemo ? ton.filter((t) => t.memo.trim().toUpperCase() === myMemo) : [];
    })());
  }
  for (const r of await Promise.all(jobs)) found.push(...r);
  const known = await knownTx(found.map((f) => f.tx));
  const credited = [];
  for (const f of found) {
    if (known.has(f.tx)) continue;
    try {
      const c = await credit(u.tg_user_id, f, s);
      if (c) credited.push(c);
    } catch (e) { console.error("credit failed", e); }
  }
  return credited;
}

/** Hourly cron: ETH/BSC/GRAM for users active in the last 48h (other chains on "Check Deposit" — free APIs have tight limits). */
export async function scanActiveUsers() {
  const since = new Date(Date.now() - 48 * 3600000).toISOString();
  const { data: users } = await supabaseAdmin.from("users")
    .select(USER_SCAN_COLS)
    .eq("is_banned", false).gte("last_seen_at", since).limit(200);
  const { gramAddress } = await import("./wallet.server");
  const ton = await scanTon(await gramAddress());
  let total = 0;
  for (const u of users ?? []) total += (await scanUser(u, { chains: ["eth", "bsc", "ton"], tonCache: ton })).length;
  return { users: users?.length ?? 0, credited: total };
}
