import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const auth = z.object({ initData: z.string().min(1).max(8000) });
type TaskRow = { id: string; kind: string; link: string; chat_ref: string | null; title: string; check_join: boolean; reward_usdt: number; target: number; done: number; owner_id: number | null; status: string };

// Active task list is the same for everyone: cached per worker 30s so opening the Tasks page rarely hits the database.
let taskCache: { rows: TaskRow[]; at: number } | null = null;
async function activeTasks(): Promise<TaskRow[]> {
  if (taskCache && Date.now() - taskCache.at < 30000) return taskCache.rows;
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin.from("tasks").select("id,kind,link,chat_ref,title,check_join,reward_usdt,target,done,owner_id,status").eq("status", "active").order("created_at", { ascending: false }).limit(100);
  if (error) throw new Error(error.message);
  taskCache = { rows: (data ?? []) as TaskRow[], at: Date.now() };
  return taskCache.rows;
}
const dropTaskCache = () => { taskCache = null; };

function taskPrices(s: Record<string, unknown>) {
  return {
    price: Number(s["task_price"] ?? 0.005), priceCheck: Number(s["task_price_check"] ?? 0.008),
    minTarget: Number(s["task_min_target"] ?? 250), userReward: Number(s["user_task_reward"] ?? 0.004),
    adminReward: Number(s["task_reward_default"] ?? 0.05),
  };
}

/** Link → type + title. Telegram public chats are looked up through the bot. */
async function inspectLink(raw: string) {
  const link = raw.trim();
  const m = /^(?:https?:\/\/)?(?:t\.me|telegram\.me)\/([^/?#]+)/i.exec(link);
  if (!m) {
    let host = link; try { host = new URL(link).hostname; } catch { /* keep */ }
    return { kind: "other", ref: null as string | null, title: host, link };
  }
  const name = m[1]!;
  const url = `https://t.me/${name}`;
  if (name.startsWith("+") || name === "joinchat") return { kind: "group", ref: null, title: "Private chat", link };
  if (/bot$/i.test(name)) return { kind: "bot", ref: null, title: `@${name}`, link: url };
  const { tgApi } = await import("./telegram.server");
  try {
    const c = (await tgApi("getChat", { chat_id: `@${name}` })) as { type: string; title?: string };
    return { kind: c.type === "channel" ? "channel" : "group", ref: `@${name}`, title: c.title || `@${name}`, link: url };
  } catch { return { kind: "channel", ref: `@${name}`, title: `@${name}`, link: url }; }
}

export const previewTaskLink = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ link: z.string().min(5).max(300) }).parse(d))
  .handler(async ({ data }) => {
    const { verifyInitData } = await import("./telegram.server");
    verifyInitData(data.initData);
    return inspectLink(data.link);
  });

export const getTasks = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.parse(d))
  .handler(async ({ data }) => {
    const { verifyInitData } = await import("./telegram.server");
    const { getSettings } = await import("./core.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { user } = verifyInitData(data.initData);
    const [rows, s, done, mine] = await Promise.all([
      activeTasks(), getSettings(),
      supabaseAdmin.from("task_done").select("task_id").eq("user_id", user.id).order("created_at", { ascending: false }).limit(500),
      supabaseAdmin.from("tasks").select("id,title,kind,target,done,status,cost_usdt").eq("owner_id", user.id).order("created_at", { ascending: false }).limit(20),
    ]);
    const doneSet = new Set((done.data ?? []).map((d) => d.task_id));
    return {
      tasks: rows.filter((t) => t.owner_id !== user.id && !doneSet.has(t.id)).map((t) => ({ id: t.id, kind: t.kind, link: t.link, title: t.title, checkJoin: t.check_join, reward: Number(t.reward_usdt) })),
      mine: mine.data ?? [],
      prices: taskPrices(s as unknown as Record<string, unknown>),
    };
  });

export const completeTask = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const { verifyInitData, tgApi } = await import("./telegram.server");
    const { rateLimit } = await import("./core.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { user } = verifyInitData(data.initData, 3600);
    await rateLimit(`task:${user.id}`, 1, 3);
    const t = (await activeTasks()).find((x) => x.id === data.id);
    if (!t) throw new Error("This task is no longer available");
    if (t.check_join && t.chat_ref) {
      let ok = false;
      try {
        const m = (await tgApi("getChatMember", { chat_id: t.chat_ref, user_id: user.id })) as { status: string };
        ok = ["member", "administrator", "creator", "restricted"].includes(m.status);
      } catch { throw new Error("Could not verify right now, please try again later"); }
      if (!ok) throw new Error("Please join first, then tap Check");
    }
    const { data: r, error } = await supabaseAdmin.rpc("complete_task", { p_user: user.id, p_task: t.id });
    if (error) throw new Error(error.message);
    if (t.done + 1 >= t.target) dropTaskCache();
    return { reward: Number(r) };
  });

export const createUserTask = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ link: z.string().min(5).max(300), target: z.number().int().positive().max(1e6), checkJoin: z.boolean() }).parse(d))
  .handler(async ({ data }) => {
    const { verifyInitData } = await import("./telegram.server");
    const { getSettings, rateLimit } = await import("./core.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { user } = verifyInitData(data.initData, 3600);
    await rateLimit(`mktask:${user.id}`, 1, 5);
    const p = taskPrices((await getSettings()) as unknown as Record<string, unknown>);
    if (data.target < p.minTarget) throw new Error(`Minimum ${p.minTarget} completions`);
    const info = await inspectLink(data.link);
    const check = data.checkJoin && !!info.ref && (info.kind === "channel" || info.kind === "group");
    if (check) {
      const { tgApi, BOT_USERNAME } = await import("./telegram.server");
      try {
        const me = (await tgApi("getMe", {})) as { id: number };
        const m = (await tgApi("getChatMember", { chat_id: info.ref, user_id: me.id })) as { status: string };
        if (m.status !== "administrator") throw new Error();
      } catch { throw new Error(`To check joins, add @${BOT_USERNAME} as admin of ${info.title} first`); }
    }
    const cost = Math.round(data.target * (check ? p.priceCheck : p.price) * 1e6) / 1e6;
    const { data: id, error } = await supabaseAdmin.rpc("create_user_task", {
      p_user: user.id, p_kind: info.kind, p_link: info.link, p_ref: info.ref ?? "", p_title: info.title.slice(0, 120), p_check: check, p_reward: p.userReward, p_target: data.target, p_cost: cost,
    });
    if (error) throw new Error(error.message);
    dropTaskCache();
    return { id: id as string, cost };
  });

export const claimPromo = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ code: z.string().trim().min(1).max(40) }).parse(d))
  .handler(async ({ data }) => {
    const { verifyInitData } = await import("./telegram.server");
    const { rateLimit } = await import("./core.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { user } = verifyInitData(data.initData, 3600);
    await rateLimit(`promo:${user.id}`, 1, 3);
    const { data: r, error } = await supabaseAdmin.rpc("claim_promo", { p_user: user.id, p_code: data.code });
    if (error) throw new Error(error.message);
    return { reward: Number(r) };
  });

// ---------- Admin ----------
async function adm(initData: string) {
  const { requireAdmin } = await import("./core.server");
  await requireAdmin(initData);
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export const adminTasksList = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.parse(d))
  .handler(async ({ data }) => {
    const db = await adm(data.initData);
    const [t, p] = await Promise.all([
      db.from("tasks").select("*").order("created_at", { ascending: false }).limit(200),
      db.from("promo_codes").select("*").order("created_at", { ascending: false }).limit(200),
    ]);
    return { tasks: t.data ?? [], promos: p.data ?? [] };
  });

export const adminSaveTask = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ link: z.string().min(5).max(300), title: z.string().max(120).optional(), target: z.number().int().positive().max(1e7), reward: z.number().min(0).max(100), checkJoin: z.boolean() }).parse(d))
  .handler(async ({ data }) => {
    const db = await adm(data.initData);
    const info = await inspectLink(data.link);
    const { error } = await db.from("tasks").insert({ kind: info.kind, link: info.link, chat_ref: info.ref, title: (data.title || info.title).slice(0, 120), check_join: data.checkJoin && !!info.ref, reward_usdt: data.reward, target: data.target });
    if (error) throw new Error(error.message);
    dropTaskCache();
    return { ok: true };
  });

export const adminTaskAction = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ id: z.string().uuid(), action: z.enum(["pause", "resume", "delete", "refund"]) }).parse(d))
  .handler(async ({ data }) => {
    const db = await adm(data.initData);
    if (data.action === "delete") await db.from("tasks").delete().eq("id", data.id);
    else if (data.action === "refund") {
      const { data: t } = await db.from("tasks").select("*").eq("id", data.id).single();
      if (!t || !t.owner_id || t.status === "refunded") throw new Error("Nothing to refund");
      const left = Math.max(0, Number(t.cost_usdt) * (1 - t.done / t.target));
      await db.from("tasks").update({ status: "refunded" }).eq("id", data.id);
      const { applyBalance } = await import("./core.server");
      if (left > 0) await applyBalance(Number(t.owner_id), "task_refund", 0, Math.round(left * 1e6) / 1e6);
    } else await db.from("tasks").update({ status: data.action === "pause" ? "paused" : "active" }).eq("id", data.id);
    dropTaskCache();
    return { ok: true };
  });

export const adminSavePromo = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ code: z.string().trim().min(2).max(40), reward: z.number().positive().max(1000), maxUses: z.number().int().min(0).max(1e7) }).parse(d))
  .handler(async ({ data }) => {
    const db = await adm(data.initData);
    const { error } = await db.from("promo_codes").upsert({ code: data.code.toUpperCase(), reward_usdt: data.reward, max_uses: data.maxUses, active: true });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const adminPromoAction = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ code: z.string().max(40), action: z.enum(["toggle", "delete"]) }).parse(d))
  .handler(async ({ data }) => {
    const db = await adm(data.initData);
    if (data.action === "delete") { await db.from("promo_claims").delete().eq("code", data.code); await db.from("promo_codes").delete().eq("code", data.code); }
    else { const { data: p } = await db.from("promo_codes").select("active").eq("code", data.code).single(); await db.from("promo_codes").update({ active: !p?.active }).eq("code", data.code); }
    return { ok: true };
  });
