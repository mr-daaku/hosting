import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, ExternalLink, Plus } from "lucide-react";
import { Shell, PageTitle, card } from "@/components/app/Shell";
import { useTg, useRefreshMe, haptic, openLink } from "@/lib/tg";
import { getTasks, completeTask, createUserTask, previewTaskLink } from "@/lib/tasks.functions";

export const Route = createFileRoute("/tasks")({
  head: () => ({
    meta: [
      { title: "Tasks & earn — OminiAi" },
      { name: "description", content: "Complete simple tasks to earn USDT, or create your own task to grow your channel, group or bot." },
      { property: "og:title", content: "Tasks & earn — OminiAi" },
      { property: "og:description", content: "Earn USDT for joining channels, groups and bots." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => <Shell><Tasks /></Shell>,
});

function Tasks() {
  const { initData } = useTg();
  const refresh = useRefreshMe();
  const q = useQuery({ queryKey: ["tasks", initData], queryFn: () => getTasks({ data: { initData } }), enabled: !!initData, staleTime: 30000 });
  const [opened, setOpened] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState<string | null>(null);
  const [create, setCreate] = useState(false);
  const d = q.data;

  const check = async (id: string) => {
    if (busy) return;
    setBusy(id);
    try { const r = await completeTask({ data: { initData, id } }); haptic("success"); toast.success(`+${r.reward} USDT`); refresh(); await q.refetch(); }
    catch (e) { haptic("error"); toast.error((e as Error).message); } finally { setBusy(null); }
  };

  return (
    <div>
      <PageTitle right={<Link to="/" className="inline-flex items-center gap-1 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" />Back</Link>}>Tasks & earn</PageTitle>
      <button onClick={() => setCreate((v) => !v)} className="mb-3 inline-flex w-full items-center justify-center gap-2 rounded-2xl border border-dashed border-primary/60 py-3 text-sm font-bold text-primary"><Plus className="h-4 w-4" /> Create your own task</button>
      {create && d && <CreateTask prices={d.prices} onDone={() => { setCreate(false); refresh(); q.refetch(); }} />}
      {!d ? <p className="text-muted-foreground">Loading…</p> : d.tasks.length === 0 ? <p className={`${card} text-center text-sm text-muted-foreground`}>No tasks right now. Check back later.</p> : (
        <div className="space-y-2">
          {d.tasks.map((t) => (
            <div key={t.id} className={`${card} flex items-center gap-3`}>
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold">{t.title}</p>
                <p className="text-xs capitalize text-muted-foreground">{t.kind} · +{t.reward} USDT</p>
              </div>
              {opened.has(t.id) ? (
                <button onClick={() => check(t.id)} disabled={busy === t.id} aria-busy={busy === t.id} className="rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground disabled:opacity-60">{busy === t.id ? "…" : "Check"}</button>
              ) : (
                <button onClick={() => { openLink(t.link); setTimeout(() => setOpened((s) => new Set(s).add(t.id)), 1500); }} className="inline-flex items-center gap-1 rounded-xl bg-muted px-4 py-2 text-sm font-bold">Start <ExternalLink className="h-3 w-3" /></button>
              )}
            </div>
          ))}
        </div>
      )}
      {d && d.mine.length > 0 && (
        <>
          <p className="mb-2 mt-5 text-sm font-semibold text-muted-foreground">My tasks</p>
          <div className="space-y-2">{d.mine.map((m) => (
            <div key={m.id} className={`${card} flex justify-between text-sm`}><span className="truncate">{m.title}</span><span className="shrink-0 text-muted-foreground">{m.done}/{m.target} · {m.status}</span></div>
          ))}</div>
        </>
      )}
    </div>
  );
}

function CreateTask({ prices, onDone }: { prices: { price: number; priceCheck: number; minTarget: number }; onDone: () => void }) {
  const { initData } = useTg();
  const [link, setLink] = useState("");
  const [target, setTarget] = useState(String(prices.minTarget));
  const [checkJoin, setCheckJoin] = useState(false);
  const [info, setInfo] = useState<{ kind: string; title: string; ref: string | null } | null>(null);
  const [busy, setBusy] = useState(false);
  const n = Math.floor(Number(target) || 0);
  const canCheck = !!info?.ref && (info.kind === "channel" || info.kind === "group");
  const cost = n * (checkJoin && canCheck ? prices.priceCheck : prices.price);
  const look = async () => {
    if (link.trim().length < 5) return;
    try { setInfo(await previewTaskLink({ data: { initData, link: link.trim() } })); } catch { setInfo(null); }
  };
  const pay = async () => {
    if (busy) return;
    if (n < prices.minTarget) { toast.error(`Minimum ${prices.minTarget} completions`); return; }
    setBusy(true);
    try { const r = await createUserTask({ data: { initData, link: link.trim(), target: n, checkJoin: checkJoin && canCheck } }); haptic("success"); toast.success(`Task created. Paid ${r.cost} USDT`); onDone(); }
    catch (e) { haptic("error"); toast.error((e as Error).message); } finally { setBusy(false); }
  };
  return (
    <div className={`${card} mb-4 space-y-3`}>
      <input value={link} onChange={(e) => setLink(e.target.value)} onBlur={look} placeholder="https://t.me/yourchannel" className="w-full rounded-xl bg-muted px-3 py-2 text-sm outline-none" />
      {info && <p className="text-xs text-muted-foreground"><b className="capitalize text-foreground">{info.kind}</b> · {info.title}</p>}
      <input value={target} onChange={(e) => setTarget(e.target.value.replace(/\D/g, ""))} inputMode="numeric" placeholder={`Total completions (min ${prices.minTarget})`} className="w-full rounded-xl bg-muted px-3 py-2 text-sm outline-none" />
      <label className={`flex items-center justify-between text-sm ${canCheck ? "" : "opacity-50"}`}>
        <span>Check that users really joined<br /><span className="text-xs text-muted-foreground">${prices.priceCheck}/user · bot must be admin</span></span>
        <input type="checkbox" disabled={!canCheck} checked={checkJoin && canCheck} onChange={(e) => setCheckJoin(e.target.checked)} className="h-5 w-5" />
      </label>
      <button onClick={pay} disabled={busy} aria-busy={busy} className="w-full rounded-2xl bg-primary py-3 font-bold text-primary-foreground disabled:opacity-60">{busy ? "Paying…" : `Pay ${cost.toFixed(4)} USDT & create`}</button>
      <p className="text-center text-xs text-muted-foreground">${prices.price} per user · min {prices.minTarget} users · paid from your USDT balance</p>
    </div>
  );
}
