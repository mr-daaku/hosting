# Crypto Wallet + Refer + Support Telegram Mini App (bina daily return)

## Kya banega
Telegram Mini App aur Bot, aapke screenshots jaisa design. Isme koi "daily return" ya guaranteed kamai nahi hogi. Emoji ki jagah SVG icons, apna logo aur images.

### User side
- **Wallet**: USDT balance (asli, jo deposit se aata hai). FLASH USDT, mining aur daily return nahi honge.
- **Deposit**: har user ka apna address (HD wallet + wallet index 1, 2, 3...). Address database mein save nahi hoga. Har baar secret se banega.
  - Chains aur coins: BNB (BNB, USDT, USDC), ETH (ETH, USDT, USDC), TRON (TRX, USDT), SOL (SOL, USDC, USDT), BTC, TON (GRAM/TON, USDT).
  - Minimum deposit settings se badal sakte hain (default $2).
- **Withdraw**: sirf BEP-20 USDT, seedha form. Payment method chunna nahi padega. Account kam se kam 1 ghanta purana hona chahiye. Ek device par kai accounts bane hon to unse withdraw block hoga.
- **Refer**: link `https://t.me/{bot}?start=ref_{userid}`. Har sahi referral (jab referred user pehla deposit kare) par gift box mein 2-10 points/coupon milenge. Yeh withdraw nahi honge. Iske badle aap batayein ki inka kya istemal ho.
- **Tasks**: channel join karne jaise tasks par points.
- **Profile**: history, legal page, support.
- **Support bot** (SUPPORT_BOT_TOKEN): user message bheje, dono admin ko mile, admin reply kare.

### Admin panel (sirf ADMIN_ID aur ADMIN_ID_2)
Dashboard, Users, Withdrawals (Pending / Paid / Rejected), Deposits, Auto Pay (on/off), Check Deposit (user ID ya tx hash se), Settings (app ki saari settings), Broadcast (ek user / kai user / sab users, batch mein bheje, aakhir mein pass/fail report), Tasks, Admin logs.

## Security (aapki list ke hisaab se)
- Har request par Telegram initData ka signature check, purana data reject. Frontend se aaya user ID kabhi nahi mana jayega.
- Balance sirf ledger se badlega. Database transaction aur row lock lagenge. Unique (chain, tx_hash, log_index) se ek deposit do baar credit nahi hoga. Balance negative nahi ho sakta.
- Deposit sirf blockchain se verify hoga: sahi chain, sahi token contract, poore confirmations, sahi address. User ka bheja hash sirf check karne ke kaam aayega.
- Withdraw ke liye idempotency key aur lock hoga, taaki double-click se do baar paisa na kate. Auto pay ki daily limit hogi. Uske upar ki withdrawal admin approve karega.
- Seed phrase sirf server secret mein rahega. Har admin action log hoga.
- Settings aur admin list cache mein rahenge. Broadcast user IDs ko pages mein ek hi baar padhega, baar-baar nahi.

## Zaroori secrets
BOT_TOKEN, SUPPORT_BOT_TOKEN, ADMIN_ID, ADMIN_ID_2, HD_WALLET, ALCHEMY_API. Main inhe Lovable Cloud mein add karwaunga.

## Dhyan dein
- Alchemy BNB, ETH, SOL aur BTC ke liye kaam karta hai. TRON aur TON ke liye public API (TronGrid, Toncenter) lagegi.
- Asli paise ka test aapke real wallet se hi hoga. Main code aur test-network tak hi check kar sakta hoon.

## Technical details
- Lovable Cloud: tables users, ledger, deposits, withdrawals, referrals, tasks, settings, admin_logs, broadcasts, support_threads. Balance badalne ke saare kaam security-definer SQL functions se honge.
- Server functions (TanStack): initData HMAC verify, HD key derivation (@scure/bip32/bip39, ed25519 for SOL/TON, tronweb-lite address), Telegram webhooks `/api/public/bot` aur `/api/public/support-bot` (secret-token header check), deposit scan route jo cron chalaye, auto-pay worker jisme row lock ho.
- Pages: /, /deposit, /withdraw, /refer, /tasks, /profile, /legal, /admin/*.

## Steps
1. Cloud on karna, database tables aur security
2. Secrets
3. Telegram login aur bot webhooks
4. Wallet, deposit address aur scanner
5. Withdraw aur auto pay
6. Refer, tasks, support bot
7. Admin panel aur broadcast
8. Design, logo, images
9. Tests (double credit, double withdraw, fake initData) aur fixes
