ALTER TABLE public.gift_boxes ALTER COLUMN referred_id DROP NOT NULL;
ALTER TABLE public.gift_boxes ADD CONSTRAINT gift_boxes_kind_chk CHECK (referred_id IS NOT NULL OR daily_day IS NOT NULL);