ALTER TABLE public.gift_boxes ADD COLUMN IF NOT EXISTS daily_day date;
CREATE UNIQUE INDEX IF NOT EXISTS gift_boxes_daily_uq ON public.gift_boxes (user_id, daily_day) WHERE daily_day IS NOT NULL;

CREATE OR REPLACE FUNCTION public.claim_daily_gift(p_user bigint)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE v_id bigint;
BEGIN
  INSERT INTO gift_boxes (user_id, daily_day) VALUES (p_user, (now() AT TIME ZONE 'utc')::date)
  ON CONFLICT (user_id, daily_day) WHERE daily_day IS NOT NULL DO NOTHING RETURNING id INTO v_id;
  RETURN v_id IS NOT NULL;
END $$;
REVOKE ALL ON FUNCTION public.claim_daily_gift(bigint) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_daily_gift(bigint) TO service_role;

CREATE OR REPLACE FUNCTION public.claim_welcome(p_user bigint, p_points integer)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  IF p_points <= 0 THEN RETURN NULL; END IF;
  UPDATE app_users SET welcome_claimed = true, points = points + p_points
   WHERE id = p_user AND NOT welcome_claimed AND NOT withdraw_blocked AND NOT banned;
  IF NOT FOUND THEN RETURN NULL; END IF;
  RETURN p_points;
END $$;
REVOKE ALL ON FUNCTION public.claim_welcome(bigint, integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_welcome(bigint, integer) TO service_role;

ALTER TABLE public.broadcasts ADD COLUMN IF NOT EXISTS photo_id text;
ALTER TABLE public.broadcasts ADD COLUMN IF NOT EXISTS buttons jsonb NOT NULL DEFAULT '[]'::jsonb;