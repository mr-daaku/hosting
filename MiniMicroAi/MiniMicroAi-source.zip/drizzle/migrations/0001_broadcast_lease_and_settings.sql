
ALTER TABLE public.broadcasts ADD COLUMN lease_until timestamptz;
INSERT INTO public.app_settings(key, value) VALUES ('webapp_url', '""'), ('bot_username', '""') ON CONFLICT DO NOTHING;

CREATE OR REPLACE FUNCTION public.lease_broadcast(p_id bigint)
RETURNS SETOF public.broadcasts LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  UPDATE broadcasts SET lease_until = now() + interval '50 seconds'
   WHERE id = p_id AND status = 'running' AND (lease_until IS NULL OR lease_until < now())
  RETURNING *;
$$;
REVOKE ALL ON FUNCTION public.lease_broadcast(bigint) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.lease_broadcast(bigint) TO service_role;
