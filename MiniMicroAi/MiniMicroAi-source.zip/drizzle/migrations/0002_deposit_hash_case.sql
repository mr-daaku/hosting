
CREATE OR REPLACE FUNCTION public.credit_deposit(p_user bigint, p_chain text, p_asset text, p_tx text, p_log int, p_amount numeric, p_usd numeric, p_to text, p_min_usd numeric)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_id bigint; v_bal numeric; v_status text; v_first boolean; v_ref bigint;
BEGIN
  IF p_amount <= 0 OR p_usd < 0 THEN RETURN 'invalid'; END IF;
  v_status := CASE WHEN p_usd >= p_min_usd THEN 'credited' ELSE 'below_min' END;
  INSERT INTO deposits(user_id, chain, asset, tx_hash, log_index, amount, usd_value, to_address, status)
  VALUES (p_user, p_chain, p_asset, p_tx, p_log, p_amount, round(p_usd, 8), p_to, v_status)
  ON CONFLICT (chain, tx_hash, log_index) DO NOTHING RETURNING id INTO v_id;
  IF v_id IS NULL THEN RETURN 'duplicate'; END IF;
  IF v_status <> 'credited' THEN RETURN 'below_min'; END IF;
  SELECT total_deposit = 0, referred_by INTO v_first, v_ref FROM app_users WHERE id = p_user FOR UPDATE;
  UPDATE app_users SET usdt_balance = usdt_balance + round(p_usd, 8), total_deposit = total_deposit + round(p_usd, 8)
   WHERE id = p_user RETURNING usdt_balance INTO v_bal;
  INSERT INTO ledger(user_id, kind, amount, balance_after, ref, note)
  VALUES (p_user, 'deposit', round(p_usd, 8), v_bal, 'dep:' || v_id, p_chain || ' ' || p_asset);
  IF v_first AND v_ref IS NOT NULL THEN
    INSERT INTO gift_boxes(user_id, referred_id) VALUES (v_ref, p_user) ON CONFLICT (referred_id) DO NOTHING;
  END IF;
  RETURN 'credited';
END $$;
REVOKE ALL ON FUNCTION public.credit_deposit(bigint,text,text,text,int,numeric,numeric,text,numeric) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.credit_deposit(bigint,text,text,text,int,numeric,numeric,text,numeric) TO service_role;
