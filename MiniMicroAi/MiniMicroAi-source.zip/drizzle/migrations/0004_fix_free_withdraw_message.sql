CREATE OR REPLACE FUNCTION public.request_withdrawal_capped(p_user bigint, p_amount numeric, p_fee numeric, p_address text, p_key text, p_free_cap numeric)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE u app_users%ROWTYPE; v_id bigint; v_used numeric;
BEGIN
  SELECT id INTO v_id FROM withdrawals WHERE idempotency_key = p_key;
  IF v_id IS NOT NULL THEN RETURN jsonb_build_object('id', v_id, 'duplicate', true); END IF;
  SELECT * INTO u FROM app_users WHERE id = p_user FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('error','User not found'); END IF;
  IF u.total_deposit <= 0 THEN
    SELECT coalesce(sum(amount),0) INTO v_used FROM withdrawals WHERE user_id = p_user AND status IN ('pending','processing','paid');
    IF v_used + p_amount > p_free_cap THEN
      RETURN jsonb_build_object('error', 'Without a deposit you can withdraw up to ' || trim_scale(p_free_cap)::text || ' USDT in total. Make a deposit to withdraw more.');
    END IF;
  END IF;
  RETURN public.request_withdrawal(p_user, p_amount, p_fee, p_address, p_key);
END $$;
REVOKE ALL ON FUNCTION public.request_withdrawal_capped(bigint,numeric,numeric,text,text,numeric) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.request_withdrawal_capped(bigint,numeric,numeric,text,text,numeric) TO service_role;