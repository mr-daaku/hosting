
CREATE TABLE public.app_users (
  id bigint PRIMARY KEY,
  username text,
  first_name text,
  wallet_index bigint GENERATED ALWAYS AS IDENTITY (START WITH 1) UNIQUE,
  referred_by bigint,
  usdt_balance numeric(30,8) NOT NULL DEFAULT 0 CHECK (usdt_balance >= 0),
  points integer NOT NULL DEFAULT 0 CHECK (points >= 0),
  device_hash text,
  ip_hash text,
  withdraw_blocked boolean NOT NULL DEFAULT false,
  banned boolean NOT NULL DEFAULT false,
  total_deposit numeric(30,8) NOT NULL DEFAULT 0,
  total_withdraw numeric(30,8) NOT NULL DEFAULT 0,
  watch_until timestamptz,
  last_check_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_seen timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX app_users_device_idx ON public.app_users(device_hash);
CREATE INDEX app_users_watch_idx ON public.app_users(watch_until);
CREATE INDEX app_users_ref_idx ON public.app_users(referred_by);

CREATE TABLE public.ledger (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id bigint NOT NULL,
  kind text NOT NULL,
  amount numeric(30,8) NOT NULL,
  balance_after numeric(30,8) NOT NULL,
  ref text NOT NULL UNIQUE,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ledger_user_idx ON public.ledger(user_id, id DESC);

CREATE TABLE public.deposits (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id bigint NOT NULL,
  chain text NOT NULL,
  asset text NOT NULL,
  tx_hash text NOT NULL,
  log_index integer NOT NULL DEFAULT 0,
  amount numeric(38,18) NOT NULL CHECK (amount > 0),
  usd_value numeric(30,8) NOT NULL DEFAULT 0,
  to_address text NOT NULL,
  status text NOT NULL DEFAULT 'credited',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (chain, tx_hash, log_index)
);
CREATE INDEX deposits_user_idx ON public.deposits(user_id, id DESC);

CREATE TABLE public.withdrawals (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id bigint NOT NULL,
  amount numeric(30,8) NOT NULL CHECK (amount > 0),
  fee numeric(30,8) NOT NULL DEFAULT 0,
  address text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  tx_hash text,
  reject_reason text,
  idempotency_key text NOT NULL UNIQUE,
  processed_by bigint,
  created_at timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz
);
CREATE INDEX withdrawals_status_idx ON public.withdrawals(status, id);
CREATE INDEX withdrawals_user_idx ON public.withdrawals(user_id, id DESC);
CREATE UNIQUE INDEX withdrawals_one_open ON public.withdrawals(user_id) WHERE status IN ('pending','processing');

CREATE TABLE public.gift_boxes (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id bigint NOT NULL,
  referred_id bigint NOT NULL UNIQUE,
  points integer,
  opened_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX gift_user_idx ON public.gift_boxes(user_id);

CREATE TABLE public.tasks (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  title text NOT NULL,
  url text NOT NULL,
  reward_points integer NOT NULL DEFAULT 1 CHECK (reward_points >= 0),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.task_completions (
  user_id bigint NOT NULL,
  task_id bigint NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, task_id)
);

CREATE TABLE public.app_settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO public.app_settings(key, value) VALUES
 ('min_deposit_usd', '2'),
 ('min_withdraw_usd', '1'),
 ('withdraw_fee_usd', '0.5'),
 ('min_account_age_minutes', '60'),
 ('auto_pay_enabled', 'false'),
 ('auto_pay_max_usd', '20'),
 ('auto_pay_daily_limit_usd', '200'),
 ('gift_min', '2'),
 ('gift_max', '10'),
 ('withdraw_enabled', 'true'),
 ('deposit_enabled', 'true'),
 ('channel_url', '""'),
 ('support_bot_username', '""'),
 ('maintenance', 'false');

CREATE TABLE public.admin_logs (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  admin_id bigint NOT NULL,
  action text NOT NULL,
  details jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.broadcasts (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  admin_id bigint NOT NULL,
  text text NOT NULL,
  target text NOT NULL,
  target_ids bigint[],
  status text NOT NULL DEFAULT 'running',
  cursor bigint NOT NULL DEFAULT 0,
  total integer NOT NULL DEFAULT 0,
  sent integer NOT NULL DEFAULT 0,
  failed integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz
);

CREATE TABLE public.support_messages (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id bigint NOT NULL,
  direction text NOT NULL,
  text text,
  admin_chat_id bigint,
  admin_message_id bigint,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX support_map_idx ON public.support_messages(admin_chat_id, admin_message_id);

CREATE TABLE public.price_cache (
  asset text PRIMARY KEY,
  usd numeric(30,10) NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['app_users','ledger','deposits','withdrawals','gift_boxes','tasks','task_completions','app_settings','admin_logs','broadcasts','support_messages','price_cache'] LOOP
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
  END LOOP;
END $$;

-- Credit a verified on-chain deposit exactly once
CREATE OR REPLACE FUNCTION public.credit_deposit(p_user bigint, p_chain text, p_asset text, p_tx text, p_log int, p_amount numeric, p_usd numeric, p_to text, p_min_usd numeric)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_id bigint; v_bal numeric; v_status text; v_first boolean; v_ref bigint;
BEGIN
  IF p_amount <= 0 OR p_usd < 0 THEN RETURN 'invalid'; END IF;
  v_status := CASE WHEN p_usd >= p_min_usd THEN 'credited' ELSE 'below_min' END;
  INSERT INTO deposits(user_id, chain, asset, tx_hash, log_index, amount, usd_value, to_address, status)
  VALUES (p_user, p_chain, p_asset, lower(p_tx), p_log, p_amount, round(p_usd, 8), p_to, v_status)
  ON CONFLICT (chain, tx_hash, log_index) DO NOTHING RETURNING id INTO v_id;
  IF v_id IS NULL THEN RETURN 'duplicate'; END IF;
  IF v_status <> 'credited' THEN RETURN 'below_min'; END IF;
  SELECT total_deposit = 0, referred_by INTO v_first, v_ref FROM app_users WHERE id = p_user FOR UPDATE;
  UPDATE app_users SET usdt_balance = usdt_balance + round(p_usd, 8), total_deposit = total_deposit + round(p_usd, 8)
   WHERE id = p_user RETURNING usdt_balance INTO v_bal;
  INSERT INTO ledger(user_id, kind, amount, balance_after, ref, note)
  VALUES (p_user, 'deposit', round(p_usd, 8), v_bal, 'dep:' || v_id, p_chain || ' ' || p_asset);
  IF v_first AND v_ref IS NOT NULL THEN
    INSERT INTO gift_boxes(user_id, referred_id) VALUES (v_ref, p_user) ON CONFLICT (referred_id) DO NOTHING;
  END IF;
  RETURN 'credited';
END $$;

-- Atomic withdrawal request
CREATE OR REPLACE FUNCTION public.request_withdrawal(p_user bigint, p_amount numeric, p_fee numeric, p_address text, p_key text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE u app_users%ROWTYPE; v_id bigint; v_bal numeric; v_total numeric;
BEGIN
  IF p_amount <= 0 OR p_fee < 0 THEN RETURN jsonb_build_object('error','Invalid amount'); END IF;
  SELECT id INTO v_id FROM withdrawals WHERE idempotency_key = p_key;
  IF v_id IS NOT NULL THEN RETURN jsonb_build_object('id', v_id, 'duplicate', true); END IF;
  SELECT * INTO u FROM app_users WHERE id = p_user FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('error','User not found'); END IF;
  IF u.banned OR u.withdraw_blocked THEN RETURN jsonb_build_object('error','Withdrawals are blocked for this account'); END IF;
  IF EXISTS (SELECT 1 FROM withdrawals WHERE user_id = p_user AND status IN ('pending','processing')) THEN
    RETURN jsonb_build_object('error','You already have a withdrawal in progress');
  END IF;
  v_total := round(p_amount + p_fee, 8);
  IF u.usdt_balance < v_total THEN RETURN jsonb_build_object('error','Insufficient balance'); END IF;
  UPDATE app_users SET usdt_balance = usdt_balance - v_total WHERE id = p_user RETURNING usdt_balance INTO v_bal;
  INSERT INTO withdrawals(user_id, amount, fee, address, idempotency_key) VALUES (p_user, round(p_amount,8), round(p_fee,8), p_address, p_key) RETURNING id INTO v_id;
  INSERT INTO ledger(user_id, kind, amount, balance_after, ref, note) VALUES (p_user, 'withdraw', -v_total, v_bal, 'wd:' || v_id, p_address);
  RETURN jsonb_build_object('id', v_id);
END $$;

-- Claim a pending withdrawal for payment (only one worker can win)
CREATE OR REPLACE FUNCTION public.claim_withdrawal(p_id bigint, p_admin bigint)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE withdrawals SET status = 'processing', processed_by = p_admin WHERE id = p_id AND status = 'pending';
  RETURN FOUND;
END $$;

CREATE OR REPLACE FUNCTION public.finish_withdrawal(p_id bigint, p_tx text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE w withdrawals%ROWTYPE;
BEGIN
  UPDATE withdrawals SET status = 'paid', tx_hash = p_tx, processed_at = now() WHERE id = p_id AND status = 'processing' RETURNING * INTO w;
  IF NOT FOUND THEN RETURN false; END IF;
  UPDATE app_users SET total_withdraw = total_withdraw + w.amount WHERE id = w.user_id;
  RETURN true;
END $$;

-- Reject and refund exactly once
CREATE OR REPLACE FUNCTION public.reject_withdrawal(p_id bigint, p_admin bigint, p_reason text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE w withdrawals%ROWTYPE; v_bal numeric;
BEGIN
  UPDATE withdrawals SET status = 'rejected', reject_reason = p_reason, processed_by = p_admin, processed_at = now()
   WHERE id = p_id AND status IN ('pending','processing') RETURNING * INTO w;
  IF NOT FOUND THEN RETURN false; END IF;
  UPDATE app_users SET usdt_balance = usdt_balance + w.amount + w.fee WHERE id = w.user_id RETURNING usdt_balance INTO v_bal;
  INSERT INTO ledger(user_id, kind, amount, balance_after, ref, note) VALUES (w.user_id, 'refund', w.amount + w.fee, v_bal, 'refund:' || w.id, p_reason);
  RETURN true;
END $$;

-- Return a stuck processing withdrawal to pending (when the send definitely did not happen)
CREATE OR REPLACE FUNCTION public.unclaim_withdrawal(p_id bigint)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE withdrawals SET status = 'pending', processed_by = NULL WHERE id = p_id AND status = 'processing' AND tx_hash IS NULL;
  RETURN FOUND;
END $$;

CREATE OR REPLACE FUNCTION public.open_gift_box(p_user bigint, p_box bigint, p_min int, p_max int)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_pts int;
BEGIN
  v_pts := p_min + floor(random() * (p_max - p_min + 1))::int;
  UPDATE gift_boxes SET points = v_pts, opened_at = now() WHERE id = p_box AND user_id = p_user AND opened_at IS NULL;
  IF NOT FOUND THEN RETURN NULL; END IF;
  UPDATE app_users SET points = points + v_pts WHERE id = p_user;
  RETURN v_pts;
END $$;

CREATE OR REPLACE FUNCTION public.complete_task(p_user bigint, p_task bigint)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_pts int;
BEGIN
  SELECT reward_points INTO v_pts FROM tasks WHERE id = p_task AND active;
  IF NOT FOUND THEN RETURN NULL; END IF;
  INSERT INTO task_completions(user_id, task_id) VALUES (p_user, p_task) ON CONFLICT DO NOTHING;
  IF NOT FOUND THEN RETURN NULL; END IF;
  UPDATE app_users SET points = points + v_pts WHERE id = p_user;
  RETURN v_pts;
END $$;

CREATE OR REPLACE FUNCTION public.admin_adjust_balance(p_user bigint, p_amount numeric, p_admin bigint, p_note text, p_ref text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_bal numeric;
BEGIN
  UPDATE app_users SET usdt_balance = usdt_balance + round(p_amount,8) WHERE id = p_user AND usdt_balance + round(p_amount,8) >= 0 RETURNING usdt_balance INTO v_bal;
  IF NOT FOUND THEN RETURN jsonb_build_object('error','User not found or balance would go negative'); END IF;
  INSERT INTO ledger(user_id, kind, amount, balance_after, ref, note) VALUES (p_user, 'admin', round(p_amount,8), v_bal, p_ref, p_note);
  INSERT INTO admin_logs(admin_id, action, details) VALUES (p_admin, 'adjust_balance', jsonb_build_object('user', p_user, 'amount', p_amount, 'note', p_note));
  RETURN jsonb_build_object('balance', v_bal);
END $$;

CREATE OR REPLACE FUNCTION public.admin_stats()
RETURNS jsonb LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  SELECT jsonb_build_object(
    'users', (SELECT count(*) FROM app_users),
    'users_today', (SELECT count(*) FROM app_users WHERE created_at > now() - interval '1 day'),
    'balance_total', (SELECT coalesce(sum(usdt_balance),0) FROM app_users),
    'deposit_total', (SELECT coalesce(sum(usd_value),0) FROM deposits WHERE status='credited'),
    'deposit_today', (SELECT coalesce(sum(usd_value),0) FROM deposits WHERE status='credited' AND created_at > now() - interval '1 day'),
    'withdraw_paid', (SELECT coalesce(sum(amount),0) FROM withdrawals WHERE status='paid'),
    'withdraw_pending', (SELECT count(*) FROM withdrawals WHERE status IN ('pending','processing')),
    'auto_paid_today', (SELECT coalesce(sum(amount),0) FROM withdrawals WHERE status='paid' AND processed_by = 0 AND processed_at > now() - interval '1 day')
  )
$$;

DO $$ DECLARE f text; BEGIN
  FOREACH f IN ARRAY ARRAY['credit_deposit(bigint,text,text,text,int,numeric,numeric,text,numeric)','request_withdrawal(bigint,numeric,numeric,text,text)','claim_withdrawal(bigint,bigint)','finish_withdrawal(bigint,text)','reject_withdrawal(bigint,bigint,text)','unclaim_withdrawal(bigint)','open_gift_box(bigint,bigint,int,int)','complete_task(bigint,bigint)','admin_adjust_balance(bigint,numeric,bigint,text,text)','admin_stats()'] LOOP
    EXECUTE 'REVOKE ALL ON FUNCTION public.' || f || ' FROM PUBLIC, anon, authenticated';
    EXECUTE 'GRANT EXECUTE ON FUNCTION public.' || f || ' TO service_role';
  END LOOP;
END $$;
