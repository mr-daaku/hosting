ALTER TABLE public.app_users ADD COLUMN IF NOT EXISTS welcome_claimed boolean NOT NULL DEFAULT false;
ALTER TABLE public.tasks ADD COLUMN IF NOT EXISTS reward_type text NOT NULL DEFAULT 'points';
ALTER TABLE public.tasks ADD COLUMN IF NOT EXISTS reward_usdt numeric(30,8) NOT NULL DEFAULT 0;
ALTER TABLE public.tasks ADD CONSTRAINT tasks_reward_type_chk CHECK (reward_type IN ('points','usdt'));
ALTER TABLE public.tasks ADD CONSTRAINT tasks_reward_usdt_chk CHECK (reward_usdt >= 0);

INSERT INTO public.app_settings(key, value) VALUES
 ('welcome_bonus_points', '100'),
 ('free_withdraw_usd', '0.1'),
 ('required_channels', '[]')
ON CONFLICT DO NOTHING;

CREATE INDEX IF NOT EXISTS app_users_created_idx ON public.app_users(created_at DESC);
CREATE INDEX IF NOT EXISTS app_users_username_idx ON public.app_users(lower(username));
CREATE INDEX IF NOT EXISTS tasks_active_idx ON public.tasks(active, id);
CREATE INDEX IF NOT EXISTS deposits_status_created_idx ON public.deposits(status, created_at);
CREATE INDEX IF NOT EXISTS withdrawals_paid_idx ON public.withdrawals(status, processed_at);
CREATE INDEX IF NOT EXISTS gift_user_open_idx ON public.gift_boxes(user_id) WHERE opened_at IS NULL;
CREATE INDEX IF NOT EXISTS admin_logs_id_idx ON public.admin_logs(id DESC);

CREATE OR REPLACE FUNCTION public.claim_welcome(p_user bigint, p_points int)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF p_points <= 0 THEN RETURN NULL; END IF;
  UPDATE app_users SET welcome_claimed = true, points = points + p_points WHERE id = p_user AND NOT welcome_claimed;
  IF NOT FOUND THEN RETURN NULL; END IF;
  RETURN p_points;
END $$;

CREATE OR REPLACE FUNCTION public.admin_adjust_points(p_user bigint, p_points int, p_admin bigint, p_note text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_pts int;
BEGIN
  UPDATE app_users SET points = points + p_points WHERE id = p_user AND points + p_points >= 0 RETURNING points INTO v_pts;
  IF NOT FOUND THEN RETURN jsonb_build_object('error','User not found or points would go negative'); END IF;
  INSERT INTO admin_logs(admin_id, action, details) VALUES (p_admin, 'adjust_points', jsonb_build_object('user', p_user, 'points', p_points, 'note', p_note));
  RETURN jsonb_build_object('points', v_pts);
END $$;

CREATE OR REPLACE FUNCTION public.complete_task_reward(p_user bigint, p_task bigint)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE t tasks%ROWTYPE; v_bal numeric;
BEGIN
  SELECT * INTO t FROM tasks WHERE id = p_task AND active;
  IF NOT FOUND THEN RETURN NULL; END IF;
  INSERT INTO task_completions(user_id, task_id) VALUES (p_user, p_task) ON CONFLICT DO NOTHING;
  IF NOT FOUND THEN RETURN NULL; END IF;
  IF t.reward_type = 'usdt' AND t.reward_usdt > 0 THEN
    UPDATE app_users SET usdt_balance = usdt_balance + t.reward_usdt WHERE id = p_user RETURNING usdt_balance INTO v_bal;
    INSERT INTO ledger(user_id, kind, amount, balance_after, ref, note) VALUES (p_user, 'task', t.reward_usdt, v_bal, 'task:' || p_user || ':' || p_task, t.title);
    RETURN jsonb_build_object('type','usdt','amount', t.reward_usdt);
  END IF;
  UPDATE app_users SET points = points + t.reward_points WHERE id = p_user;
  RETURN jsonb_build_object('type','points','amount', t.reward_points);
END $$;
COMMENT ON FUNCTION public.complete_task(bigint,bigint) IS 'DEPRECATED: replaced by complete_task_reward';

CREATE OR REPLACE FUNCTION public.request_withdrawal_capped(p_user bigint, p_amount numeric, p_fee numeric, p_address text, p_key text, p_free_cap numeric)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE u app_users%ROWTYPE; v_id bigint; v_used numeric;
BEGIN
  SELECT id INTO v_id FROM withdrawals WHERE idempotency_key = p_key;
  IF v_id IS NOT NULL THEN RETURN jsonb_build_object('id', v_id, 'duplicate', true); END IF;
  SELECT * INTO u FROM app_users WHERE id = p_user FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('error','User not found'); END IF;
  IF u.total_deposit <= 0 THEN
    SELECT coalesce(sum(amount),0) INTO v_used FROM withdrawals WHERE user_id = p_user AND status IN ('pending','processing','paid');
    IF v_used + p_amount > p_free_cap THEN
      RETURN jsonb_build_object('error', 'Without a deposit you can withdraw up to ' || trim(to_char(p_free_cap, 'FM999999990.00######')) || ' USDT in total. Make a deposit to withdraw more.');
    END IF;
  END IF;
  RETURN public.request_withdrawal(p_user, p_amount, p_fee, p_address, p_key);
END $$;

REVOKE ALL ON FUNCTION public.claim_welcome(bigint,int) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.admin_adjust_points(bigint,int,bigint,text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.complete_task_reward(bigint,bigint) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.request_withdrawal_capped(bigint,numeric,numeric,text,text,numeric) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_welcome(bigint,int) TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_adjust_points(bigint,int,bigint,text) TO service_role;
GRANT EXECUTE ON FUNCTION public.complete_task_reward(bigint,bigint) TO service_role;
GRANT EXECUTE ON FUNCTION public.request_withdrawal_capped(bigint,numeric,numeric,text,text,numeric) TO service_role;