// Micro Wallet app cache.
// - Built files (/assets/*, images, fonts): served from the phone, downloaded once.
// - Pages: shown from the phone instantly, while the newest version downloads in the background.
//   When a new version arrives, it replaces the old one and old files are deleted.
// - Server calls (/_serverFn, /api) always go to the network.
const PAGES = "mw-pages-v1";
const FILES = "mw-files-v1";

self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (e) => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (![PAGES, FILES].includes(k)) await caches.delete(k);
    await self.clients.claim();
  })());
});

function isFile(url) {
  return url.pathname.startsWith("/assets/") || /\.(?:js|css|png|jpe?g|webp|svg|woff2?|ico)$/.test(url.pathname);
}

async function pruneFiles(html) {
  const keep = new Set([...html.matchAll(/\/assets\/[^"'\s)]+/g)].map((m) => m[0]));
  if (!keep.size) return;
  const c = await caches.open(FILES);
  for (const req of await c.keys()) {
    const p = new URL(req.url).pathname;
    if (p.startsWith("/assets/") && !keep.has(p)) await c.delete(req);
  }
}

async function page(event) {
  const req = event.request;
  const url = new URL(req.url);
  const key = url.origin + url.pathname;
  const c = await caches.open(PAGES);
  const cached = await c.match(key);
  const update = fetch(req).then(async (res) => {
    if (res.ok && res.type === "basic") {
      const text = await res.clone().text();
      const old = cached ? await cached.clone().text() : null;
      await c.put(key, res.clone());
      if (old !== null && old !== text) {
        // New version: drop the other saved pages and old files; they are re-saved on next use.
        for (const r of await c.keys()) if (r.url !== key) await c.delete(r);
        await pruneFiles(text);
      }
    }
    return res;
  });
  if (cached) {
    event.waitUntil(update.catch(() => {}));
    return cached;
  }
  return update;
}

async function file(req) {
  const c = await caches.open(FILES);
  const hit = await c.match(req);
  if (hit) return hit;
  const res = await fetch(req);
  if (res.ok && res.type === "basic") c.put(req, res.clone());
  return res;
}

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith("/_serverFn") || url.pathname.startsWith("/api/") || url.pathname === "/sw.js") return;
  if (req.mode === "navigate") return event.respondWith(page(event));
  if (isFile(url)) return event.respondWith(file(req));
});
