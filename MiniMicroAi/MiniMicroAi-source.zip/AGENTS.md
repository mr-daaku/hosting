<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Architecture rules
- Users sign in only through Telegram Mini App initData, verified server-side in `src/lib/server/core.server.ts`; never trust a user ID sent from the browser. Why: Telegram's signature is the only identity source.
- All tables are service-role only (RLS on, no policies); browser code reaches data solely through `createServerFn` in `src/lib/*.functions.ts`. Why: balances must never be writable from the client.
- Every balance change goes through a SECURITY DEFINER SQL function that locks the user row and writes a ledger row with a unique ref. Why: prevents double credit, double withdrawal and negative balances.
- Deposits are found by scanning each user's derived address on-chain (`chains.server.ts`); the token contract, destination, and confirmations are checked there, and `(chain, tx_hash, log_index)` is unique. Why: a submitted hash is never trusted.
- Deposit addresses are derived from the HD_WALLET secret plus the user's `wallet_index` and are never stored. HD index 0 (EVM) is the hot wallet for BEP-20 payouts.
- App settings and prices are cached in memory for a short time; broadcasts read users in keyset batches with a lease. Why: avoids database load spikes.
- Scheduled work runs through one `/api/public/tick` route (broadcasts, watched deposit scans, auto pay). Why: a single low-frequency job instead of many pollers.
- Required join channels live in the cached `required_channels` setting; membership is checked with getChatMember and only passing results are cached per instance, and a channel the bot cannot check never locks users out. Why: avoids Bot API calls on every open without blocking everyone on a misconfigured channel.
- Telegram photos (welcome, invite) are files in `public/` addressed through `publicFile()` from the `webapp_url` setting. Why: Telegram needs an absolute public URL.
- The published app registers `public/sw.js` (via `src/lib/app-cache.ts`) to keep built files on the phone and refresh pages in the background; it is never registered in the editor preview and never caches `/_serverFn` or `/api`. Why: fast reopen without stale server calls.
- Coin prices come from Binance's ticker (CoinGecko fallback, stored prices under 1 hour as last resort) through `getPrices()`. Why: one live source for deposit crediting and the shown rate.
- Telegram photos sent often (/start banner, broadcast images) are sent by Telegram file id after the first upload. Why: sending by URL makes Telegram re-download the image and slows replies.
