import { createFileRoute } from "@tanstack/react-router";
import { Tap } from "@/components/app/Tap";
import { ShieldCheck, Download, Upload, History, Layers, Gift, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useApp } from "@/components/app/AppContext";
import { ChannelCard, InviteButtons, Page, ProfileHeader, SectionTitle, fmt } from "@/components/app/Bits";
import wallet from "@/assets/wallet.webp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Micro Wallet - Home" },
      { name: "description", content: "Your USDT balance, deposits and withdrawals in one Telegram wallet." },
      { property: "og:title", content: "Micro Wallet - Home" },
      { property: "og:description", content: "Your USDT balance, deposits and withdrawals in one Telegram wallet." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

const NETS = ["BNB", "ETH", "TRON", "SOL", "TON", "BTC"];

function Home() {
  const { me } = useApp();
  const [whole, dec] = fmt(me.balance, 8).split(".");
  return (
    <Page>
      <ProfileHeader />
      <ChannelCard />

      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-lg font-extrabold">
            <ShieldCheck className="h-5 w-5 text-success" /> Your USDT balance
          </div>
          <span className="rounded-full border border-success/40 bg-success/10 px-2.5 py-1 text-xs font-bold text-success">Withdrawable</span>
        </div>
        <div className="font-display text-[2.6rem] font-extrabold leading-none tracking-tight">
          {whole}<span className="text-foreground/60">.{dec}</span>
        </div>
        <div className="grid grid-cols-2 gap-3 pt-1">
          <Button asChild variant="ghostline" size="xl"><Tap to="/wallet"><Download /> Deposit USDT</Tap></Button>
          <Button asChild variant="hero" size="xl"><Tap to="/wallet/withdraw"><Upload /> Withdraw USDT</Tap></Button>
        </div>
        <Button asChild variant="ghostline" size="xl" className="w-full"><Tap to="/history"><History /> Operation history</Tap></Button>
      </section>

      <Tap to="/wallet" aria-label="Open deposit" className="surface relative block w-full overflow-hidden p-4 text-left active:scale-[0.99] transition-transform">
        <div className="relative z-10 max-w-[62%] space-y-1">
          <div className="text-lg font-extrabold">Deposit on 6 networks</div>
          <p className="text-xs text-muted-foreground">Personal addresses for every network. Stablecoins are credited 1:1, coins at live price.</p>
          <div className="flex flex-wrap gap-1.5 pt-2">
            {NETS.map((n) => (
              <span key={n} className="rounded-md border border-border bg-background/50 px-2 py-0.5 text-[11px] font-bold">{n}</span>
            ))}
          </div>
        </div>
        <img src={wallet} alt="" width={160} height={160} loading="lazy" className="absolute -right-4 top-1/2 h-40 w-40 -translate-y-1/2" />
      </Tap>

      <SectionTitle>Earn by inviting</SectionTitle>
      <div className="grid grid-cols-3 gap-2.5">
        <div className="rounded-2xl bg-violet-grad p-3 text-center">
          <Gift className="mx-auto h-5 w-5" />
          <div className="mt-1 font-display text-lg font-bold">+1</div>
          <div className="text-[11px] leading-tight text-foreground/85">gift box per active friend</div>
        </div>
        <div className="rounded-2xl bg-orange-grad p-3 text-center">
          <Layers className="mx-auto h-5 w-5" />
          <div className="mt-1 font-display text-lg font-bold">{me.settings.giftMin}-{me.settings.giftMax}</div>
          <div className="text-[11px] leading-tight text-foreground/85">points in every box</div>
        </div>
        <div className="rounded-2xl bg-green-grad p-3 text-center text-success-foreground">
          <Users className="mx-auto h-5 w-5" />
          <div className="mt-1 font-display text-lg font-bold">{me.referrals}</div>
          <div className="text-[11px] leading-tight">friends invited</div>
        </div>
      </div>
      <InviteButtons />
    </Page>
  );
}
