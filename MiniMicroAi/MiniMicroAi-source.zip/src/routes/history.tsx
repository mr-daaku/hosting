import { openExternal } from "@/hooks/use-telegram";
import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, ArrowDownLeft, ArrowUpRight, RotateCcw, Settings2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useApp } from "@/components/app/AppContext";
import { Empty, Page, fmt } from "@/components/app/Bits";
import { CoinIcon } from "@/components/app/CoinIcon";
import { getHistory } from "@/lib/api.functions";

export const Route = createFileRoute("/history")({
  head: () => ({
    meta: [
      { title: "Micro Wallet - History" },
      { name: "description", content: "All your deposits, withdrawals and balance changes." },
      { property: "og:title", content: "Micro Wallet - History" },
      { property: "og:description", content: "All your deposits, withdrawals and balance changes." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HistoryPage,
});

const STATUS: Record<string, string> = { pending: "text-primary", processing: "text-primary", paid: "text-success", rejected: "text-destructive", credited: "text-success", below_min: "text-destructive" };

function HistoryPage() {
  const { initData } = useApp();
  const fn = useServerFn(getHistory);
  const q = useQuery({ queryKey: ["history"], queryFn: () => fn({ data: { initData } }) });
  const [tab, setTab] = useState<"all" | "dep" | "wd">("all");
  return (
    <Page>
      <h1 className="text-2xl font-extrabold">Operation history</h1>
      <div className="flex gap-2">
        {([["all", "All"], ["dep", "Deposits"], ["wd", "Withdrawals"]] as const).map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={cn("rounded-full border px-4 py-1.5 text-sm font-bold", tab === k ? "border-primary bg-primary text-primary-foreground" : "border-border")}>{l}</button>
        ))}
      </div>
      {q.isLoading ? <Loader2 className="mx-auto h-6 w-6 animate-spin text-primary" /> : (
        <div className="space-y-2">
          {tab === "all" && (q.data!.ledger.length ? q.data!.ledger.map((l) => (
            <div key={l.id} className="surface flex items-center gap-3 p-3">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-accent">
                {l.kind === "deposit" ? <ArrowDownLeft className="h-4 w-4 text-success" /> : l.kind === "withdraw" ? <ArrowUpRight className="h-4 w-4" /> : l.kind === "refund" ? <RotateCcw className="h-4 w-4" /> : <Settings2 className="h-4 w-4" />}
              </span>
              <div className="flex-1">
                <div className="font-bold capitalize">{l.kind}</div>
                <div className="text-xs text-muted-foreground">{new Date(l.created_at).toLocaleString()}</div>
              </div>
              <span className={cn("font-display font-bold", l.amount >= 0 ? "text-success" : "")}>{l.amount >= 0 ? "+" : ""}{fmt(l.amount)}</span>
            </div>
          )) : <Empty>No operations yet</Empty>)}
          {tab === "dep" && (q.data!.deposits.length ? q.data!.deposits.map((d) => (
            <div key={d.id} className="surface flex items-center gap-3 p-3">
              <CoinIcon sym={d.asset} className="h-9 w-9" />
              <div className="min-w-0 flex-1">
                <div className="font-bold">{d.amount} {d.asset} <span className="text-xs text-muted-foreground">{d.chain}</span></div>
                <div className="truncate font-mono text-[10px] text-muted-foreground">{d.tx_hash}</div>
              </div>
              <div className="text-right">
                <div className="font-display font-bold">{fmt(d.usd_value)}</div>
                <div className={cn("text-[11px] font-bold", STATUS[d.status])}>{d.status === "below_min" ? "Below min" : "Credited"}</div>
              </div>
            </div>
          )) : <Empty>No deposits yet</Empty>)}
          {tab === "wd" && (q.data!.withdrawals.length ? q.data!.withdrawals.map((w) => (
            <div key={w.id} className="surface space-y-1 p-3">
              <div className="flex justify-between"><span className="font-bold">#{w.id} - {fmt(w.amount)} USDT</span><span className={cn("text-sm font-bold capitalize", STATUS[w.status])}>{w.status}</span></div>
              <div className="truncate font-mono text-[11px] text-muted-foreground">{w.address}</div>
              {w.tx_hash && <button type="button" onClick={() => openExternal(`https://bscscan.com/tx/${w.tx_hash}`)} className="text-xs text-primary">View transaction</button>}
              {w.reject_reason && <div className="text-xs text-destructive">{w.reject_reason}</div>}
            </div>
          )) : <Empty>No withdrawals yet</Empty>)}
        </div>
      )}
    </Page>
  );
}
