import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { RefreshCw, AlertTriangle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useApp } from "@/components/app/AppContext";
import { CopyField, fmt } from "@/components/app/Bits";
import { checkMyDeposits, getDepositInfo } from "@/lib/api.functions";
import { haptic } from "@/hooks/use-telegram";
import { CoinIcon } from "@/components/app/CoinIcon";
import { QrCode } from "@/components/app/QrCode";

export const Route = createFileRoute("/wallet/")({ component: Deposit });

function Deposit() {
  const { initData, refresh } = useApp();
  const info = useServerFn(getDepositInfo);
  const check = useServerFn(checkMyDeposits);
  const q = useQuery({ queryKey: ["deposit-info"], queryFn: () => info({ data: { initData } }), staleTime: 60_000, refetchInterval: 60_000 });
  const [chain, setChain] = useState("BSC");
  const [asset, setAsset] = useState("USDT");
  const [busy, setBusy] = useState(false);

  if (q.isLoading) return <div className="grid place-items-center py-16"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>;
  if (q.isError) return <p className="py-8 text-center text-sm text-destructive">{(q.error as Error).message}</p>;
  const d = q.data!;
  const c = d.chains.find((x) => x.chain === chain) ?? d.chains[0]!;
  const a = c.assets.includes(asset as never) ? asset : c.assets[0]!;
  const stable = a === "USDT" || a === "USDC";
  const live = stable ? 1 : (d.prices as Record<string, number>)[a === "GRAM" ? "TON" : a];

  async function runCheck() {
    setBusy(true);
    try {
      const r = await check({ data: { initData, chain: c.chain as never } });
      if (r.waitSeconds) toast(`Please wait ${r.waitSeconds}s before checking again`);
      else if (!r.credited.length) toast("No new confirmed deposits yet. New transfers can take a few minutes.");
      else {
        haptic("success");
        for (const x of r.credited)
          x.status === "credited" ? toast.success(`+${fmt(x.usd)} USDT credited (${x.amount} ${x.asset})`) : toast.error(`${x.amount} ${x.asset} is below the minimum of ${d.minDeposit} USD and was not credited`);
        refresh();
      }
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <div className="mb-2 text-sm font-bold text-muted-foreground">Network</div>
        <div className="grid grid-cols-3 gap-2">
          {d.chains.map((x) => (
            <button key={x.chain} onClick={() => { setChain(x.chain); haptic(); }} className={cn("surface flex items-center gap-2 rounded-xl p-2.5 text-left", chain === x.chain && "border-primary ring-1 ring-primary")}>
              <CoinIcon sym={x.chain} className="h-7 w-7" />
              <span className="min-w-0">
                <span className="block truncate text-xs font-bold">{x.name}</span>
                <span className="block text-[10px] text-muted-foreground">{x.net}</span>
              </span>
            </button>
          ))}
        </div>
      </div>
      <div>
        <div className="mb-2 text-sm font-bold text-muted-foreground">Coin</div>
        <div className="flex flex-wrap gap-2">
          {c.assets.map((s) => (
            <button key={s} onClick={() => setAsset(s)} className={cn("flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm font-bold", a === s ? "border-primary bg-primary text-primary-foreground" : "border-border")}>
              <CoinIcon sym={s} className="h-5 w-5" /> {s}
            </button>
          ))}
        </div>
      </div>
      <div className="surface space-y-3 p-4">
        <div className="flex items-center justify-between">
          <span className="font-bold">Your {a} address on {c.name}</span>
        </div>
        <div className="mx-auto w-fit rounded-xl bg-foreground p-3"><QrCode value={c.address} size={168} /></div>
        <CopyField value={c.address} label="Address" />
        <div className="flex items-center justify-between rounded-xl border border-border bg-background/50 px-3 py-2 text-sm">
          <span className="text-muted-foreground">{stable ? "Fixed rate" : "Live rate"}</span>
          <span className="font-display font-bold">1 {a} = {live ? fmt(live, live < 1 ? 4 : 2) : "..."} USDT</span>
        </div>
        <div className="flex gap-2 rounded-xl border border-primary/30 bg-primary/10 p-3 text-xs">
          <AlertTriangle className="h-4 w-4 shrink-0 text-primary" />
          <span>Send only <b>{a}</b> on <b>{c.name} ({c.net})</b>. Minimum deposit {d.minDeposit} USD. Other tokens or networks are lost. {a === "USDT" || a === "USDC" ? "Credited 1:1 as USDT." : "Credited as USDT at live market price."}</span>
        </div>
      </div>
      <Button variant="hero" size="xl" className="w-full" disabled={busy} onClick={runCheck}>
        {busy ? <Loader2 className="animate-spin" /> : <RefreshCw />} I have sent it, check now
      </Button>
      <p className="text-center text-xs text-muted-foreground">Deposits are also checked automatically for 24 hours after you open this page.</p>
    </div>
  );
}
