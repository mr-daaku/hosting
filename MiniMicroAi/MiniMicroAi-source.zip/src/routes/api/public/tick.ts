import { createFileRoute } from "@tanstack/react-router";
import { authenticateCronRequest } from "@/integrations/supabase/cron-auth";

// Scheduled: sends running broadcasts, scans deposits for users who opened the deposit
// page in the last 24h, and auto-pays eligible pending withdrawals.
export const Route = createFileRoute("/api/public/tick")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const fail = await authenticateCronRequest(request);
        if (fail) return fail;
        const started = Date.now();
        const { db, getSettings } = await import("@/lib/server/core.server");
        const sb = await db();
        const out: Record<string, unknown> = {};
        try {
          const { runActiveBroadcasts } = await import("@/lib/server/broadcast.server");
          await runActiveBroadcasts();
        } catch (e) { out["broadcastError"] = String(e); }
        try {
          const { scanUser } = await import("@/lib/server/chains.server");
          const { data: users } = await sb.from("app_users").select("id,wallet_index").gt("watch_until", new Date().toISOString()).order("last_check_at", { ascending: true, nullsFirst: true }).limit(8);
          let n = 0;
          for (const u of users ?? []) {
            if (Date.now() - started > 20_000) break;
            await sb.from("app_users").update({ last_check_at: new Date().toISOString() }).eq("id", u.id);
            await scanUser(Number(u.id), Number(u.wallet_index));
            n++;
          }
          out["scanned"] = n;
        } catch (e) { out["scanError"] = String(e); }
        try {
          const s = await getSettings();
          if (s.auto_pay_enabled) {
            const { maybeAutoPay } = await import("@/lib/server/payout.server");
            const { data: pend } = await sb.from("withdrawals").select("id,amount").eq("status", "pending").lte("amount", Number(s.auto_pay_max_usd)).order("id").limit(3);
            for (const w of pend ?? []) await maybeAutoPay(Number(w.id), Number(w.amount));
          }
        } catch (e) { out["payError"] = String(e); }
        return Response.json({ ok: true, ...out });
      },
    },
  },
});
