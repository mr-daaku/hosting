import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/bot")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { webhookSecret, safeEqual } = await import("@/lib/server/core.server");
        const got = request.headers.get("x-telegram-bot-api-secret-token") ?? "";
        if (!safeEqual(got, webhookSecret("main"))) return new Response("Unauthorized", { status: 401 });
        const update = await request.json().catch(() => null);
        if (!update) return new Response("ok");
        try {
          const { handleMainUpdate } = await import("@/lib/server/bots.server");
          await handleMainUpdate(update);
        } catch (e) {
          console.error("bot update failed", e);
        }
        return new Response("ok");
      },
    },
  },
});
