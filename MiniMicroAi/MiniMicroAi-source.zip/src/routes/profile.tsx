import { createFileRoute } from "@tanstack/react-router";
import { CalendarDays, Download, Upload, Users, History, FileText, HelpCircle, LifeBuoy, ShieldCheck, Hash } from "lucide-react";
import { useApp } from "@/components/app/AppContext";
import { InviteButtons, MenuRow, Page, ProfileHeader, SectionTitle, StatTile, fmt } from "@/components/app/Bits";
import { openExternal } from "@/hooks/use-telegram";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Micro Wallet - Profile" },
      { name: "description", content: "Your account stats, history, support and legal information." },
      { property: "og:title", content: "Micro Wallet - Profile" },
      { property: "og:description", content: "Your account stats, history, support and legal information." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Profile,
});

function Profile() {
  const { me } = useApp();
  const days = Math.max(1, Math.ceil((Date.now() - new Date(me.createdAt).getTime()) / 86400000));
  return (
    <Page>
      <ProfileHeader />
      <div className="grid grid-cols-3 gap-2.5">
        <StatTile icon={<CalendarDays />} value={days} label="Days in the app" />
        <StatTile icon={<Hash />} value={me.id} label="Your ID" />
        <StatTile icon={<Users />} value={me.referrals} label="Invited" />
        <StatTile icon={<Download />} value={fmt(me.totalDeposit)} label="USDT deposits" />
        <StatTile icon={<Upload />} value={fmt(me.totalWithdraw)} label="USDT withdrawals" />
        <StatTile icon={<ShieldCheck />} value={me.withdrawBlocked ? "Off" : "On"} label="Withdrawals" />
      </div>
      <SectionTitle>Referral program</SectionTitle>
      <InviteButtons />
      <div className="surface">
        <MenuRow icon={<History />} title="Operation history" to="/history" />
        <MenuRow icon={<HelpCircle />} title="Questions and answers" to="/legal" />
        <MenuRow icon={<FileText />} title="Terms and risk notice" to="/legal" />
        <MenuRow icon={<LifeBuoy />} title="Support" sub="Message our team" onClick={() => me.settings.supportBot && openExternal(`https://t.me/${me.settings.supportBot.replace(/^@/, "")}`)} />
        {me.isAdmin && <MenuRow icon={<ShieldCheck />} title="Admin panel" sub="Only visible to admins" to="/admin" />}
      </div>
    </Page>
  );
}
