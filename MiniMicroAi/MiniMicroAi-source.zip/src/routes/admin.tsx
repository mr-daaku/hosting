import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Tap } from "@/components/app/Tap";
import { ShieldAlert } from "lucide-react";
import { cn } from "@/lib/utils";
import { useApp } from "@/components/app/AppContext";
import { Page } from "@/components/app/Bits";
import { AutoPay, Broadcast, Channels, CheckDeposit, Dashboard, Deposits, Logs, SettingsPanel, Tasks, Users, Withdrawals } from "@/components/admin/Panels";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Micro Wallet - Admin" },
      { name: "description", content: "Admin panel for users, deposits, withdrawals, broadcasts and settings." },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: "Micro Wallet - Admin" },
      { property: "og:description", content: "Admin panel for users, deposits, withdrawals, broadcasts and settings." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Admin,
});

const TABS = [
  ["dashboard", "Dashboard", Dashboard],
  ["users", "Users", Users],
  ["withdrawals", "Withdrawals", Withdrawals],
  ["deposits", "Deposits", Deposits],
  ["autopay", "Auto pay", AutoPay],
  ["check", "Check deposit", CheckDeposit],
  ["settings", "Settings", SettingsPanel],
  ["broadcast", "Broadcast", Broadcast],
  ["tasks", "Tasks", Tasks],
  ["channels", "Join channels", Channels],
  ["logs", "Logs", Logs],
] as const;

function Admin() {
  const { me } = useApp();
  const [tab, setTab] = useState<(typeof TABS)[number][0]>("dashboard");
  if (!me.isAdmin)
    return (
      <Page>
        <div className="surface flex flex-col items-center gap-3 p-8 text-center">
          <ShieldAlert className="h-10 w-10 text-destructive" />
          <div className="font-bold">Admins only</div>
          <Tap to="/" className="text-sm text-primary">Back home</Tap>
        </div>
      </Page>
    );
  const Comp = TABS.find((t) => t[0] === tab)![2];
  return (
    <Page>
      <h1 className="text-2xl font-extrabold">Admin panel</h1>
      <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
        {TABS.map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={cn("whitespace-nowrap rounded-full border px-4 py-2 text-sm font-bold", tab === k ? "border-primary bg-primary text-primary-foreground" : "border-border")}>{l}</button>
        ))}
      </div>
      <Comp />
    </Page>
  );
}
