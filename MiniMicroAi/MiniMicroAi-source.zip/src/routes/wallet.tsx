import { createFileRoute, Outlet, useLocation } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import { Tap } from "@/components/app/Tap";
import { Page, ProfileHeader } from "@/components/app/Bits";

export const Route = createFileRoute("/wallet")({
  head: () => ({
    meta: [
      { title: "Micro Wallet - Wallet" },
      { name: "description", content: "Deposit crypto to your personal address or withdraw USDT BEP-20." },
      { property: "og:title", content: "Micro Wallet - Wallet" },
      { property: "og:description", content: "Deposit crypto to your personal address or withdraw USDT BEP-20." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: WalletLayout,
});

function WalletLayout() {
  const { pathname } = useLocation();
  const isW = pathname.startsWith("/wallet/withdraw");
  return (
    <Page>
      <ProfileHeader />
      <div className="surface grid grid-cols-2 gap-1 rounded-2xl p-1">
        <Tap to="/wallet" className={cn("rounded-xl py-3 text-center font-bold", !isW ? "bg-primary text-primary-foreground" : "text-muted-foreground")}>Deposit</Tap>
        <Tap to="/wallet/withdraw" className={cn("rounded-xl py-3 text-center font-bold", isW ? "bg-primary text-primary-foreground" : "text-muted-foreground")}>Withdraw</Tap>
      </div>
      <Outlet />
    </Page>
  );
}
