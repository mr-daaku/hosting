import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Tap } from "@/components/app/Tap";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Upload, Info, ShieldAlert } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useApp } from "@/components/app/AppContext";
import { fmt } from "@/components/app/Bits";
import { CoinIcon } from "@/components/app/CoinIcon";
import { requestWithdraw } from "@/lib/api.functions";
import { haptic } from "@/hooks/use-telegram";

export const Route = createFileRoute("/wallet/withdraw")({ component: Withdraw });

function Withdraw() {
  const { me, initData, refresh } = useApp();
  const send = useServerFn(requestWithdraw);
  const [amount, setAmount] = useState("");
  const [address, setAddress] = useState("");
  const [busy, setBusy] = useState(false);
  // One idempotency key per form attempt: double taps create one withdrawal only
  const [key, setKey] = useState(() => crypto.randomUUID());
  const free = me.freeWithdraw;
  const fee = free ? 0 : me.settings.withdrawFee;
  const freeLeft = free ? Math.max(0, free.cap - free.used) : Infinity;
  const max = Math.max(0, Math.floor(Math.min(me.balance - fee, freeLeft) * 100) / 100);
  const minAmount = free ? Math.min(me.settings.minWithdraw, free.cap) : me.settings.minWithdraw;
  const ageLeft = useMemo(() => {
    const mins = (Date.now() - new Date(me.createdAt).getTime()) / 60000;
    return Math.max(0, Math.ceil(me.settings.minAgeMinutes - mins));
  }, [me]);
  const n = Number(amount);
  const valid = n > 0 && n >= minAmount && n <= max && /^0x[a-fA-F0-9]{40}$/.test(address.trim());

  async function submit() {
    if (busy || !valid) return;
    setBusy(true);
    try {
      const r = await send({ data: { initData, amount: n, address: address.trim(), key } });
      if ("error" in r && r.error) { toast.error(r.error); haptic("error"); return; }
      haptic("success");
      toast.success(r.status === "paid" ? "Withdrawal sent to your wallet" : "Withdrawal request created. It will be processed soon.");
      setAmount("");
      setKey(crypto.randomUUID());
      refresh();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="surface flex items-center gap-3 p-4">
        <CoinIcon sym="USDT" className="h-10 w-10" />
        <div className="flex-1">
          <div className="font-bold">USDT</div>
          <div className="text-xs text-muted-foreground">BNB Smart Chain (BEP-20)</div>
        </div>
        <div className="text-right">
          <div className="font-display text-lg font-bold">{fmt(me.balance)}</div>
          <div className="text-xs text-muted-foreground">available</div>
        </div>
      </div>

      {me.withdrawBlocked && (
        <div className="flex gap-2 rounded-xl border border-destructive/40 bg-destructive/10 p-3 text-sm">
          <ShieldAlert className="h-5 w-5 shrink-0 text-destructive" /> Withdrawals are disabled on this account because more than one account was used on this device. Contact support if this is a mistake.
        </div>
      )}
      {!me.withdrawBlocked && ageLeft > 0 && (
        <div className="flex gap-2 rounded-xl border border-primary/30 bg-primary/10 p-3 text-sm">
          <Info className="h-5 w-5 shrink-0 text-primary" /> New accounts can withdraw after {me.settings.minAgeMinutes} minutes. About {ageLeft} min left.
        </div>
      )}

      <label className="block space-y-2">
        <span className="text-sm font-bold text-muted-foreground">BEP-20 address</span>
        <Input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="0x..." className="h-12 rounded-xl font-mono text-sm" autoComplete="off" spellCheck={false} />
      </label>
      <label className="block space-y-2">
        <span className="flex justify-between text-sm font-bold text-muted-foreground">
          <span>Amount (USDT)</span>
          <button type="button" className="text-primary" onClick={() => setAmount(String(max))}>Max {fmt(max)}</button>
        </span>
        <Input value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))} inputMode="decimal" placeholder={`Min ${minAmount}`} className="h-12 rounded-xl font-display text-lg" />
      </label>
      <div className="surface space-y-1.5 p-4 text-sm">
        <Row k="Network fee" v={`${fmt(fee)} USDT`} />
        <Row k="You receive" v={`${fmt(n > 0 ? n : 0)} USDT`} />
        <Row k="Total deducted" v={`${fmt(n > 0 ? n + fee : 0)} USDT`} />
      </div>
      <Button variant="hero" size="xl" className="w-full" disabled={!valid || busy || me.withdrawBlocked || ageLeft > 0} onClick={submit}>
        {busy ? <Loader2 className="animate-spin" /> : <Upload />} Withdraw USDT
      </Button>
      <p className="text-center text-xs text-muted-foreground">One withdrawal at a time. Track it in <Tap to="/history" className="text-primary">operation history</Tap>.</p>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between"><span className="text-muted-foreground">{k}</span><span className="font-bold">{v}</span></div>
  );
}
