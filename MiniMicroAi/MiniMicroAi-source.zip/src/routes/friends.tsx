import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Users, Gift, Link2, Loader2 } from "lucide-react";
import { useApp } from "@/components/app/AppContext";
import { Empty, InviteButtons, Page, ProfileHeader, SectionTitle, StatTile } from "@/components/app/Bits";
import { getFriends } from "@/lib/api.functions";
import friendsImg from "@/assets/friends.webp";

export const Route = createFileRoute("/friends")({
  head: () => ({
    meta: [
      { title: "Micro Wallet - Friends" },
      { name: "description", content: "Invite friends with your personal link and earn gift boxes." },
      { property: "og:title", content: "Micro Wallet - Friends" },
      { property: "og:description", content: "Invite friends with your personal link and earn gift boxes." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Friends,
});

function Friends() {
  const { me, initData } = useApp();
  const fn = useServerFn(getFriends);
  const q = useQuery({ queryKey: ["friends"], queryFn: () => fn({ data: { initData } }) });
  const gifts = (q.data?.gifts ?? []).filter((g) => !g.daily_day);
  const pts = gifts.reduce((a, g) => a + (g.points ?? 0), 0);
  return (
    <Page>
      <ProfileHeader />
      <section className="relative">
        <h1 className="max-w-[60%] pt-2 text-[1.7rem] font-extrabold leading-tight">
          Invite friends, get <span className="text-primary">gift boxes</span> with up to <span className="text-primary">{me.settings.giftMax}</span> points
        </h1>
        <img src={friendsImg} alt="" width={170} height={170} className="absolute -right-3 -top-1 h-40 w-40" />
      </section>
      <InviteButtons />
      <div className="grid grid-cols-3 gap-2.5">
        <StatTile icon={<Users />} value={me.referrals} label="Invited" />
        <StatTile icon={<Gift />} value={gifts.length} label="Gift boxes" />
        <StatTile icon={<Link2 />} value={pts} label="Points earned" />
      </div>
      <SectionTitle right={<span className="text-sm text-muted-foreground">{q.data?.friends.length ?? 0}</span>}>My friends</SectionTitle>
      {q.isLoading ? <Loader2 className="mx-auto h-5 w-5 animate-spin text-primary" /> : !q.data?.friends.length ? (
        <Empty>No friends yet. Share your link to start.</Empty>
      ) : (
        <div className="surface divide-y divide-border">
          {q.data.friends.map((f, i) => (
            <div key={i} className="flex items-center gap-3 px-4 py-3">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-accent font-bold">{f.name.slice(0, 1).toUpperCase()}</span>
              <div className="flex-1">
                <div className="font-bold">{f.name}</div>
                <div className="text-xs text-muted-foreground">Joined {new Date(f.joined).toLocaleDateString()}</div>
              </div>
              <span className={f.active ? "text-xs font-bold text-success" : "text-xs text-muted-foreground"}>{f.active ? "Active" : "No deposit yet"}</span>
            </div>
          ))}
        </div>
      )}
    </Page>
  );
}
