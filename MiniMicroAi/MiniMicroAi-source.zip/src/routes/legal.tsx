import { createFileRoute } from "@tanstack/react-router";
import { Tap } from "@/components/app/Tap";
import logo from "@/assets/logo.webp";

export const Route = createFileRoute("/legal")({
  head: () => ({
    meta: [
      { title: "Micro Wallet - Terms, FAQ and risk notice" },
      { name: "description", content: "How Micro Wallet works, its rules, fees and the risks of using crypto." },
      { property: "og:title", content: "Micro Wallet - Terms, FAQ and risk notice" },
      { property: "og:description", content: "How Micro Wallet works, its rules, fees and the risks of using crypto." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Legal,
});

const SECTIONS: [string, string][] = [
  ["What is Micro Wallet?", "A custodial USDT wallet inside Telegram. You get personal deposit addresses on BNB Smart Chain, Ethereum, TRON, Solana, TON and Bitcoin. Deposits are converted to a USDT balance that you can withdraw as USDT (BEP-20)."],
  ["Does the app pay interest or returns?", "No. Your balance only changes through your own deposits, withdrawals, refunds and corrections by support. Points from gift boxes and tasks are rewards inside the app and are not money and cannot be withdrawn."],
  ["How are deposits credited?", "Stablecoins (USDT, USDC) are credited 1:1. Other coins are converted at the market price at the moment the deposit is confirmed on the blockchain. Deposits below the minimum are not credited. Only the listed tokens and networks are supported; other tokens sent to your address can be lost."],
  ["Withdrawals", "Withdrawals are paid in USDT on BNB Smart Chain (BEP-20) to the address you enter. A network fee is shown before you confirm. Only one withdrawal can be in progress at a time. New accounts must wait a short period before their first withdrawal."],
  ["Multiple accounts", "Using several Telegram accounts on one device is allowed for browsing, but withdrawals are disabled on the extra accounts to protect other users."],
  ["Custody and risk", "We hold the funds you deposit on your behalf. Crypto prices are volatile, blockchain transfers cannot be reversed and services can fail. Only deposit what you can afford to lose and never send funds to an address you did not copy from this app."],
  ["Privacy", "We store your Telegram ID, name, username, balances and transaction history to run the service. We never ask for your seed phrase or passwords."],
  ["Support", "Message the support bot from the Profile page. We will never contact you first asking for funds."],
];

function Legal() {
  return (
    <main className="mx-auto max-w-md space-y-4 px-4 py-6">
      <div className="flex items-center gap-3">
        <img src={logo} alt="Micro Wallet" width={48} height={48} className="h-12 w-12" />
        <h1 className="text-2xl font-extrabold">Terms, FAQ and risk notice</h1>
      </div>
      {SECTIONS.map(([t, b]) => (
        <section key={t} className="surface space-y-1.5 p-4">
          <h2 className="font-bold">{t}</h2>
          <p className="text-sm text-muted-foreground">{b}</p>
        </section>
      ))}
      <Tap to="/profile" className="block text-center text-sm font-bold text-primary">Back to the app</Tap>
    </main>
  );
}
