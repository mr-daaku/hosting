import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Gift, UserPlus, CheckCircle2, ExternalLink, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useApp } from "@/components/app/AppContext";
import { Empty, InviteButtons, Page, ProfileHeader, SectionTitle } from "@/components/app/Bits";
import { completeTask, getFriends, getTasks, openGift } from "@/lib/api.functions";
import { haptic, openExternal } from "@/hooks/use-telegram";
import giftImg from "@/assets/gift-box.webp";

export const Route = createFileRoute("/gifts")({
  head: () => ({
    meta: [
      { title: "Micro Wallet - Gifts" },
      { name: "description", content: "Open gift boxes from invited friends and complete tasks for points." },
      { property: "og:title", content: "Micro Wallet - Gifts" },
      { property: "og:description", content: "Open gift boxes from invited friends and complete tasks for points." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Gifts,
});

function Gifts() {
  const { me, initData, refresh } = useApp();
  const qc = useQueryClient();
  const friendsFn = useServerFn(getFriends);
  const tasksFn = useServerFn(getTasks);
  const openFn = useServerFn(openGift);
  const doTask = useServerFn(completeTask);
  const f = useQuery({ queryKey: ["friends"], queryFn: () => friendsFn({ data: { initData } }) });
  const t = useQuery({ queryKey: ["tasks"], queryFn: () => tasksFn({ data: { initData } }) });
  const [opening, setOpening] = useState<number | null>(null);
  const [opened, setOpened] = useState<{ id: number; pts: number } | null>(null);
  const [visited, setVisited] = useState<Record<number, boolean>>({});
  const boxes = f.data?.gifts ?? [];
  const closed = boxes.filter((b) => !b.opened_at);

  async function open(id: number) {
    setOpening(id);
    haptic();
    try {
      const r = await openFn({ data: { initData, boxId: id } });
      if ("error" in r) toast.error(r.error);
      else {
        setTimeout(() => { setOpened({ id, pts: r.points }); haptic("success"); }, 700);
        refresh();
        qc.invalidateQueries({ queryKey: ["friends"] });
      }
    } finally {
      setTimeout(() => setOpening(null), 800);
    }
  }

  return (
    <Page>
      <ProfileHeader />
      <section className="relative pt-2">
        <div className="max-w-[58%] space-y-2">
          <h1 className="text-[1.7rem] font-extrabold leading-tight">Gift boxes for every friend</h1>
          <p className="text-sm text-muted-foreground">When a friend you invited makes their first deposit, you get a gift box with {me.settings.giftMin} to {me.settings.giftMax} points. Plus one free box every day.</p>
        </div>
        <img src={giftImg} alt="" width={180} height={180} className={cn("absolute -right-2 -top-2 h-44 w-44", opening && "animate-shake")} />
      </section>

      {opened && (
        <div className="surface animate-pop border-primary p-5 text-center glow">
          <div className="text-sm text-muted-foreground">You got</div>
          <div className="font-display text-4xl font-extrabold text-primary">+{opened.pts}</div>
          <div className="text-sm">points</div>
          <Button variant="ghostline" className="mt-3" onClick={() => setOpened(null)}>Nice</Button>
        </div>
      )}

      <div className="surface space-y-3 p-4">
        <div className="flex items-center gap-2 font-bold"><UserPlus className="h-5 w-5 text-primary" /> Invite a friend to get +1 gift</div>
        <InviteButtons />
      </div>

      <SectionTitle right={<span className="text-sm text-muted-foreground">{closed.length} closed</span>}>Your boxes</SectionTitle>
      {f.isLoading ? <Loader2 className="mx-auto h-5 w-5 animate-spin text-primary" /> : boxes.length === 0 ? (
        <Empty>No gift boxes yet. Come back daily or invite friends to earn them.</Empty>
      ) : (
        <div className="grid grid-cols-4 gap-2.5">
          {boxes.map((b) => (
            <button
              key={b.id}
              disabled={!!b.opened_at || opening !== null}
              onClick={() => open(Number(b.id))}
              className={cn("surface flex aspect-square flex-col items-center justify-center gap-1 rounded-2xl", !b.opened_at ? "border-primary/60" : "opacity-60", opening === b.id && "animate-shake")}
            >
              {b.opened_at ? <CheckCircle2 className="h-6 w-6 text-success" /> : <Gift className="h-7 w-7 text-primary" />}
              <span className="text-xs font-bold">{b.opened_at ? `+${b.points}` : "Open"}</span>
              {b.daily_day && <span className="text-[10px] text-muted-foreground">Daily</span>}
            </button>
          ))}
        </div>
      )}

      <SectionTitle>Tasks</SectionTitle>
      {t.isLoading ? <Loader2 className="mx-auto h-5 w-5 animate-spin text-primary" /> : !t.data?.length ? (
        <Empty>No tasks available</Empty>
      ) : (
        <div className="space-y-2.5">
          {t.data.map((task) => (
            <div key={task.id} className="surface flex items-center gap-3 p-3">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-violet-grad"><ExternalLink className="h-5 w-5" /></span>
              <div className="flex-1">
                <div className="font-bold">{task.title}</div>
                <div className="text-xs text-muted-foreground">{task.reward_type === "usdt" ? `+${task.reward_usdt} USDT` : `+${task.reward_points} points`}</div>
              </div>
              {task.done ? (
                <CheckCircle2 className="h-7 w-7 text-success" />
              ) : !visited[task.id] ? (
                <Button size="sm" variant="hero" onClick={() => { openExternal(task.url); setVisited((v) => ({ ...v, [task.id]: true })); }}>Start</Button>
              ) : (
                <Button size="sm" variant="ghostline" onClick={async () => {
                  const r = await doTask({ data: { initData, taskId: task.id } });
                  if ("error" in r) toast.error(r.error);
                  else { toast.success(r.type === "usdt" ? `+${r.amount} USDT added to your balance` : `+${r.amount} points`); haptic("success"); refresh(); qc.invalidateQueries({ queryKey: ["tasks"] }); }
                }}>Check</Button>
              )}
            </div>
          ))}
        </div>
      )}
    </Page>
  );
}
