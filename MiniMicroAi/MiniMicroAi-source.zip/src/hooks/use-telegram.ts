import { useEffect, useState } from "react";

type TgWebApp = {
  initData: string;
  initDataUnsafe?: { user?: { id: number; first_name?: string; photo_url?: string }; start_param?: string };
  ready: () => void;
  expand: () => void;
  openLink: (url: string) => void;
  openTelegramLink: (url: string) => void;
  HapticFeedback?: { impactOccurred: (s: string) => void; notificationOccurred: (s: string) => void };
  setHeaderColor?: (c: string) => void;
  setBackgroundColor?: (c: string) => void;
  disableVerticalSwipes?: () => void;
  requestFullscreen?: () => void;
  isVersionAtLeast?: (v: string) => boolean;
  platform?: string;
  shareMessage?: (id: string, cb?: (sent: boolean) => void) => void;
};
declare global {
  interface Window {
    Telegram?: { WebApp?: TgWebApp };
  }
}

export function getWebApp(): TgWebApp | null {
  if (typeof window === "undefined") return null;
  return window.Telegram?.WebApp ?? null;
}

/** Returns signed initData once the Telegram script is ready ("" outside Telegram). */
export function useTelegramInit() {
  const [state, setState] = useState<{ ready: boolean; initData: string }>({ ready: false, initData: "" });
  useEffect(() => {
    let tries = 0;
    const tick = () => {
      const wa = getWebApp();
      if (wa) {
        try {
          wa.ready();
          wa.expand();
          wa.setHeaderColor?.("#120f14");
          wa.setBackgroundColor?.("#120f14");
          wa.disableVerticalSwipes?.();
          // Fullscreen on phones (Bot API 8.0+); desktop keeps the normal window.
          const mobile = ["android", "ios"].includes(wa.platform ?? "");
          if (mobile && wa.isVersionAtLeast?.("8.0")) wa.requestFullscreen?.();
        } catch {}
        setState({ ready: true, initData: wa.initData || "" });
        return;
      }
      if (tries++ < 30) setTimeout(tick, 100);
      else setState({ ready: true, initData: "" });
    };
    tick();
  }, []);
  return state;
}

export function deviceId() {
  try {
    let id = localStorage.getItem("mw_device");
    if (!id) {
      id = crypto.randomUUID();
      localStorage.setItem("mw_device", id);
    }
    return id;
  } catch {
    return undefined;
  }
}

export function haptic(kind: "light" | "success" | "error" = "light") {
  const h = getWebApp()?.HapticFeedback;
  if (!h) return;
  if (kind === "light") h.impactOccurred("light");
  else h.notificationOccurred(kind);
}

export function openExternal(url: string) {
  const wa = getWebApp();
  if (wa && /^https:\/\/t\.me\//.test(url)) wa.openTelegramLink(url);
  else if (wa) wa.openLink(url);
  else window.open(url, "_blank", "noopener");
}

/** Blocks right-click and long-press menus so link targets and the app address never show. */
export function useNoContextMenu() {
  useEffect(() => {
    const stop = (e: Event) => {
      const t = e.target as HTMLElement | null;
      if (t?.closest("input, textarea")) return;
      e.preventDefault();
    };
    document.addEventListener("contextmenu", stop);
    document.addEventListener("dragstart", stop);
    return () => {
      document.removeEventListener("contextmenu", stop);
      document.removeEventListener("dragstart", stop);
    };
  }, []);
}
