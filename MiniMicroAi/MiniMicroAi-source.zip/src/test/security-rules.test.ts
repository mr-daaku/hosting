import { describe, expect, it, beforeAll } from "vitest";
import { hmac } from "@noble/hashes/hmac.js";
import { sha256 } from "@noble/hashes/sha2.js";
import { verifyInitData } from "@/lib/server/core.server";
import { units } from "@/lib/server/chains.server";
import { evmAddress, tronAddress, btcAddress, solAddress } from "@/lib/server/wallet.server";

const TOKEN = "123456:TEST_TOKEN";
const enc = new TextEncoder();
const hex = (b: Uint8Array) => Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
function sign(fields: Record<string, string>) {
  const p = new URLSearchParams(fields);
  const dcs = [...p.entries()].sort(([a], [b]) => (a < b ? -1 : 1)).map(([k, v]) => `${k}=${v}`).join("\n");
  p.set("hash", hex(hmac(sha256, hmac(sha256, enc.encode("WebAppData"), enc.encode(TOKEN)), enc.encode(dcs))));
  return p.toString();
}
const now = () => String(Math.floor(Date.now() / 1000));
const MN = "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about";

beforeAll(() => {
  process.env["BOT_TOKEN"] = TOKEN;
});

describe("Telegram login", () => {
  it("accepts correctly signed data", () => {
    expect(verifyInitData(sign({ auth_date: now(), user: JSON.stringify({ id: 42 }) })).user.id).toBe(42);
  });
  it("rejects a changed user ID", () => {
    const s = sign({ auth_date: now(), user: JSON.stringify({ id: 42 }) }).replace("42", "43");
    expect(() => verifyInitData(s)).toThrow();
  });
  it("rejects login data older than 24 hours", () => {
    const old = String(Math.floor(Date.now() / 1000) - 86400 - 60);
    expect(() => verifyInitData(sign({ auth_date: old, user: JSON.stringify({ id: 42 }) }))).toThrow(/expired/);
  });
});

describe("Deposit amounts", () => {
  it("converts 18-decimal BEP-20 USDT without float errors", () => {
    expect(units(2_000000000000000001n, 18)).toBe("2.000000000000000001");
    expect(units(5_000000n, 6)).toBe("5");
  });
});

describe("Wallet addresses from the seed", () => {
  it("match standard wallets for the same index", () => {
    expect(evmAddress(0, MN)).toBe("0x9858EfFD232B4033E47d90003D41EC34EcaEda94");
    expect(tronAddress(0, MN)).toBe("TUEZSdKsoDHQMeZwihtdoBiN46zxhGWYdH");
    expect(btcAddress(0, MN)).toBe("bc1qcr8te4kr609gcawutmrza0j4xv80jy8z306fyu");
    expect(solAddress(0, MN)).toBe("HAgk14JpMQLgt6rVgv7cBQFJWFto5Dqxi472uT3DKpqk");
  });
  it("gives each user index a different address", () => {
    expect(evmAddress(1, MN)).not.toBe(evmAddress(2, MN));
  });
});
