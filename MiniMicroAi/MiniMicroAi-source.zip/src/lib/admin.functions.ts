import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const init = z.string().min(10).max(4096);
async function admin(initData: string) {
  const m = await import("./server/session.server");
  return m.requireAdmin(initData);
}
async function lib() {
  return import("./server/core.server");
}

export const adminStats = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init }).parse(d))
  .handler(async ({ data }) => {
    await admin(data.initData);
    const { db } = await lib();
    const sb = await db();
    const { data: stats } = await sb.rpc("admin_stats");
    let hot: { address: string; bnb: string; usdt: string } | null = null;
    try {
      const { hotWalletBalances } = await import("./server/payout.server");
      hot = await hotWalletBalances();
    } catch (e) {
      console.error(e);
    }
    return { stats: stats as Record<string, number>, hot };
  });

export const adminUsers = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init, q: z.string().max(64).optional(), page: z.number().int().min(0).max(10000) }).parse(d))
  .handler(async ({ data }) => {
    await admin(data.initData);
    const { db } = await lib();
    let q = (await db()).from("app_users").select("id,username,first_name,wallet_index,usdt_balance,points,total_deposit,total_withdraw,withdraw_blocked,banned,created_at,referred_by", { count: "estimated" });
    const term = (data.q ?? "").trim().replace(/[%,()]/g, "");
    // Nothing loads until the admin searches.
    if (!term) return { rows: [], count: 0 };
    if (term) q = /^\d+$/.test(term) ? q.eq("id", Number(term)) : q.or(`username.ilike.%${term}%,first_name.ilike.%${term}%`);
    const { data: rows, count } = await q.order("created_at", { ascending: false }).range(data.page * 30, data.page * 30 + 29);
    return { rows: (rows ?? []).map((r) => ({ ...r, id: Number(r.id), usdt_balance: Number(r.usdt_balance), total_deposit: Number(r.total_deposit), total_withdraw: Number(r.total_withdraw) })), count: count ?? 0 };
  });

export const adminUserAction = createServerFn({ method: "POST" })
  .inputValidator((d) =>
    z.object({
      initData: init,
      userId: z.number().int().positive(),
      action: z.enum(["ban", "unban", "block_withdraw", "unblock_withdraw", "adjust", "points"]),
      amount: z.number().min(-1_000_000).max(1_000_000).optional(),
      note: z.string().max(200).optional(),
      key: z.string().uuid().optional(),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const adminId = await admin(data.initData);
    const { db, logAdmin } = await lib();
    const sb = await db();
    if (data.action === "adjust") {
      if (!data.amount || !data.key) return { error: "Amount required" };
      const { data: r } = await sb.rpc("admin_adjust_balance", { p_user: data.userId, p_amount: data.amount, p_admin: adminId, p_note: data.note ?? "Admin adjustment", p_ref: `adm:${data.key}` });
      return r as { error?: string; balance?: number };
    }
    if (data.action === "points") {
      if (!data.amount || !Number.isInteger(data.amount)) return { error: "Whole number of points required" };
      const { data: r } = await sb.rpc("admin_adjust_points", { p_user: data.userId, p_points: data.amount, p_admin: adminId, p_note: data.note ?? "Admin points" });
      return r as { error?: string; points?: number };
    }
    const patch =
      data.action === "ban" ? { banned: true } : data.action === "unban" ? { banned: false } : data.action === "block_withdraw" ? { withdraw_blocked: true } : { withdraw_blocked: false };
    await sb.from("app_users").update(patch).eq("id", data.userId);
    await logAdmin(adminId, data.action, { user: data.userId });
    return { ok: true };
  });

export const adminWithdrawals = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init, status: z.enum(["pending", "paid", "rejected"]), page: z.number().int().min(0) }).parse(d))
  .handler(async ({ data }) => {
    await admin(data.initData);
    const { db } = await lib();
    const statuses = data.status === "pending" ? ["pending", "processing"] : [data.status];
    const { data: rows } = await (await db())
      .from("withdrawals").select("*").in("status", statuses).order("id", { ascending: data.status === "pending" }).range(data.page * 30, data.page * 30 + 29);
    return (rows ?? []).map((r) => ({ ...r, id: Number(r.id), user_id: Number(r.user_id), amount: Number(r.amount), fee: Number(r.fee) }));
  });

export const adminWithdrawalAction = createServerFn({ method: "POST" })
  .inputValidator((d) =>
    z.object({
      initData: init,
      id: z.number().int().positive(),
      action: z.enum(["pay", "mark_paid", "reject"]),
      txHash: z.string().regex(/^0x[a-fA-F0-9]{64}$/).optional(),
      reason: z.string().max(200).optional(),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const adminId = await admin(data.initData);
    const { db, logAdmin, tg } = await lib();
    const sb = await db();
    if (data.action === "pay") {
      const { payWithdrawal } = await import("./server/payout.server");
      const r = await payWithdrawal(data.id, adminId);
      await logAdmin(adminId, "withdraw_pay", { id: data.id, ...r });
      return r;
    }
    if (data.action === "mark_paid") {
      if (!data.txHash) return { ok: false, error: "Transaction hash required" };
      const { data: c } = await sb.rpc("claim_withdrawal", { p_id: data.id, p_admin: adminId });
      if (!c) return { ok: false, error: "Not pending" };
      await sb.rpc("finish_withdrawal", { p_id: data.id, p_tx: data.txHash });
      await logAdmin(adminId, "withdraw_mark_paid", { id: data.id, tx: data.txHash });
      return { ok: true };
    }
    const { data: ok } = await sb.rpc("reject_withdrawal", { p_id: data.id, p_admin: adminId, p_reason: data.reason ?? "Rejected" });
    if (!ok) return { ok: false, error: "Already processed" };
    const { data: w } = await sb.from("withdrawals").select("user_id,amount").eq("id", data.id).single();
    if (w) await tg("sendMessage", { chat_id: w.user_id, text: `Your withdrawal of ${w.amount} USDT was rejected and refunded to your balance.${data.reason ? "\nReason: " + data.reason : ""}` }).catch(() => {});
    await logAdmin(adminId, "withdraw_reject", { id: data.id, reason: data.reason });
    return { ok: true };
  });

export const adminDeposits = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init, page: z.number().int().min(0) }).parse(d))
  .handler(async ({ data }) => {
    await admin(data.initData);
    const { db } = await lib();
    const { data: rows } = await (await db()).from("deposits").select("*").order("id", { ascending: false }).range(data.page * 30, data.page * 30 + 29);
    return (rows ?? []).map((r) => ({ ...r, id: Number(r.id), user_id: Number(r.user_id), amount: String(r.amount), usd_value: Number(r.usd_value) }));
  });

export const adminCheckDeposit = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init, query: z.string().min(3).max(120) }).parse(d))
  .handler(async ({ data }) => {
    const adminId = await admin(data.initData);
    const { db, logAdmin } = await lib();
    const sb = await db();
    const q = data.query.trim();
    if (/^\d{1,15}$/.test(q)) {
      const { data: u } = await sb.from("app_users").select("id,wallet_index").eq("id", Number(q)).maybeSingle();
      if (!u) return { error: "User not found" };
      const { scanUser } = await import("./server/chains.server");
      const r = await scanUser(Number(u.id), Number(u.wallet_index));
      await logAdmin(adminId, "check_deposit_user", { user: u.id, credited: r.credited.length });
      const { allAddresses } = await import("./server/wallet.server");
      return { mode: "user", credited: r.credited.map((c) => ({ chain: c.chain, asset: c.asset, amount: c.amount, usd: c.usd, status: c.result })), errors: r.errors, addresses: await allAddresses(Number(u.wallet_index)) };
    }
    const variants = [q, q.toLowerCase()];
    const { data: rows } = await sb.from("deposits").select("*").in("tx_hash", variants);
    return { mode: "tx", rows: (rows ?? []).map((r) => ({ ...r, id: Number(r.id), user_id: Number(r.user_id), amount: String(r.amount), usd_value: Number(r.usd_value) })) };
  });

export const adminGetSettings = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init }).parse(d))
  .handler(async ({ data }) => {
    await admin(data.initData);
    const { getSettings } = await lib();
    return getSettings(true);
  });

const settingsSchema = z.object({
  min_deposit_usd: z.number().min(0).max(100000),
  min_withdraw_usd: z.number().min(0.01).max(100000),
  withdraw_fee_usd: z.number().min(0).max(1000),
  min_account_age_minutes: z.number().int().min(0).max(100000),
  auto_pay_enabled: z.boolean(),
  auto_pay_max_usd: z.number().min(0).max(100000),
  auto_pay_daily_limit_usd: z.number().min(0).max(1000000),
  gift_min: z.number().int().min(0).max(100000),
  gift_max: z.number().int().min(0).max(100000),
  withdraw_enabled: z.boolean(),
  deposit_enabled: z.boolean(),
  channel_url: z.string().max(200),
  support_bot_username: z.string().max(64),
  maintenance: z.boolean(),
  webapp_url: z.string().max(300),
  bot_username: z.string().max(64),
  welcome_bonus_points: z.number().int().min(0).max(1_000_000),
  free_withdraw_usd: z.number().min(0).max(1000),
  required_channels: z.array(z.object({ title: z.string().min(1).max(60), url: z.string().min(2).max(200), chat: z.string().max(64) })).max(20),
}).partial();

export const adminSaveSettings = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init, values: z.record(z.string(), z.unknown()) }).parse(d))
  .handler(async ({ data }) => {
    const adminId = await admin(data.initData);
    const { db, clearSettingsCache, logAdmin, channelChat } = await lib();
    // Validate here so a bad field comes back as a readable message instead of a silent failure.
    const parsed = settingsSchema.safeParse(data.values);
    if (!parsed.success) {
      const i = parsed.error.issues[0];
      return { error: `${String(i?.path[0] ?? "value").replace(/_/g, " ")}: ${i?.message ?? "invalid"}` };
    }
    const v = parsed.data;
    if (v.gift_min != null && v.gift_max != null && v.gift_min > v.gift_max) return { error: "Gift min must be less than max" };
    if (v.required_channels) {
      for (const c of v.required_channels) {
        const chat = c.chat || channelChat(c.url);
        if (!chat) return { error: `Channel "${c.title}": use a link like https://t.me/name or a chat ID` };
        c.chat = chat;
      }
    }
    const rows = Object.entries(v).map(([key, value]) => ({ key, value: value as never, updated_at: new Date().toISOString() }));
    if (!rows.length) return { error: "Nothing to save" };
    const { error } = await (await db()).from("app_settings").upsert(rows, { onConflict: "key" });
    if (error) return { error: "Could not save: " + error.message };
    clearSettingsCache();
    await logAdmin(adminId, "settings", v);
    return { ok: true };
  });

export const adminCreateBroadcast = createServerFn({ method: "POST" })
  .inputValidator((d) =>
    z.object({
      initData: init,
      text: z.string().min(1).max(4000),
      target: z.enum(["all", "single", "multiple"]),
      ids: z.array(z.number().int().positive()).max(5000).optional(),
      photoId: z.string().min(10).max(300).optional(),
      buttons: z
        .array(z.array(z.object({ text: z.string().trim().min(1).max(64), url: z.string().trim().max(512).regex(/^(https:\/\/|tg:\/\/)/, "Button links must start with https://") })).min(1).max(4))
        .max(8)
        .optional(),
    }).refine((x) => !x.photoId || x.text.length <= 1024, { message: "With an image the message can be at most 1024 characters" }).parse(d),
  )
  .handler(async ({ data }) => {
    const adminId = await admin(data.initData);
    const { db, logAdmin } = await lib();
    const sb = await db();
    let total = 0;
    let ids: number[] | null = null;
    if (data.target === "all") {
      const { count } = await sb.from("app_users").select("id", { count: "exact", head: true }).eq("banned", false);
      total = count ?? 0;
    } else {
      ids = [...new Set(data.ids ?? [])];
      if (!ids.length) return { error: "Add at least one user ID" };
      if (data.target === "single") ids = ids.slice(0, 1);
      total = ids.length;
    }
    const { data: b } = await sb.from("broadcasts").insert({ admin_id: adminId, text: data.text, target: data.target, target_ids: ids, total, photo_id: data.photoId ?? null, buttons: (data.buttons ?? []) as never }).select("id").single();
    await logAdmin(adminId, "broadcast", { id: b?.id, target: data.target, total });
    return { id: Number(b!.id) };
  });

/** Uploads a broadcast image once to Telegram (sent to the admin as a preview) and returns its file id. */
export const adminUploadPhoto = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init, dataUrl: z.string().max(8_000_000).regex(/^data:image\/(jpeg|png|webp);base64,/) }).parse(d))
  .handler(async ({ data }) => {
    const adminId = await admin(data.initData);
    const token = process.env["BOT_TOKEN"];
    if (!token) return { error: "Bot is not configured" };
    const [head, b64] = data.dataUrl.split(",");
    const type = /data:(image\/\w+)/.exec(head ?? "")?.[1] ?? "image/jpeg";
    const bytes = Uint8Array.from(atob(b64 ?? ""), (c) => c.charCodeAt(0));
    if (bytes.length > 5_000_000) return { error: "Image is too large (max 5 MB)" };
    const form = new FormData();
    form.append("chat_id", String(adminId));
    form.append("caption", "Broadcast image preview");
    form.append("photo", new Blob([bytes], { type }), "broadcast." + type.split("/")[1]);
    const res = await fetch(`https://api.telegram.org/bot${token}/sendPhoto`, { method: "POST", body: form });
    const j = (await res.json().catch(() => ({}))) as { ok?: boolean; result?: { photo?: { file_id: string }[] }; description?: string };
    const sizes = j.result?.photo;
    const id = sizes?.[sizes.length - 1]?.file_id;
    if (!j.ok || !id) return { error: j.description ?? "Upload failed. Open the bot once so it can message you." };
    return { photoId: id };
  });

export const adminBroadcasts = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init, process: z.number().int().positive().optional() }).parse(d))
  .handler(async ({ data }) => {
    await admin(data.initData);
    const { db } = await lib();
    if (data.process) {
      const { runBroadcastBatch } = await import("./server/broadcast.server");
      await runBroadcastBatch(data.process);
    }
    const { data: rows } = await (await db()).from("broadcasts").select("id,text,target,status,total,sent,failed,created_at,finished_at,photo_id,buttons").order("id", { ascending: false }).limit(20);
    return (rows ?? []).map((r) => ({ ...r, id: Number(r.id) }));
  });

export const adminTasks = createServerFn({ method: "POST" })
  .inputValidator((d) =>
    z.object({
      initData: init,
      op: z.enum(["list", "create", "toggle", "delete"]),
      id: z.number().int().positive().optional(),
      title: z.string().min(1).max(80).optional(),
      url: z.string().url().max(300).optional(),
      reward: z.number().int().min(0).max(100000).optional(),
      rewardType: z.enum(["points", "usdt"]).optional(),
      rewardUsdt: z.number().min(0).max(1000).optional(),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const adminId = await admin(data.initData);
    const { db, logAdmin } = await lib();
    const sb = await db();
    if (data.op === "create" && data.title && data.url) {
      const usdt = data.rewardType === "usdt";
      if (usdt && !(Number(data.rewardUsdt) > 0)) throw new Error("Enter the USDT reward");
      await sb.from("tasks").insert({ title: data.title, url: data.url, reward_type: usdt ? "usdt" : "points", reward_points: usdt ? 0 : data.reward ?? 1, reward_usdt: usdt ? Number(data.rewardUsdt) : 0 });
      await logAdmin(adminId, "task_create", { title: data.title });
    } else if (data.op === "toggle" && data.id) {
      const { data: t } = await sb.from("tasks").select("active").eq("id", data.id).single();
      if (t) await sb.from("tasks").update({ active: !t.active }).eq("id", data.id);
    } else if (data.op === "delete" && data.id) {
      await sb.from("tasks").update({ active: false, title: "[deleted]" }).eq("id", data.id);
    }
    const { data: rows } = await sb.from("tasks").select("*").neq("title", "[deleted]").order("id", { ascending: false });
    return (rows ?? []).map((r) => ({ ...r, id: Number(r.id), reward_usdt: Number(r.reward_usdt) }));
  });

/** Checks that the bot can see membership in a channel (it must be an admin there). */
export const adminTestChannel = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init, url: z.string().min(2).max(200) }).parse(d))
  .handler(async ({ data }) => {
    const adminId = await admin(data.initData);
    const { tg, channelChat } = await lib();
    const chat = channelChat(data.url);
    if (!chat) return { ok: false, error: "Use a link like https://t.me/name or a chat ID" };
    const me = await tg("getMe", {});
    const r = await tg("getChatMember", { chat_id: chat, user_id: me.result?.id ?? 0 });
    const c = await tg("getChat", { chat_id: chat });
    if (!r.ok) return { ok: false, chat, error: r.description ?? "Bot cannot see this channel" };
    if (!["administrator", "creator"].includes(r.result?.status)) return { ok: false, chat, error: "Make the bot an admin of this channel first" };
    void adminId;
    return { ok: true, chat, title: (c.result?.title as string) ?? chat };
  });

export const adminLogs = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init }).parse(d))
  .handler(async ({ data }) => {
    await admin(data.initData);
    const { db } = await lib();
    const { data: rows } = await (await db()).from("admin_logs").select("*").order("id", { ascending: false }).limit(100);
    return (rows ?? []).map((r) => ({ ...r, id: Number(r.id), admin_id: Number(r.admin_id), details: JSON.stringify(r.details) }));
  });

export const adminSetupBots = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init, origin: z.string().url().max(200) }).parse(d))
  .handler(async ({ data }) => {
    const adminId = await admin(data.initData);
    const { tg, webhookSecret, db, clearSettingsCache, logAdmin } = await lib();
    const origin = new URL(data.origin).origin;
    const main = await tg("setWebhook", { url: `${origin}/api/public/bot`, secret_token: webhookSecret("main"), allowed_updates: ["message"] });
    const support = await tg("setWebhook", { url: `${origin}/api/public/support-bot`, secret_token: webhookSecret("support"), allowed_updates: ["message"] }, "support");
    const me = await tg("getMe", {});
    const sme = await tg("getMe", {}, "support");
    await tg("setChatMenuButton", { menu_button: { type: "web_app", text: "Open", web_app: { url: origin } } });
    const sb = await db();
    const { error: saveErr } = await sb.from("app_settings").upsert([
      { key: "webapp_url", value: origin as never },
      { key: "bot_username", value: (me.result?.username ?? "") as never },
      { key: "support_bot_username", value: (sme.result?.username ?? "") as never },
    ], { onConflict: "key" });
    if (saveErr) throw new Error("Bots connected, but saving the app address failed: " + saveErr.message);
    clearSettingsCache();
    await logAdmin(adminId, "setup_bots", { origin });
    return { main: main.ok ? "connected" : main.description, support: support.ok ? "connected" : support.description, bot: me.result?.username, supportBot: sme.result?.username };
  });
