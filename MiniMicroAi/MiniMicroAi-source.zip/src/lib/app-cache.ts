// Saves the app's files on the phone after the first open (service worker in /sw.js),
// so later opens load from the phone and new versions are fetched in the background.
export function registerAppCache() {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) return;
  const h = window.location.hostname;
  const allowed = window.location.protocol === "https:" && !h.startsWith("id-preview--") && !h.includes("lovableproject.com") && window.top === window.self;
  if (!allowed) {
    // Never keep a cache in the editor preview: remove any worker that got there.
    navigator.serviceWorker.getRegistrations().then((rs) => rs.forEach((r) => r.unregister())).catch(() => {});
    return;
  }
  navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(() => {});
}
