import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const init = z.string().min(10).max(4096);

async function session(initData: string, deviceId?: string) {
  const m = await import("./server/session.server");
  return m.session(initData, deviceId);
}

export const bootstrap = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init, deviceId: z.string().max(64).optional() }).parse(d))
  .handler(async ({ data }) => {
    const { getSettings, isAdmin, db, missingChannels } = await import("./server/core.server");
    const [{ tg, row }, s, sb] = await Promise.all([session(data.initData, data.deviceId), getSettings(), db()]);
    const admin = isAdmin(Number(row.id));
    const noDeposit = Number(row.total_deposit) <= 0;
    const [{ count: refCount }, { count: giftCount }, dailyNew, missing, freeUsed] = await Promise.all([
      sb.from("app_users").select("id", { count: "exact", head: true }).eq("referred_by", row.id),
      sb.from("gift_boxes").select("id", { count: "exact", head: true }).eq("user_id", row.id).is("opened_at", null),
      // One free gift box per user per day (UTC); the database makes it once-only.
      row.banned ? Promise.resolve(false) : sb.rpc("claim_daily_gift", { p_user: row.id }).then((r) => r.data === true),
      admin ? Promise.resolve([]) : missingChannels(Number(row.id), s.required_channels ?? []),
      noDeposit
        ? sb.from("withdrawals").select("amount").eq("user_id", row.id).in("status", ["pending", "processing", "paid"]).then((r) => (r.data ?? []).reduce((a, x) => a + Number(x.amount), 0))
        : Promise.resolve(0),
    ]);
    const bonus = Number(s.welcome_bonus_points) || 0;
    return {
      id: Number(row.id),
      name: row.first_name ?? tg.first_name ?? "User",
      username: row.username,
      photo: tg.photo_url ?? null,
      balance: Number(row.usdt_balance),
      points: row.points,
      totalDeposit: Number(row.total_deposit),
      totalWithdraw: Number(row.total_withdraw),
      createdAt: row.created_at,
      withdrawBlocked: row.withdraw_blocked,
      referrals: refCount ?? 0,
      unopenedGifts: (giftCount ?? 0) + (dailyNew ? 1 : 0),
      dailyGift: dailyNew,
      isAdmin: admin,
      // Extra accounts on one device (flagged) get no welcome bonus.
      welcomeBonus: !row.welcome_claimed && !row.withdraw_blocked && bonus > 0 ? bonus : 0,
      missingChannels: missing.map((c) => ({ title: c.title, url: c.url })),
      freeWithdraw: noDeposit ? { cap: Number(s.free_withdraw_usd) || 0, used: freeUsed } : null,
      settings: {
        minDeposit: Number(s.min_deposit_usd),
        minWithdraw: Number(s.min_withdraw_usd),
        withdrawFee: Number(s.withdraw_fee_usd),
        minAgeMinutes: Number(s.min_account_age_minutes),
        channelUrl: s.channel_url,
        supportBot: s.support_bot_username,
        botUsername: s.bot_username,
        maintenance: !!s.maintenance,
        giftMin: Number(s.gift_min),
        giftMax: Number(s.gift_max),
      },
    };
  });

export const claimWelcome = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init }).parse(d))
  .handler(async ({ data }) => {
    const { db, getSettings } = await import("./server/core.server");
    const { row } = await session(data.initData);
    const s = await getSettings();
    const pts = Math.floor(Number(s.welcome_bonus_points) || 0);
    if (pts <= 0) return { error: "Welcome bonus is not available" };
    if (row.withdraw_blocked) return { error: "Welcome bonus is only for one account per device" };
    const { data: r } = await (await db()).rpc("claim_welcome", { p_user: row.id, p_points: pts });
    if (r == null) return { error: "Welcome bonus already claimed" };
    return { points: Number(r) };
  });

export const checkJoin = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init }).parse(d))
  .handler(async ({ data }) => {
    const { getSettings, missingChannels } = await import("./server/core.server");
    const { row } = await session(data.initData);
    const s = await getSettings();
    const missing = await missingChannels(Number(row.id), s.required_channels ?? [], true);
    return { missing: missing.map((c) => ({ title: c.title, url: c.url })) };
  });

/** Prepares a rich invite message (image + text + button) the user can share from the app. */
export const prepareInvite = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init }).parse(d))
  .handler(async ({ data }) => {
    const { getSettings, tg, publicFile } = await import("./server/core.server");
    const { row, tg: user } = await session(data.initData);
    const s = await getSettings();
    if (!s.bot_username) return { error: "Bot is not connected yet" };
    const link = `https://t.me/${s.bot_username.replace(/^@/, "")}?start=ref_${row.id}`;
    const name = (row.first_name ?? user.first_name ?? "Your friend").replace(/[<>&]/g, "");
    const caption =
      `🎁 <b>${name} invites you to Micro Wallet!</b>\n\n` +
      `💼 Your own crypto wallet right inside Telegram\n` +
      `🌐 Deposit on BNB, ETH, TRON, SOL, TON and BTC\n` +
      `💸 Fast USDT (BEP-20) withdrawals\n` +
      `🎉 Welcome bonus points for new members\n\n` +
      `👇 Tap the button to open the app`;
    const r = await tg("savePreparedInlineMessage", {
      user_id: row.id,
      result: {
        type: "photo",
        id: `inv${row.id}${Date.now() % 100000}`,
        photo_url: publicFile(s, "invite-banner.jpg"),
        thumbnail_url: publicFile(s, "invite-banner.jpg"),
        caption,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "🚀 Open App", url: link }]] },
      },
      allow_user_chats: true,
      allow_group_chats: true,
      allow_channel_chats: true,
      allow_bot_chats: false,
    });
    if (!r.ok) return { error: r.description ?? "Could not prepare invite", link };
    return { id: String(r.result.id), link };
  });

export const getDepositInfo = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init }).parse(d))
  .handler(async ({ data }) => {
    const { db, getSettings } = await import("./server/core.server");
    const { allAddresses } = await import("./server/wallet.server");
    const { CHAIN_INFO } = await import("./server/chains.server");
    const { row } = await session(data.initData);
    const s = await getSettings();
    if (!s.deposit_enabled) throw new Error("Deposits are paused right now");
    const { getPrices } = await import("./server/core.server");
    const [a, prices] = await Promise.all([allAddresses(Number(row.wallet_index)), getPrices().catch(() => ({}) as Record<string, number>)]);
    await (await db()).from("app_users").update({ watch_until: new Date(Date.now() + 24 * 3600_000).toISOString() }).eq("id", row.id);
    return {
      prices,
      minDeposit: Number(s.min_deposit_usd),
      chains: CHAIN_INFO.map((c) => ({ chain: c.chain, name: c.name, net: c.net, assets: [...c.assets], address: a[c.key] })),
    };
  });

export const checkMyDeposits = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init, chain: z.enum(["BSC", "ETH", "TRON", "SOL", "TON", "BTC"]).optional() }).parse(d))
  .handler(async ({ data }) => {
    const { db } = await import("./server/core.server");
    const { scanUser } = await import("./server/chains.server");
    const { row } = await session(data.initData);
    const sb = await db();
    const last = row.last_check_at ? new Date(row.last_check_at).getTime() : 0;
    const wait = Math.ceil((last + 30_000 - Date.now()) / 1000);
    if (wait > 0) return { credited: [], waitSeconds: wait };
    await sb.from("app_users").update({ last_check_at: new Date().toISOString() }).eq("id", row.id);
    const r = await scanUser(Number(row.id), Number(row.wallet_index), data.chain ? [data.chain] : undefined);
    return {
      credited: r.credited.map((c) => ({ chain: c.chain, asset: c.asset, amount: c.amount, usd: c.usd, status: c.result })),
      waitSeconds: 0,
    };
  });

export const getHistory = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init }).parse(d))
  .handler(async ({ data }) => {
    const { db } = await import("./server/core.server");
    const { row } = await session(data.initData);
    const sb = await db();
    const [l, w, d] = await Promise.all([
      sb.from("ledger").select("id,kind,amount,note,created_at").eq("user_id", row.id).order("id", { ascending: false }).limit(50),
      sb.from("withdrawals").select("id,amount,fee,address,status,tx_hash,reject_reason,created_at").eq("user_id", row.id).order("id", { ascending: false }).limit(30),
      sb.from("deposits").select("id,chain,asset,amount,usd_value,status,tx_hash,created_at").eq("user_id", row.id).order("id", { ascending: false }).limit(30),
    ]);
    return {
      ledger: (l.data ?? []).map((x) => ({ ...x, amount: Number(x.amount) })),
      withdrawals: (w.data ?? []).map((x) => ({ ...x, amount: Number(x.amount), fee: Number(x.fee) })),
      deposits: (d.data ?? []).map((x) => ({ ...x, amount: String(x.amount), usd_value: Number(x.usd_value) })),
    };
  });

export const requestWithdraw = createServerFn({ method: "POST" })
  .inputValidator((d) =>
    z.object({
      initData: init,
      amount: z.number().positive().max(1_000_000),
      address: z.string().regex(/^0x[a-fA-F0-9]{40}$/, "Enter a valid BEP-20 address (0x...)"),
      key: z.string().uuid(),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const { db, getSettings, tg, adminIds } = await import("./server/core.server");
    const { canWithdraw } = await import("./server/users.server");
    const { maybeAutoPay } = await import("./server/payout.server");
    const { row } = await session(data.initData);
    const s = await getSettings();
    const block = await canWithdraw(row);
    if (block) return { error: block };
    const amount = Math.floor(data.amount * 100) / 100;
    const free = Number(row.total_deposit) <= 0;
    const freeCap = Number(s.free_withdraw_usd) || 0;
    if (free && freeCap <= 0) return { error: "Make a deposit first to withdraw" };
    // Users without a deposit can only take out the admin-set free amount, with no fee.
    const minAmount = free ? Math.min(Number(s.min_withdraw_usd), freeCap) : Number(s.min_withdraw_usd);
    if (amount <= 0 || amount < minAmount) return { error: `Minimum withdrawal is ${minAmount} USDT` };
    const sb = await db();
    const { data: r, error } = await sb.rpc("request_withdrawal_capped", {
      p_user: row.id, p_amount: amount, p_fee: free ? 0 : Number(s.withdraw_fee_usd), p_address: data.address.toLowerCase(), p_key: `${row.id}:${data.key}`, p_free_cap: freeCap,
    });
    if (error) return { error: "Could not create withdrawal, try again" };
    const res = r as { id?: number; error?: string; duplicate?: boolean };
    if (res.error) return { error: res.error };
    if (res.duplicate) return { id: res.id, status: "pending" };
    const paid = await maybeAutoPay(Number(res.id), amount).catch(() => false);
    if (!paid) {
      for (const a of adminIds())
        await tg("sendMessage", { chat_id: a, parse_mode: "HTML", text: `<b>New withdrawal #${res.id}</b>\nUser: <code>${row.id}</code>\nAmount: ${amount} USDT\nTo: <code>${data.address}</code>` }).catch(() => {});
    }
    return { id: res.id, status: paid ? "paid" : "pending" };
  });

export const getFriends = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init }).parse(d))
  .handler(async ({ data }) => {
    const { db } = await import("./server/core.server");
    const { row } = await session(data.initData);
    const sb = await db();
    const [f, g] = await Promise.all([
      sb.from("app_users").select("first_name,username,created_at,total_deposit").eq("referred_by", row.id).order("created_at", { ascending: false }).limit(100),
      sb.from("gift_boxes").select("id,points,opened_at,created_at,daily_day").eq("user_id", row.id).order("id", { ascending: false }).limit(100),
    ]);
    return {
      friends: (f.data ?? []).map((x) => ({ name: x.first_name ?? x.username ?? "Friend", joined: x.created_at, active: Number(x.total_deposit) > 0 })),
      gifts: g.data ?? [],
    };
  });

export const openGift = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init, boxId: z.number().int().positive() }).parse(d))
  .handler(async ({ data }) => {
    const { db, getSettings } = await import("./server/core.server");
    const { row } = await session(data.initData);
    const s = await getSettings();
    const { data: pts } = await (await db()).rpc("open_gift_box", { p_user: row.id, p_box: data.boxId, p_min: Number(s.gift_min), p_max: Number(s.gift_max) });
    if (pts == null) return { error: "This gift is already opened" };
    return { points: Number(pts) };
  });

export const getTasks = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init }).parse(d))
  .handler(async ({ data }) => {
    const { db } = await import("./server/core.server");
    const { row } = await session(data.initData);
    const sb = await db();
    const [t, c] = await Promise.all([
      sb.from("tasks").select("id,title,url,reward_points,reward_type,reward_usdt").eq("active", true).order("id"),
      sb.from("task_completions").select("task_id").eq("user_id", row.id),
    ]);
    const done = new Set((c.data ?? []).map((x) => Number(x.task_id)));
    return (t.data ?? []).map((x) => ({ ...x, id: Number(x.id), reward_usdt: Number(x.reward_usdt), done: done.has(Number(x.id)) }));
  });

export const completeTask = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ initData: init, taskId: z.number().int().positive() }).parse(d))
  .handler(async ({ data }) => {
    const { db, tg } = await import("./server/core.server");
    const { row } = await session(data.initData);
    const sb = await db();
    const { data: task } = await sb.from("tasks").select("url").eq("id", data.taskId).eq("active", true).maybeSingle();
    if (!task) return { error: "Task not found" };
    const m = /t\.me\/([a-zA-Z0-9_]{4,})\/?$/.exec(task.url);
    if (m) {
      const r = await tg("getChatMember", { chat_id: "@" + m[1], user_id: row.id });
      if (r.ok && !["member", "administrator", "creator"].includes(r.result?.status)) return { error: "Join the channel first, then tap check" };
    }
    const { data: res } = await sb.rpc("complete_task_reward", { p_user: row.id, p_task: data.taskId });
    if (res == null) return { error: "Already completed" };
    const out = res as { type: "points" | "usdt"; amount: number };
    return { type: out.type, amount: Number(out.amount) };
  });
