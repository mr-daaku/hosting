// BEP-20 USDT payouts from the hot wallet (HD index 0). One withdrawal can be paid only once:
// claim_withdrawal moves pending -> processing atomically before any transaction is signed.
import { db, getSettings, tg } from "./core.server";
import { hotWalletPrivateKey, evmAddress } from "./wallet.server";
import { BSC_USDT } from "./chains.server";

function bscRpc() {
  const key = process.env["ALCHEMY_API"];
  return key ? `https://bnb-mainnet.g.alchemy.com/v2/${key}` : "https://bsc-dataseed.binance.org";
}

export function hotWalletAddress() {
  return evmAddress(0);
}

export async function hotWalletBalances() {
  const { createPublicClient, http, erc20Abi, formatUnits } = await import("viem");
  const { bsc } = await import("viem/chains");
  const client = createPublicClient({ chain: bsc, transport: http(bscRpc()) });
  const address = hotWalletAddress() as `0x${string}`;
  const [bnb, usdt] = await Promise.all([
    client.getBalance({ address }),
    client.readContract({ address: BSC_USDT as `0x${string}`, abi: erc20Abi, functionName: "balanceOf", args: [address] }),
  ]);
  return { address, bnb: formatUnits(bnb, 18), usdt: formatUnits(usdt, 18) };
}

export async function payWithdrawal(id: number, adminId: number): Promise<{ ok: boolean; tx?: string; error?: string }> {
  const sb = await db();
  const { data: claimed } = await sb.rpc("claim_withdrawal", { p_id: id, p_admin: adminId });
  if (!claimed) return { ok: false, error: "Already processed or not pending" };
  const { data: w } = await sb.from("withdrawals").select("*").eq("id", id).single();
  if (!w) return { ok: false, error: "Not found" };
  let hash: string | undefined;
  try {
    const { createWalletClient, createPublicClient, http, erc20Abi, parseUnits, isAddress, getAddress } = await import("viem");
    const { privateKeyToAccount } = await import("viem/accounts");
    const { bsc } = await import("viem/chains");
    if (!isAddress(w.address)) throw new Error("Invalid address");
    const account = privateKeyToAccount(hotWalletPrivateKey());
    const pub = createPublicClient({ chain: bsc, transport: http(bscRpc()) });
    const wallet = createWalletClient({ account, chain: bsc, transport: http(bscRpc()) });
    const amount = parseUnits(String(w.amount), 18);
    const bal = await pub.readContract({ address: BSC_USDT as `0x${string}`, abi: erc20Abi, functionName: "balanceOf", args: [account.address] });
    if (bal < amount) throw new Error("Hot wallet USDT balance too low");
    hash = await wallet.writeContract({ address: BSC_USDT as `0x${string}`, abi: erc20Abi, functionName: "transfer", args: [getAddress(w.address), amount] });
  } catch (e) {
    // Nothing was broadcast: put it back to pending so an admin can retry or reject.
    await sb.rpc("unclaim_withdrawal", { p_id: id });
    return { ok: false, error: (e as Error).message.slice(0, 200) };
  }
  await sb.rpc("finish_withdrawal", { p_id: id, p_tx: hash });
  await tg("sendMessage", {
    chat_id: w.user_id,
    parse_mode: "HTML",
    text: `<b>Withdrawal paid</b>\n${w.amount} USDT (BEP-20) sent.\n<a href="https://bscscan.com/tx/${hash}">View transaction</a>`,
  }).catch(() => {});
  return { ok: true, tx: hash };
}

/** Auto pay if enabled and within limits. Returns true when paid. */
export async function maybeAutoPay(id: number, amount: number) {
  const s = await getSettings();
  if (!s.auto_pay_enabled || amount > Number(s.auto_pay_max_usd)) return false;
  const sb = await db();
  const since = new Date(Date.now() - 86400_000).toISOString();
  const { data } = await sb.from("withdrawals").select("amount").eq("status", "paid").eq("processed_by", 0).gte("processed_at", since);
  const today = (data ?? []).reduce((a, r) => a + Number(r.amount), 0);
  if (today + amount > Number(s.auto_pay_daily_limit_usd)) return false;
  const r = await payWithdrawal(id, 0);
  return r.ok;
}
