// Deposit scanning per chain. Only on-chain data is trusted: chain, token contract,
// destination address and confirmations are all validated here.
import { base58 } from "@scure/base";
import { db, getPrices, getSettings } from "./core.server";
import { allAddresses, solAta, tonRawAddress } from "./wallet.server";

export type Found = { chain: string; asset: string; tx: string; log: number; amount: string; to: string };

export const CHAIN_INFO = [
  { chain: "BSC", name: "BNB Smart Chain", net: "BEP-20", key: "evm", assets: ["USDT", "USDC", "BNB"] },
  { chain: "ETH", name: "Ethereum", net: "ERC-20", key: "evm", assets: ["USDT", "USDC", "ETH"] },
  { chain: "TRON", name: "TRON", net: "TRC-20", key: "tron", assets: ["USDT", "TRX"] },
  { chain: "SOL", name: "Solana", net: "SPL", key: "sol", assets: ["USDT", "USDC", "SOL"] },
  { chain: "TON", name: "TON", net: "Jetton", key: "ton", assets: ["USDT", "GRAM"] },
  { chain: "BTC", name: "Bitcoin", net: "SegWit", key: "btc", assets: ["BTC"] },
] as const;

const EVM: Record<string, { rpc: string; conf: number; native: string; tokens: Record<string, { sym: string; dec: number }> }> = {
  ETH: {
    rpc: "eth-mainnet",
    conf: 12,
    native: "ETH",
    tokens: {
      "0xdac17f958d2ee523a2206206994597c13d831ec7": { sym: "USDT", dec: 6 },
      "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48": { sym: "USDC", dec: 6 },
    },
  },
  BSC: {
    rpc: "bnb-mainnet",
    conf: 15,
    native: "BNB",
    tokens: {
      "0x55d398326f99059ff775485246999027b3197955": { sym: "USDT", dec: 18 },
      "0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d": { sym: "USDC", dec: 18 },
    },
  },
};
export const BSC_USDT = "0x55d398326f99059fF775485246999027B3197955";

export function units(raw: bigint, dec: number): string {
  const neg = raw < 0n;
  let s = (neg ? -raw : raw).toString().padStart(dec + 1, "0");
  const i = s.slice(0, s.length - dec);
  let f = dec ? s.slice(s.length - dec) : "";
  f = f.replace(/0+$/, "");
  return (neg ? "-" : "") + i + (f ? "." + f : "");
}

function alchemyUrl(net: string) {
  const key = process.env["ALCHEMY_API"] ?? process.env["ALCHEMY_ API"];
  if (!key) throw new Error("ALCHEMY_API missing");
  return `https://${net}.g.alchemy.com/v2/${key}`;
}
async function rpc(url: string, method: string, params: unknown[]) {
  const res = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }) });
  const j = (await res.json()) as { result?: any; error?: { message: string } };
  if (j.error) throw new Error(`${method}: ${j.error.message}`);
  return j.result;
}

const TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";

export async function scanEvm(chain: "ETH" | "BSC", address: string): Promise<Found[]> {
  const cfg = EVM[chain]!;
  const url = alchemyUrl(cfg.rpc);
  const latest = parseInt(await rpc(url, "eth_blockNumber", []), 16);
  const out: Found[] = [];
  const to = address.toLowerCase();
  try {
    const r = await rpc(url, "alchemy_getAssetTransfers", [
      { fromBlock: "0x0", toBlock: "latest", toAddress: address, category: ["external", "erc20"], excludeZeroValue: true, maxCount: "0x32", order: "desc" },
    ]);
    for (const t of r.transfers ?? []) {
      const block = parseInt(t.blockNum, 16);
      if (latest - block < cfg.conf) continue;
      if ((t.to ?? "").toLowerCase() !== to) continue;
      const raw = BigInt(t.rawContract?.value ?? "0x0");
      if (raw <= 0n) continue;
      const m = /:log:(\d+)$/.exec(t.uniqueId ?? "");
      if (t.category === "external") {
        out.push({ chain, asset: cfg.native, tx: t.hash, log: -1, amount: units(raw, 18), to: address });
      } else if (t.category === "erc20" && m) {
        const tok = cfg.tokens[(t.rawContract?.address ?? "").toLowerCase()];
        if (!tok) continue; // unknown / fake token contract
        out.push({ chain, asset: tok.sym, tx: t.hash, log: Number(m[1]), amount: units(raw, tok.dec), to: address });
      }
    }
    return out;
  } catch (e) {
    // Fallback: token logs in the recent window (native coin needs the transfers API)
    const from = Math.max(0, latest - 4900);
    const topicTo = "0x" + to.replace(/^0x/, "").padStart(64, "0");
    const logs = await rpc(url, "eth_getLogs", [
      { fromBlock: "0x" + from.toString(16), toBlock: "0x" + (latest - cfg.conf).toString(16), address: Object.keys(cfg.tokens), topics: [TRANSFER_TOPIC, null, topicTo] },
    ]);
    for (const l of logs ?? []) {
      if (l.removed) continue;
      const tok = cfg.tokens[(l.address ?? "").toLowerCase()];
      if (!tok) continue;
      const raw = BigInt(l.data);
      if (raw <= 0n) continue;
      out.push({ chain, asset: tok.sym, tx: l.transactionHash, log: parseInt(l.logIndex, 16), amount: units(raw, tok.dec), to: address });
    }
    console.warn(`${chain} transfers API failed, used logs`, (e as Error).message);
    return out;
  }
}

const TRON_USDT = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";
function tronHex(b58: string) {
  const b = base58.decode(b58).slice(0, 21);
  return Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
}
export async function scanTron(address: string): Promise<Found[]> {
  const out: Found[] = [];
  const h = { accept: "application/json" };
  const r1 = await fetch(`https://api.trongrid.io/v1/accounts/${address}/transactions/trc20?only_to=true&only_confirmed=true&limit=50&contract_address=${TRON_USDT}`, { headers: h });
  if (r1.ok) {
    const j = (await r1.json()) as { data?: any[] };
    for (const t of j.data ?? []) {
      if (t.to !== address || t.type !== "Transfer" || t.token_info?.address !== TRON_USDT) continue;
      const raw = BigInt(t.value ?? "0");
      if (raw <= 0n) continue;
      out.push({ chain: "TRON", asset: "USDT", tx: t.transaction_id, log: 0, amount: units(raw, 6), to: address });
    }
  }
  const r2 = await fetch(`https://api.trongrid.io/v1/accounts/${address}/transactions?only_to=true&only_confirmed=true&limit=50`, { headers: h });
  if (r2.ok) {
    const mine = tronHex(address);
    const j = (await r2.json()) as { data?: any[] };
    for (const t of j.data ?? []) {
      const c = t.raw_data?.contract?.[0];
      if (c?.type !== "TransferContract" || t.ret?.[0]?.contractRet !== "SUCCESS") continue;
      if ((c.parameter?.value?.to_address ?? "").toLowerCase() !== mine) continue;
      const raw = BigInt(c.parameter.value.amount ?? 0);
      if (raw <= 0n) continue;
      out.push({ chain: "TRON", asset: "TRX", tx: t.txID, log: -1, amount: units(raw, 6), to: address });
    }
  }
  return out;
}

const SOL_MINTS: Record<string, { sym: string; log: number }> = {
  EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v: { sym: "USDC", log: 1 },
  Es9vMFrzaCERmJfrF4H2FYD4KCoNkY2oZ8zXk6qXz6Ub: { sym: "USDT", log: 2 },
};
export async function scanSol(address: string, known: Set<string>): Promise<Found[]> {
  const url = alchemyUrl("solana-mainnet");
  const watch = [address, ...Object.keys(SOL_MINTS).map((m) => solAta(address, m))];
  const sigs = new Set<string>();
  for (const a of watch) {
    const r = (await rpc(url, "getSignaturesForAddress", [a, { limit: 15, commitment: "finalized" }])) as any[];
    for (const s of r ?? []) if (!s.err) sigs.add(s.signature);
  }
  const out: Found[] = [];
  for (const sig of sigs) {
    if (known.has(sig)) continue;
    const tx = await rpc(url, "getTransaction", [sig, { encoding: "jsonParsed", maxSupportedTransactionVersion: 0, commitment: "finalized" }]);
    if (!tx || tx.meta?.err) continue;
    const keys: string[] = (tx.transaction?.message?.accountKeys ?? []).map((k: any) => (typeof k === "string" ? k : k.pubkey));
    const idx = keys.indexOf(address);
    if (idx >= 0) {
      const diff = BigInt(tx.meta.postBalances[idx]) - BigInt(tx.meta.preBalances[idx]);
      if (diff > 0n) out.push({ chain: "SOL", asset: "SOL", tx: sig, log: 0, amount: units(diff, 9), to: address });
    }
    for (const [mint, info] of Object.entries(SOL_MINTS)) {
      const find = (arr: any[]) => (arr ?? []).find((b) => b.owner === address && b.mint === mint);
      const post = find(tx.meta.postTokenBalances);
      if (!post) continue;
      const pre = find(tx.meta.preTokenBalances);
      const diff = BigInt(post.uiTokenAmount.amount) - BigInt(pre?.uiTokenAmount.amount ?? "0");
      if (diff > 0n) out.push({ chain: "SOL", asset: info.sym, tx: sig, log: info.log, amount: units(diff, post.uiTokenAmount.decimals), to: address });
    }
  }
  return out;
}

export async function scanBtc(address: string): Promise<Found[]> {
  const tipRes = await fetch("https://blockstream.info/api/blocks/tip/height");
  const tip = Number(await tipRes.text());
  const r = await fetch(`https://blockstream.info/api/address/${address}/txs`);
  if (!r.ok) return [];
  const txs = (await r.json()) as any[];
  const out: Found[] = [];
  for (const t of txs) {
    if (!t.status?.confirmed || tip - t.status.block_height + 1 < 2) continue;
    let sum = 0n;
    for (const o of t.vout ?? []) if (o.scriptpubkey_address === address) sum += BigInt(o.value);
    if (sum > 0n) out.push({ chain: "BTC", asset: "BTC", tx: t.txid, log: 0, amount: units(sum, 8), to: address });
  }
  return out;
}

const TON_USDT_MASTER = "0:B113A994B5024A16719F69139328EB759596C38A25F59028B146FECDC3621DFE";
export async function scanTon(address: string, raw: string): Promise<Found[]> {
  const out: Found[] = [];
  const r = await fetch(`https://toncenter.com/api/v3/transactions?account=${encodeURIComponent(address)}&limit=30&sort=desc`);
  if (r.ok) {
    const j = (await r.json()) as { transactions?: any[] };
    for (const t of j.transactions ?? []) {
      const m = t.in_msg;
      if (!m?.source || m.bounced) continue;
      if ((m.destination ?? "").toUpperCase() !== raw) continue;
      const v = BigInt(m.value ?? "0");
      if (v <= 0n) continue;
      out.push({ chain: "TON", asset: "GRAM", tx: t.hash, log: -1, amount: units(v, 9), to: address });
    }
  }
  await new Promise((res) => setTimeout(res, 1100)); // public API limit
  const r2 = await fetch(`https://toncenter.com/api/v3/jetton/transfers?owner_address=${encodeURIComponent(address)}&direction=in&jetton_master=${encodeURIComponent(TON_USDT_MASTER)}&limit=30&sort=desc`);
  if (r2.ok) {
    const j = (await r2.json()) as { jetton_transfers?: any[] };
    for (const t of j.jetton_transfers ?? []) {
      if (t.transaction_aborted) continue;
      if ((t.jetton_master ?? "").toUpperCase() !== TON_USDT_MASTER) continue;
      if ((t.destination ?? "").toUpperCase() !== raw) continue;
      const v = BigInt(t.amount ?? "0");
      if (v <= 0n) continue;
      out.push({ chain: "TON", asset: "USDT", tx: t.transaction_hash, log: 0, amount: units(v, 6), to: address });
    }
  }
  return out;
}

const STABLE = new Set(["USDT", "USDC"]);
const PRICE_SYM: Record<string, string> = { GRAM: "TON" };

/** Scan every chain for one user and credit new deposits. Safe to run many times. */
export async function scanUser(userId: number, walletIndex: number, chains?: string[]) {
  const sb = await db();
  const s = await getSettings();
  const a = await allAddresses(walletIndex);
  const { data: existing } = await sb.from("deposits").select("chain,tx_hash,log_index").eq("user_id", userId).order("id", { ascending: false }).limit(300);
  const known = new Set((existing ?? []).map((d) => d.tx_hash));
  const knownKey = new Set((existing ?? []).map((d) => `${d.chain}:${d.tx_hash}:${d.log_index}`));
  const want = (c: string) => !chains || chains.includes(c);
  const jobs: Promise<Found[]>[] = [];
  if (want("BSC")) jobs.push(scanEvm("BSC", a.evm));
  if (want("ETH")) jobs.push(scanEvm("ETH", a.evm));
  if (want("TRON")) jobs.push(scanTron(a.tron));
  if (want("SOL")) jobs.push(scanSol(a.sol, known));
  if (want("BTC")) jobs.push(scanBtc(a.btc));
  if (want("TON")) jobs.push(tonRawAddress(walletIndex).then((raw) => scanTon(a.ton, raw)));
  const results = await Promise.allSettled(jobs);
  const found = results.flatMap((r) => (r.status === "fulfilled" ? r.value : []));
  const errors = results.filter((r) => r.status === "rejected").map((r) => String((r as PromiseRejectedResult).reason?.message ?? r));
  if (errors.length) console.warn("scan errors", errors);
  for (const f of found) if (f.chain === "ETH" || f.chain === "BSC") f.tx = f.tx.toLowerCase();
  const fresh = found.filter((f) => !knownKey.has(`${f.chain}:${f.tx}:${f.log}`));
  if (!fresh.length) return { credited: [] as (Found & { usd: number; result: string })[], errors };
  const prices = fresh.some((f) => !STABLE.has(f.asset)) ? await getPrices() : {};
  const credited: (Found & { usd: number; result: string })[] = [];
  for (const f of fresh) {
    let usd: number;
    if (STABLE.has(f.asset)) usd = Number(f.amount);
    else {
      const p = prices[PRICE_SYM[f.asset] ?? f.asset];
      if (!p) continue; // no price: retry next scan
      usd = Number(f.amount) * p;
    }
    if (usd < 0.01) continue; // ignore dust / address-poisoning spam
    const { data: result, error } = await sb.rpc("credit_deposit", {
      p_user: userId, p_chain: f.chain, p_asset: f.asset, p_tx: f.tx, p_log: f.log,
      p_amount: f.amount, p_usd: usd, p_to: f.to, p_min_usd: s.min_deposit_usd,
    } as never);
    if (error) { console.error("credit_deposit", error.message); continue; }
    if (result !== "duplicate") credited.push({ ...f, usd, result: String(result) });
  }
  return { credited, errors };
}
