// Shared server-only helpers: database, cached settings, Telegram auth and Bot API.
import { hmac } from "@noble/hashes/hmac.js";
import { sha256 } from "@noble/hashes/sha2.js";

const enc = new TextEncoder();

export async function db() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export function hex(b: Uint8Array) {
  return Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
}
export function sha256hex(s: string) {
  return hex(sha256(enc.encode(s)));
}
export function safeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

// ---------- Settings (cached per server instance, 30s) ----------
export type Settings = {
  min_deposit_usd: number;
  min_withdraw_usd: number;
  withdraw_fee_usd: number;
  min_account_age_minutes: number;
  auto_pay_enabled: boolean;
  auto_pay_max_usd: number;
  auto_pay_daily_limit_usd: number;
  gift_min: number;
  gift_max: number;
  withdraw_enabled: boolean;
  deposit_enabled: boolean;
  channel_url: string;
  support_bot_username: string;
  maintenance: boolean;
  webapp_url: string;
  bot_username: string;
  welcome_bonus_points: number;
  free_withdraw_usd: number;
  required_channels: Channel[];
  /** Internal: cached Telegram file id of the /start photo, "<url>|<file_id>". */
  welcome_photo_id?: string;
};
export type Channel = { title: string; url: string; chat: string };
export const SETTING_KEYS: (keyof Settings)[] = [
  "min_deposit_usd", "min_withdraw_usd", "withdraw_fee_usd", "min_account_age_minutes",
  "auto_pay_enabled", "auto_pay_max_usd", "auto_pay_daily_limit_usd", "gift_min", "gift_max",
  "withdraw_enabled", "deposit_enabled", "channel_url", "support_bot_username", "maintenance",
  "webapp_url", "bot_username", "welcome_bonus_points", "free_withdraw_usd", "required_channels",
];
const DEFAULTS: Partial<Settings> = { welcome_bonus_points: 100, free_withdraw_usd: 0.1, required_channels: [] };
export const PUBLIC_ORIGIN = "https://minimicroaibot.lovable.app";
/** Absolute https URL of a file in /public, for Telegram photos. */
export function publicFile(s: Settings, name: string) {
  const base = /^https:\/\//.test(s.webapp_url ?? "") ? s.webapp_url.replace(/\/$/, "") : PUBLIC_ORIGIN;
  return `${base}/${name}`;
}
let settingsCache: { at: number; value: Settings } | null = null;

export async function getSettings(force = false): Promise<Settings> {
  if (!force && settingsCache && Date.now() - settingsCache.at < 30_000) return settingsCache.value;
  const { data, error } = await (await db()).from("app_settings").select("key,value");
  if (error) throw new Error("settings unavailable");
  const v: Record<string, unknown> = { ...DEFAULTS };
  for (const r of data ?? []) v[r.key] = r.value;
  const value = v as unknown as Settings;
  settingsCache = { at: Date.now(), value };
  return value;
}
export function clearSettingsCache() {
  settingsCache = null;
}

// ---------- Required channels (passed checks cached per instance, 10 min) ----------
const joinedCache = new Map<number, number>();
export function channelChat(url: string) {
  const t = url.trim();
  if (/^-?\d{5,}$/.test(t)) return t;
  const m = /^(?:https?:\/\/)?(?:t\.me|telegram\.me)\/([a-zA-Z0-9_]{4,})\/?$/.exec(t) ?? /^@([a-zA-Z0-9_]{4,})$/.exec(t);
  return m ? "@" + m[1] : null;
}
export async function missingChannels(userId: number, channels: Channel[], force = false): Promise<Channel[]> {
  if (!channels.length) return [];
  const at = joinedCache.get(userId);
  if (!force && at && Date.now() - at < 600_000) return [];
  const res = await Promise.all(
    channels.map(async (c) => {
      const chat = c.chat || channelChat(c.url);
      if (!chat) return null;
      const r = await tg("getChatMember", { chat_id: chat, user_id: userId }).catch(() => ({ ok: false }) as { ok: boolean; result?: any });
      // If the bot cannot check this channel (not an admin there), do not lock users out.
      if (!r.ok) return null;
      const st = r.result?.status;
      const inside = ["member", "administrator", "creator"].includes(st) || (st === "restricted" && r.result?.is_member);
      return inside ? null : c;
    }),
  );
  const missing = res.filter((x): x is Channel => !!x);
  if (!missing.length) {
    if (joinedCache.size > 5000) joinedCache.clear();
    joinedCache.set(userId, Date.now());
  } else joinedCache.delete(userId);
  return missing;
}

// ---------- Admins ----------
export function adminIds(): number[] {
  return [process.env["ADMIN_ID"], process.env["ADMIN_ID_2"]]
    .map((x) => Number((x ?? "").trim()))
    .filter((n) => Number.isSafeInteger(n) && n > 0);
}
export function isAdmin(id: number) {
  return adminIds().includes(id);
}

// ---------- Telegram initData ----------
export type TgUser = { id: number; first_name?: string; last_name?: string; username?: string; photo_url?: string };

export function verifyInitData(initData: string, maxAgeSec = 86400): { user: TgUser; startParam?: string } {
  const token = process.env["BOT_TOKEN"];
  if (!token) throw new Error("Bot not configured");
  if (!initData || initData.length > 4096) throw new Error("Unauthorized");
  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) throw new Error("Unauthorized");
  params.delete("hash");
  const dcs = [...params.entries()].sort(([a], [b]) => (a < b ? -1 : 1)).map(([k, v]) => `${k}=${v}`).join("\n");
  const secret = hmac(sha256, enc.encode("WebAppData"), enc.encode(token));
  const calc = hex(hmac(sha256, secret, enc.encode(dcs)));
  if (!safeEqual(calc, hash)) throw new Error("Unauthorized");
  const authDate = Number(params.get("auth_date"));
  if (!authDate || Date.now() / 1000 - authDate > maxAgeSec) throw new Error("Session expired, reopen the app");
  const user = JSON.parse(params.get("user") ?? "null") as TgUser | null;
  if (!user || !Number.isSafeInteger(user.id)) throw new Error("Unauthorized");
  const sp = params.get("start_param");
  return sp ? { user, startParam: sp } : { user };
}

// ---------- Bot API ----------
export async function tg(method: string, body: Record<string, unknown>, which: "main" | "support" = "main") {
  const token = process.env[which === "main" ? "BOT_TOKEN" : "SUPPORT_BOT_TOKEN"];
  if (!token) throw new Error("Bot token missing");
  const res = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  const json = (await res.json().catch(() => ({}))) as { ok?: boolean; result?: any; description?: string; parameters?: { retry_after?: number } };
  return json;
}

export function webhookSecret(which: "main" | "support") {
  const token = process.env[which === "main" ? "BOT_TOKEN" : "SUPPORT_BOT_TOKEN"] ?? "";
  return sha256hex(`webhook:${which}:${token}`).slice(0, 48);
}

export function escapeHtml(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

export async function logAdmin(adminId: number, action: string, details: Record<string, unknown>) {
  await (await db()).from("admin_logs").insert({ admin_id: adminId, action, details: details as never });
}

// ---------- Prices (Binance live ticker, 60s cache; CoinGecko fallback) ----------
// Native coins are converted coin -> USDT with Binance's live price; stablecoins stay 1:1.
const BINANCE: Record<string, string> = { BNB: "BNBUSDT", ETH: "ETHUSDT", TRX: "TRXUSDT", SOL: "SOLUSDT", BTC: "BTCUSDT", TON: "TONUSDT" };
const CG: Record<string, string> = { BNB: "binancecoin", ETH: "ethereum", TRX: "tron", SOL: "solana", BTC: "bitcoin", TON: "the-open-network" };
const PRICE_TTL = 60_000;
let priceMem: { at: number; v: Record<string, number> } | null = null;
let priceInflight: Promise<Record<string, number>> | null = null;

async function fromBinance(): Promise<Record<string, number>> {
  const symbols = encodeURIComponent(JSON.stringify(Object.values(BINANCE)));
  for (const host of ["https://api.binance.com", "https://data-api.binance.vision"]) {
    try {
      const res = await fetch(`${host}/api/v3/ticker/price?symbols=${symbols}`, { signal: AbortSignal.timeout(4000) });
      if (!res.ok) continue;
      const j = (await res.json()) as { symbol: string; price: string }[];
      const v: Record<string, number> = {};
      for (const [sym, pair] of Object.entries(BINANCE)) {
        const p = Number(j.find((x) => x.symbol === pair)?.price);
        if (p > 0) v[sym] = p;
      }
      if (Object.keys(v).length) return v;
    } catch {}
  }
  return {};
}
async function fromCoinGecko(): Promise<Record<string, number>> {
  try {
    const res = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${Object.values(CG).join(",")}&vs_currencies=usd`, { signal: AbortSignal.timeout(4000) });
    if (!res.ok) return {};
    const j = (await res.json()) as Record<string, { usd: number }>;
    const v: Record<string, number> = {};
    for (const [sym, id] of Object.entries(CG)) { const p = j[id]?.usd; if (p && p > 0) v[sym] = p; }
    return v;
  } catch { return {}; }
}

export async function getPrices(): Promise<Record<string, number>> {
  if (priceMem && Date.now() - priceMem.at < PRICE_TTL) return priceMem.v;
  // One fetch per instance at a time, however many requests arrive together.
  priceInflight ??= (async () => {
    const live = await fromBinance();
    const missing = Object.keys(BINANCE).filter((k) => !live[k]);
    const v = missing.length ? { ...(await fromCoinGecko()), ...live } : live;
    const sb = await db();
    if (Object.keys(v).length) {
      await sb.from("price_cache").upsert(Object.entries(v).map(([asset, usd]) => ({ asset, usd, updated_at: new Date().toISOString() })));
    }
    if (Object.keys(v).length < Object.keys(BINANCE).length) {
      // Last resort: the newest stored prices (younger than 1 hour) for anything still missing.
      const { data } = await sb.from("price_cache").select("asset,usd,updated_at");
      for (const r of data ?? []) if (!v[r.asset] && Date.now() - new Date(r.updated_at).getTime() < 3600_000) v[r.asset] = Number(r.usd);
    }
    priceMem = { at: Date.now(), v };
    return v;
  })().finally(() => { priceInflight = null; });
  return priceInflight;
}
