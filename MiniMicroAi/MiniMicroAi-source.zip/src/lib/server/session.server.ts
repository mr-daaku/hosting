import { getRequestHeader } from "@tanstack/react-start/server";
import { verifyInitData, isAdmin } from "./core.server";
import { upsertUser } from "./users.server";

export async function session(initData: string, deviceId?: string) {
  const { user, startParam } = verifyInitData(initData);
  const ref = /^ref_(\d{1,15})$/.exec(startParam ?? "");
  const ip = getRequestHeader("cf-connecting-ip") ?? undefined;
  const row = await upsertUser(user, ref ? Number(ref[1]) : undefined, deviceId, ip);
  if (row.banned) throw new Error("This account is banned");
  return { tg: user, row };
}

/** Admin check uses only the signed Telegram identity against ADMIN_ID / ADMIN_ID_2. */
export function requireAdmin(initData: string) {
  const { user } = verifyInitData(initData, 6 * 3600);
  if (!isAdmin(user.id)) throw new Error("Forbidden");
  return user.id;
}
