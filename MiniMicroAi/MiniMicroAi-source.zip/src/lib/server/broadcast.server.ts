// Broadcasts are sent in keyset-paginated batches (id > cursor) so the database is read
// once per batch, never per message. A lease stops two workers sending the same batch.
import { db, tg } from "./core.server";

const BATCH = 150;

type Msg = { text: string; photo_id: string | null; buttons: { text: string; url: string }[][] | null };

async function sendOne(chatId: number, m: Msg): Promise<boolean> {
  const reply_markup = m.buttons?.length ? { inline_keyboard: m.buttons } : undefined;
  for (let attempt = 0; attempt < 2; attempt++) {
    const r = m.photo_id
      ? await tg("sendPhoto", { chat_id: chatId, photo: m.photo_id, caption: m.text, parse_mode: "HTML", reply_markup })
      : await tg("sendMessage", { chat_id: chatId, text: m.text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup });
    if (r.ok) return true;
    const wait = r.parameters?.retry_after;
    if (wait && wait < 10) { await new Promise((res) => setTimeout(res, wait * 1000)); continue; }
    return false;
  }
  return false;
}

export async function runBroadcastBatch(id: number) {
  const sb = await db();
  const { data: leased } = await sb.rpc("lease_broadcast", { p_id: id });
  const b = (leased as any[] | null)?.[0];
  if (!b) return { busy: true };
  let ids: number[];
  if (b.target === "all") {
    const { data } = await sb.from("app_users").select("id").eq("banned", false).gt("id", b.cursor).order("id").limit(BATCH);
    ids = (data ?? []).map((r) => Number(r.id));
  } else {
    ids = ((b.target_ids ?? []) as number[]).map(Number).filter((x) => x > Number(b.cursor)).sort((x, y) => x - y).slice(0, BATCH);
  }
  // lease_broadcast may not return the new columns; read them once per batch.
  const msg: Msg = b.photo_id !== undefined ? b : ((await sb.from("broadcasts").select("text,photo_id,buttons").eq("id", id).single()).data as Msg);
  let sent = 0, failed = 0;
  for (let i = 0; i < ids.length; i += 25) {
    const chunk = ids.slice(i, i + 25);
    const res = await Promise.all(chunk.map((cid) => sendOne(cid, msg)));
    sent += res.filter(Boolean).length;
    failed += res.filter((x) => !x).length;
    if (i + 25 < ids.length) await new Promise((r) => setTimeout(r, 1000));
  }
  const done = ids.length < BATCH;
  const update = {
    cursor: ids.length ? ids[ids.length - 1] : b.cursor,
    sent: b.sent + sent,
    failed: b.failed + failed,
    lease_until: null,
    ...(done ? { status: "done", finished_at: new Date().toISOString() } : {}),
  };
  await sb.from("broadcasts").update(update as never).eq("id", id);
  if (done) {
    await tg("sendMessage", {
      chat_id: b.admin_id,
      parse_mode: "HTML",
      text: `<b>Broadcast #${id} finished</b>\nTotal: ${b.total}\nDelivered: ${update.sent}\nFailed: ${update.failed}`,
    }).catch(() => {});
  }
  return { done, sent: update.sent, failed: update.failed };
}

export async function runActiveBroadcasts() {
  const sb = await db();
  const { data } = await sb.from("broadcasts").select("id").eq("status", "running").order("id").limit(3);
  for (const r of data ?? []) await runBroadcastBatch(Number(r.id));
}
