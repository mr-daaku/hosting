import { db, getSettings, sha256hex, type TgUser } from "./core.server";

/** Creates the user on first contact. Referral is only set at creation time. */
export async function upsertUser(u: TgUser, refId?: number, deviceId?: string, ip?: string) {
  const sb = await db();
  const { data: existing } = await sb.from("app_users").select("*").eq("id", u.id).maybeSingle();
  const name = [u.first_name, u.last_name].filter(Boolean).join(" ").slice(0, 64) || null;
  const deviceHash = deviceId && /^[a-zA-Z0-9-]{16,64}$/.test(deviceId) ? sha256hex("dev:" + deviceId) : null;
  const ipHash = ip ? sha256hex("ip:" + ip) : null;
  if (!existing) {
    let referred_by: number | null = null;
    if (refId && refId !== u.id) {
      const { data: ref } = await sb.from("app_users").select("id").eq("id", refId).maybeSingle();
      if (ref) referred_by = ref.id;
    }
    const { data, error } = await sb
      .from("app_users")
      .insert({ id: u.id, username: u.username ?? null, first_name: name, referred_by, device_hash: deviceHash, ip_hash: ipHash })
      .select("*")
      .single();
    if (error && !String(error.message).includes("duplicate")) throw new Error("Could not create account");
    const user = data ?? (await sb.from("app_users").select("*").eq("id", u.id).single()).data!;
    if (deviceHash) await checkDevice(user.id, deviceHash);
    return (await sb.from("app_users").select("*").eq("id", u.id).single()).data!;
  }
  const patch: Record<string, unknown> = { last_seen: new Date().toISOString() };
  if (u.username !== existing.username) patch["username"] = u.username ?? null;
  if (name && name !== existing.first_name) patch["first_name"] = name;
  if (!existing.device_hash && deviceHash) patch["device_hash"] = deviceHash;
  if (ipHash && !existing.ip_hash) patch["ip_hash"] = ipHash;
  if (Date.now() - new Date(existing.last_seen).getTime() > 60_000 || Object.keys(patch).length > 1) {
    await sb.from("app_users").update(patch as never).eq("id", u.id);
  }
  // Device check only when this account's device is first recorded (later boots are already checked).
  if (deviceHash && !existing.device_hash) await checkDevice(u.id, deviceHash);
  return { ...existing, ...patch } as typeof existing;
}

/** Several accounts on one device: all but the first registered lose withdrawal rights. */
async function checkDevice(userId: number, deviceHash: string) {
  const sb = await db();
  const { data } = await sb.from("app_users").select("id,created_at,withdraw_blocked").eq("device_hash", deviceHash).order("created_at").limit(10);
  const first = data?.[0];
  if (first && first.id !== userId) {
    const me = data!.find((r) => r.id === userId);
    if (me && !me.withdraw_blocked) await sb.from("app_users").update({ withdraw_blocked: true }).eq("id", userId);
    else if (!me) await sb.from("app_users").update({ withdraw_blocked: true }).eq("id", userId);
  }
}

export async function canWithdraw(user: { created_at: string; withdraw_blocked: boolean; banned: boolean }) {
  const s = await getSettings();
  const ageMin = (Date.now() - new Date(user.created_at).getTime()) / 60000;
  if (user.banned) return "This account is banned";
  if (user.withdraw_blocked) return "Withdrawals are disabled: more than one account was used on this device";
  if (!s.withdraw_enabled) return "Withdrawals are paused right now";
  if (ageMin < Number(s.min_account_age_minutes)) return `Your account must be at least ${s.min_account_age_minutes} minutes old to withdraw`;
  return null;
}
