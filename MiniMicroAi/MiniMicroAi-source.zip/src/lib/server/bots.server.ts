// Webhook handlers for the main bot and the support bot.
import { adminIds, db, escapeHtml, getSettings, isAdmin, publicFile, tg, type Settings } from "./core.server";
import { upsertUser } from "./users.server";

// The /start photo is uploaded from its URL only once; afterwards Telegram's file id is reused,
// which is much faster than Telegram downloading the image again on every /start.
let photoMem: string | null = null;
async function sendWelcome(s: Settings, chatId: number, caption: string, kb: unknown) {
  const url = publicFile(s, "welcome-banner.jpg");
  const saved = photoMem ?? s.welcome_photo_id ?? "";
  const [savedUrl, fileId] = saved.split("|");
  const base = { chat_id: chatId, caption, parse_mode: "HTML", reply_markup: kb };
  if (savedUrl === url && fileId) {
    const r = await tg("sendPhoto", { ...base, photo: fileId });
    if (r.ok) return;
  }
  const r = await tg("sendPhoto", { ...base, photo: url });
  if (!r.ok) {
    await tg("sendMessage", { chat_id: chatId, parse_mode: "HTML", text: caption, reply_markup: kb });
    return;
  }
  const sizes = r.result?.photo as { file_id: string }[] | undefined;
  const id = sizes?.[sizes.length - 1]?.file_id;
  if (id) {
    photoMem = `${url}|${id}`;
    await (await db()).from("app_settings").upsert({ key: "welcome_photo_id", value: photoMem as never }, { onConflict: "key" });
  }
}

export async function handleMainUpdate(update: any) {
  const msg = update.message;
  if (!msg?.from || msg.chat?.type !== "private") return;
  const text: string = msg.text ?? "";
  const s = await getSettings();
  if (text.startsWith("/start")) {
    const arg = text.split(/\s+/)[1] ?? "";
    const m = /^ref_(\d{1,15})$/.exec(arg);
    // Save the user at the same time as replying, so the reply is not held up by the database.
    const saving = upsertUser(msg.from, m ? Number(m[1]) : undefined).catch((e) => console.error("start upsert failed", e));
    const kb = s.webapp_url
      ? { inline_keyboard: [[{ text: "🚀 Open Micro Wallet", web_app: { url: s.webapp_url } }], ...(s.channel_url ? [[{ text: "📢 Join our channel", url: s.channel_url }]] : [])] }
      : undefined;
    const name = escapeHtml(msg.from.first_name ?? "friend");
    const caption =
      `👋 <b>Welcome, ${name}!</b>\n\n` +
      `💼 <b>Micro Wallet</b> is your crypto wallet right inside Telegram.\n\n` +
      `🌐 Deposit on BNB, Ethereum, TRON, Solana, TON and Bitcoin\n` +
      `💸 Withdraw USDT (BEP-20) fast\n` +
      `🎁 Claim your welcome bonus and open gift boxes\n` +
      `👥 Invite friends and earn more points\n\n` +
      `👇 Tap the button below to open the app`;
    await Promise.all([sendWelcome(s, msg.chat.id, caption, kb), saving]);
    return;
  }
  if (text === "/help" && s.support_bot_username) {
    await tg("sendMessage", { chat_id: msg.chat.id, text: `Support: @${s.support_bot_username.replace(/^@/, "")}` });
  }
}

export async function handleSupportUpdate(update: any) {
  const msg = update.message;
  if (!msg?.from || msg.chat?.type !== "private") return;
  const sb = await db();
  const fromId = Number(msg.from.id);
  if (isAdmin(fromId)) {
    // Admin reply: reply to a forwarded message, or "/reply <userId> text"
    let target: number | null = null;
    let body: string = msg.text ?? msg.caption ?? "";
    if (msg.reply_to_message) {
      const { data } = await sb.from("support_messages").select("user_id").eq("admin_chat_id", fromId).eq("admin_message_id", msg.reply_to_message.message_id).maybeSingle();
      target = data ? Number(data.user_id) : null;
    }
    const m = /^\/reply\s+(\d+)\s+([\s\S]+)/.exec(body);
    if (m) { target = Number(m[1]); body = m[2]!; }
    if (!target) {
      await tg("sendMessage", { chat_id: fromId, text: "Reply to a user's message to answer, or use /reply <userId> <text>." }, "support");
      return;
    }
    const r = msg.text || m
      ? await tg("sendMessage", { chat_id: target, parse_mode: "HTML", text: `<b>Support</b>\n${escapeHtml(body)}` }, "support")
      : await tg("copyMessage", { chat_id: target, from_chat_id: fromId, message_id: msg.message_id }, "support");
    await sb.from("support_messages").insert({ user_id: target, direction: "out", text: body.slice(0, 4000) });
    await tg("sendMessage", { chat_id: fromId, text: r.ok ? `Sent to ${target}` : `Failed: ${r.description ?? "error"}` }, "support");
    return;
  }
  if (msg.text === "/start") {
    await tg("sendMessage", { chat_id: fromId, text: "Hi! Write your question here and our team will reply soon." }, "support");
    return;
  }
  const text: string = (msg.text ?? msg.caption ?? "").slice(0, 3500);
  const name = escapeHtml([msg.from.first_name, msg.from.last_name].filter(Boolean).join(" "));
  const header = `<b>Support message</b>\nFrom: ${name}${msg.from.username ? " @" + escapeHtml(msg.from.username) : ""}\nUser ID: <code>${fromId}</code>\n\n`;
  for (const admin of adminIds()) {
    let sent = await tg("sendMessage", { chat_id: admin, parse_mode: "HTML", text: header + escapeHtml(text || "[attachment below]") }, "support");
    if (!msg.text) {
      const c = await tg("copyMessage", { chat_id: admin, from_chat_id: fromId, message_id: msg.message_id }, "support");
      if (c.ok) await sb.from("support_messages").insert({ user_id: fromId, direction: "in", text: "[attachment]", admin_chat_id: admin, admin_message_id: c.result.message_id });
    }
    if (sent.ok) await sb.from("support_messages").insert({ user_id: fromId, direction: "in", text, admin_chat_id: admin, admin_message_id: sent.result.message_id });
  }
  await tg("sendMessage", { chat_id: fromId, text: "Message received. Our team will reply here." }, "support");
}
