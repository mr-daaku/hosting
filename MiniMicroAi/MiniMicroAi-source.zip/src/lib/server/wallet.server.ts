// Derives per-user deposit addresses from the HD_WALLET seed. Addresses are never stored.
import { HDKey } from "@scure/bip32";
import { mnemonicToSeedSync } from "@scure/bip39";
import { secp256k1 } from "@noble/curves/secp256k1.js";
import { ed25519 } from "@noble/curves/ed25519.js";
import { keccak_256 } from "@noble/hashes/sha3.js";
import { sha256, sha512 } from "@noble/hashes/sha2.js";
import { ripemd160 } from "@noble/hashes/legacy.js";
import { hmac } from "@noble/hashes/hmac.js";
import { base58, base58check, bech32 } from "@scure/base";

const enc = new TextEncoder();
let cachedSeed: { phrase: string; seed: Uint8Array; root: HDKey } | null = null;

function getSeed(phraseOverride?: string) {
  const phrase = (phraseOverride ?? process.env["HD_WALLET"] ?? "").trim().toLowerCase().split(/\s+/).join(" ");
  if (!phrase || phrase.split(" ").length < 12) throw new Error("HD_WALLET is not configured");
  if (cachedSeed && cachedSeed.phrase === phrase) return cachedSeed;
  const seed = mnemonicToSeedSync(phrase);
  cachedSeed = { phrase, seed, root: HDKey.fromMasterSeed(seed) };
  return cachedSeed;
}

function toHex(b: Uint8Array) {
  return Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
}

export function evmChecksum(addrHex: string) {
  const a = addrHex.toLowerCase().replace(/^0x/, "");
  const h = toHex(keccak_256(enc.encode(a)));
  let out = "0x";
  for (let i = 0; i < a.length; i++) out += parseInt(h[i]!, 16) >= 8 ? a[i]!.toUpperCase() : a[i];
  return out;
}

function secpKey(path: string, phrase?: string) {
  const k = getSeed(phrase).root.derive(path);
  if (!k.privateKey) throw new Error("derive failed");
  return k.privateKey;
}

function evmFromPriv(priv: Uint8Array) {
  const pub = secp256k1.getPublicKey(priv, false).slice(1);
  return keccak_256(pub).slice(12);
}

export function evmAddress(index: number, phrase?: string) {
  return evmChecksum(toHex(evmFromPriv(secpKey(`m/44'/60'/0'/0/${index}`, phrase))));
}

/** Hot wallet (index 0) private key, used only for BEP-20 payouts. */
export function hotWalletPrivateKey(): `0x${string}` {
  return `0x${toHex(secpKey(`m/44'/60'/0'/0/0`))}`;
}

export function tronAddress(index: number, phrase?: string) {
  const body = evmFromPriv(secpKey(`m/44'/195'/0'/0/${index}`, phrase));
  const payload = new Uint8Array(21);
  payload[0] = 0x41;
  payload.set(body, 1);
  return base58check(sha256).encode(payload);
}

export function btcAddress(index: number, phrase?: string) {
  const pub = secp256k1.getPublicKey(secpKey(`m/84'/0'/0'/0/${index}`, phrase), true);
  const h = ripemd160(sha256(pub));
  return bech32.encode("bc", [0, ...bech32.toWords(h)]);
}

// SLIP-0010 ed25519 (hardened only)
function slip10(path: number[], phrase?: string) {
  let I = hmac(sha512, enc.encode("ed25519 seed"), getSeed(phrase).seed);
  let key = I.slice(0, 32);
  let chain = I.slice(32);
  for (const idx of path) {
    const data = new Uint8Array(37);
    data[0] = 0;
    data.set(key, 1);
    const n = (idx | 0x80000000) >>> 0;
    data[33] = (n >>> 24) & 255;
    data[34] = (n >>> 16) & 255;
    data[35] = (n >>> 8) & 255;
    data[36] = n & 255;
    I = hmac(sha512, chain, data);
    key = I.slice(0, 32);
    chain = I.slice(32);
  }
  return key;
}

export function solPublicKey(index: number, phrase?: string) {
  return ed25519.getPublicKey(slip10([44, 501, index, 0], phrase));
}
export function solAddress(index: number, phrase?: string) {
  return base58.encode(solPublicKey(index, phrase));
}

export function tonPublicKey(index: number, phrase?: string) {
  return ed25519.getPublicKey(slip10([44, 607, index], phrase));
}

export async function tonAddress(index: number, phrase?: string) {
  const { WalletContractV4 } = await import("@ton/ton");
  const { Buffer } = await import("node:buffer");
  const w = WalletContractV4.create({ workchain: 0, publicKey: Buffer.from(tonPublicKey(index, phrase)) });
  return w.address.toString({ bounceable: false, urlSafe: true });
}

export async function tonRawAddress(index: number, phrase?: string) {
  const { WalletContractV4 } = await import("@ton/ton");
  const { Buffer } = await import("node:buffer");
  const w = WalletContractV4.create({ workchain: 0, publicKey: Buffer.from(tonPublicKey(index, phrase)) });
  return w.address.toRawString().toUpperCase();
}

// Solana associated token account (PDA)
function isOnCurve(b: Uint8Array) {
  try {
    ed25519.Point.fromBytes(b);
    return true;
  } catch {
    return false;
  }
}
const TOKEN_PROGRAM = base58.decode("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA");
const ATA_PROGRAM = base58.decode("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL");
export function solAta(ownerB58: string, mintB58: string) {
  const owner = base58.decode(ownerB58);
  const mint = base58.decode(mintB58);
  for (let bump = 255; bump >= 0; bump--) {
    const buf = new Uint8Array([...owner, ...TOKEN_PROGRAM, ...mint, bump, ...ATA_PROGRAM, ...enc.encode("ProgramDerivedAddress")]);
    const h = sha256(buf);
    if (!isOnCurve(h)) return base58.encode(h);
  }
  throw new Error("no ata");
}

export async function allAddresses(index: number) {
  return {
    evm: evmAddress(index),
    tron: tronAddress(index),
    btc: btcAddress(index),
    sol: solAddress(index),
    ton: await tonAddress(index),
  };
}
