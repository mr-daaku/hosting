export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      admin_logs: {
        Row: {
          action: string
          admin_id: number
          created_at: string
          details: Json | null
          id: number
        }
        Insert: {
          action: string
          admin_id: number
          created_at?: string
          details?: Json | null
          id?: never
        }
        Update: {
          action?: string
          admin_id?: number
          created_at?: string
          details?: Json | null
          id?: never
        }
        Relationships: []
      }
      app_settings: {
        Row: {
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          key: string
          updated_at?: string
          value: Json
        }
        Update: {
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      app_users: {
        Row: {
          banned: boolean
          created_at: string
          device_hash: string | null
          first_name: string | null
          id: number
          ip_hash: string | null
          last_check_at: string | null
          last_seen: string
          points: number
          referred_by: number | null
          total_deposit: number
          total_withdraw: number
          usdt_balance: number
          username: string | null
          wallet_index: number
          watch_until: string | null
          welcome_claimed: boolean
          withdraw_blocked: boolean
        }
        Insert: {
          banned?: boolean
          created_at?: string
          device_hash?: string | null
          first_name?: string | null
          id: number
          ip_hash?: string | null
          last_check_at?: string | null
          last_seen?: string
          points?: number
          referred_by?: number | null
          total_deposit?: number
          total_withdraw?: number
          usdt_balance?: number
          username?: string | null
          wallet_index?: never
          watch_until?: string | null
          welcome_claimed?: boolean
          withdraw_blocked?: boolean
        }
        Update: {
          banned?: boolean
          created_at?: string
          device_hash?: string | null
          first_name?: string | null
          id?: number
          ip_hash?: string | null
          last_check_at?: string | null
          last_seen?: string
          points?: number
          referred_by?: number | null
          total_deposit?: number
          total_withdraw?: number
          usdt_balance?: number
          username?: string | null
          wallet_index?: never
          watch_until?: string | null
          welcome_claimed?: boolean
          withdraw_blocked?: boolean
        }
        Relationships: []
      }
      broadcasts: {
        Row: {
          admin_id: number
          buttons: Json
          created_at: string
          cursor: number
          failed: number
          finished_at: string | null
          id: number
          lease_until: string | null
          photo_id: string | null
          sent: number
          status: string
          target: string
          target_ids: number[] | null
          text: string
          total: number
        }
        Insert: {
          admin_id: number
          buttons?: Json
          created_at?: string
          cursor?: number
          failed?: number
          finished_at?: string | null
          id?: never
          lease_until?: string | null
          photo_id?: string | null
          sent?: number
          status?: string
          target: string
          target_ids?: number[] | null
          text: string
          total?: number
        }
        Update: {
          admin_id?: number
          buttons?: Json
          created_at?: string
          cursor?: number
          failed?: number
          finished_at?: string | null
          id?: never
          lease_until?: string | null
          photo_id?: string | null
          sent?: number
          status?: string
          target?: string
          target_ids?: number[] | null
          text?: string
          total?: number
        }
        Relationships: []
      }
      deposits: {
        Row: {
          amount: number
          asset: string
          chain: string
          created_at: string
          id: number
          log_index: number
          status: string
          to_address: string
          tx_hash: string
          usd_value: number
          user_id: number
        }
        Insert: {
          amount: number
          asset: string
          chain: string
          created_at?: string
          id?: never
          log_index?: number
          status?: string
          to_address: string
          tx_hash: string
          usd_value?: number
          user_id: number
        }
        Update: {
          amount?: number
          asset?: string
          chain?: string
          created_at?: string
          id?: never
          log_index?: number
          status?: string
          to_address?: string
          tx_hash?: string
          usd_value?: number
          user_id?: number
        }
        Relationships: []
      }
      gift_boxes: {
        Row: {
          created_at: string
          daily_day: string | null
          id: number
          opened_at: string | null
          points: number | null
          referred_id: number | null
          user_id: number
        }
        Insert: {
          created_at?: string
          daily_day?: string | null
          id?: never
          opened_at?: string | null
          points?: number | null
          referred_id?: number | null
          user_id: number
        }
        Update: {
          created_at?: string
          daily_day?: string | null
          id?: never
          opened_at?: string | null
          points?: number | null
          referred_id?: number | null
          user_id?: number
        }
        Relationships: []
      }
      ledger: {
        Row: {
          amount: number
          balance_after: number
          created_at: string
          id: number
          kind: string
          note: string | null
          ref: string
          user_id: number
        }
        Insert: {
          amount: number
          balance_after: number
          created_at?: string
          id?: never
          kind: string
          note?: string | null
          ref: string
          user_id: number
        }
        Update: {
          amount?: number
          balance_after?: number
          created_at?: string
          id?: never
          kind?: string
          note?: string | null
          ref?: string
          user_id?: number
        }
        Relationships: []
      }
      price_cache: {
        Row: {
          asset: string
          updated_at: string
          usd: number
        }
        Insert: {
          asset: string
          updated_at?: string
          usd: number
        }
        Update: {
          asset?: string
          updated_at?: string
          usd?: number
        }
        Relationships: []
      }
      support_messages: {
        Row: {
          admin_chat_id: number | null
          admin_message_id: number | null
          created_at: string
          direction: string
          id: number
          text: string | null
          user_id: number
        }
        Insert: {
          admin_chat_id?: number | null
          admin_message_id?: number | null
          created_at?: string
          direction: string
          id?: never
          text?: string | null
          user_id: number
        }
        Update: {
          admin_chat_id?: number | null
          admin_message_id?: number | null
          created_at?: string
          direction?: string
          id?: never
          text?: string | null
          user_id?: number
        }
        Relationships: []
      }
      task_completions: {
        Row: {
          created_at: string
          task_id: number
          user_id: number
        }
        Insert: {
          created_at?: string
          task_id: number
          user_id: number
        }
        Update: {
          created_at?: string
          task_id?: number
          user_id?: number
        }
        Relationships: []
      }
      tasks: {
        Row: {
          active: boolean
          created_at: string
          id: number
          reward_points: number
          reward_type: string
          reward_usdt: number
          title: string
          url: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          id?: never
          reward_points?: number
          reward_type?: string
          reward_usdt?: number
          title: string
          url: string
        }
        Update: {
          active?: boolean
          created_at?: string
          id?: never
          reward_points?: number
          reward_type?: string
          reward_usdt?: number
          title?: string
          url?: string
        }
        Relationships: []
      }
      withdrawals: {
        Row: {
          address: string
          amount: number
          created_at: string
          fee: number
          id: number
          idempotency_key: string
          processed_at: string | null
          processed_by: number | null
          reject_reason: string | null
          status: string
          tx_hash: string | null
          user_id: number
        }
        Insert: {
          address: string
          amount: number
          created_at?: string
          fee?: number
          id?: never
          idempotency_key: string
          processed_at?: string | null
          processed_by?: number | null
          reject_reason?: string | null
          status?: string
          tx_hash?: string | null
          user_id: number
        }
        Update: {
          address?: string
          amount?: number
          created_at?: string
          fee?: number
          id?: never
          idempotency_key?: string
          processed_at?: string | null
          processed_by?: number | null
          reject_reason?: string | null
          status?: string
          tx_hash?: string | null
          user_id?: number
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_adjust_balance: {
        Args: {
          p_admin: number
          p_amount: number
          p_note: string
          p_ref: string
          p_user: number
        }
        Returns: Json
      }
      admin_adjust_points: {
        Args: {
          p_admin: number
          p_note: string
          p_points: number
          p_user: number
        }
        Returns: Json
      }
      admin_stats: { Args: never; Returns: Json }
      claim_daily_gift: { Args: { p_user: number }; Returns: boolean }
      claim_welcome: {
        Args: { p_points: number; p_user: number }
        Returns: number
      }
      claim_withdrawal: {
        Args: { p_admin: number; p_id: number }
        Returns: boolean
      }
      complete_task: {
        Args: { p_task: number; p_user: number }
        Returns: number
      }
      complete_task_reward: {
        Args: { p_task: number; p_user: number }
        Returns: Json
      }
      credit_deposit: {
        Args: {
          p_amount: number
          p_asset: string
          p_chain: string
          p_log: number
          p_min_usd: number
          p_to: string
          p_tx: string
          p_usd: number
          p_user: number
        }
        Returns: string
      }
      finish_withdrawal: {
        Args: { p_id: number; p_tx: string }
        Returns: boolean
      }
      lease_broadcast: {
        Args: { p_id: number }
        Returns: {
          admin_id: number
          buttons: Json
          created_at: string
          cursor: number
          failed: number
          finished_at: string | null
          id: number
          lease_until: string | null
          photo_id: string | null
          sent: number
          status: string
          target: string
          target_ids: number[] | null
          text: string
          total: number
        }[]
        SetofOptions: {
          from: "*"
          to: "broadcasts"
          isOneToOne: false
          isSetofReturn: true
        }
      }
      open_gift_box: {
        Args: { p_box: number; p_max: number; p_min: number; p_user: number }
        Returns: number
      }
      reject_withdrawal: {
        Args: { p_admin: number; p_id: number; p_reason: string }
        Returns: boolean
      }
      request_withdrawal: {
        Args: {
          p_address: string
          p_amount: number
          p_fee: number
          p_key: string
          p_user: number
        }
        Returns: Json
      }
      request_withdrawal_capped: {
        Args: {
          p_address: string
          p_amount: number
          p_fee: number
          p_free_cap: number
          p_key: string
          p_user: number
        }
        Returns: Json
      }
      unclaim_withdrawal: { Args: { p_id: number }; Returns: boolean }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
