import { Loader2, Send, CheckCircle2, Gift, X } from "lucide-react";
import logo from "@/assets/logo.webp";
import giftImg from "@/assets/gift-box.webp";
import { openExternal } from "@/hooks/use-telegram";

export function LoadingScreen() {
  return (
    <div className="grid min-h-screen place-items-center">
      <div className="flex flex-col items-center gap-4">
        <img src={logo} alt="Micro Wallet" width={96} height={96} className="h-24 w-24" />
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    </div>
  );
}

export function OutsideTelegram() {
  return (
    <div className="mx-auto grid min-h-screen max-w-md place-items-center px-6 text-center">
      <div className="space-y-5">
        <img src={logo} alt="Micro Wallet" width={128} height={128} className="mx-auto h-32 w-32" />
        <h1 className="font-display text-3xl font-bold">Micro Wallet</h1>
        <p className="text-muted-foreground">Your crypto wallet inside Telegram. Deposit on six networks, withdraw USDT, invite friends and open gift boxes.</p>
        <div className="surface flex items-center gap-3 p-4 text-left">
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-violet-grad"><Send className="h-5 w-5" /></span>
          <span className="text-sm">Open this app from our Telegram bot to sign in securely.</span>
        </div>
      </div>
    </div>
  );
}

export function ErrorScreen({ message }: { message: string }) {
  return (
    <div className="mx-auto grid min-h-screen max-w-md place-items-center px-6 text-center">
      <div className="space-y-4">
        <img src={logo} alt="" width={80} height={80} className="mx-auto h-20 w-20" />
        <h1 className="text-xl font-bold">Could not open the app</h1>
        <p className="text-sm text-muted-foreground">{message}</p>
        <button onClick={() => location.reload()} className="rounded-xl bg-primary px-5 py-3 font-bold text-primary-foreground">Try again</button>
      </div>
    </div>
  );
}

export function JoinGate({ channels, onCheck, checking }: { channels: { title: string; url: string }[]; onCheck: () => void; checking: boolean }) {
  return (
    <div className="safe-top mx-auto flex min-h-screen max-w-md flex-col px-5 pb-10">
      <div className="space-y-3 pt-6 text-center">
        <img src={logo} alt="" width={88} height={88} className="mx-auto h-22 w-22" />
        <h1 className="text-2xl font-extrabold">Join our channels</h1>
        <p className="text-sm text-muted-foreground">Join the channels below to open Micro Wallet, then tap Check join.</p>
      </div>
      <div className="mt-6 space-y-2.5">
        {channels.map((c) => (
          <button key={c.url} onClick={() => openExternal(c.url)} className="surface flex w-full items-center gap-3 p-4 text-left">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-violet-grad"><Send className="h-5 w-5" /></span>
            <span className="flex-1 font-bold">{c.title}</span>
            <span className="rounded-full bg-primary px-3 py-1.5 text-xs font-bold text-primary-foreground">Join</span>
          </button>
        ))}
      </div>
      <button onClick={onCheck} disabled={checking} className="mt-6 flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-primary font-bold text-primary-foreground glow">
        {checking ? <Loader2 className="h-5 w-5 animate-spin" /> : <CheckCircle2 className="h-5 w-5" />} Check join
      </button>
    </div>
  );
}

export function WelcomeBonus({ points, onClaim, onLater, busy }: { points: number; onClaim: () => void; onLater: () => void; busy: boolean }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-background/80 px-6 backdrop-blur-sm">
      <div className="surface relative w-full max-w-sm animate-pop space-y-4 border-primary/50 p-6 text-center glow">
        <button aria-label="Later" onClick={onLater} className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full bg-accent"><X className="h-4 w-4" /></button>
        <img src={giftImg} alt="" width={140} height={140} className="mx-auto h-32 w-32" />
        <div className="space-y-1">
          <div className="text-sm font-bold text-muted-foreground">Welcome bonus</div>
          <div className="font-display text-5xl font-extrabold text-primary">+{points}</div>
          <div className="text-sm">points for joining Micro Wallet</div>
        </div>
        <button onClick={onClaim} disabled={busy} className="flex h-13 w-full items-center justify-center gap-2 rounded-2xl bg-primary py-3.5 font-bold text-primary-foreground">
          {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <Gift className="h-5 w-5" />} Claim {points} points
        </button>
        <button onClick={onLater} className="text-xs text-muted-foreground">Claim later</button>
      </div>
    </div>
  );
}
