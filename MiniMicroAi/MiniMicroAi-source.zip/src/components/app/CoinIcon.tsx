import { cn } from "@/lib/utils";

// Simple vector coin marks (no emoji, no external images)
const MAP: Record<string, { bg: string; fg: string; glyph: string }> = {
  USDT: { bg: "#26A17B", fg: "#fff", glyph: "T" },
  USDC: { bg: "#2775CA", fg: "#fff", glyph: "$" },
  BNB: { bg: "#F3BA2F", fg: "#1E2026", glyph: "B" },
  BSC: { bg: "#F3BA2F", fg: "#1E2026", glyph: "B" },
  ETH: { bg: "#627EEA", fg: "#fff", glyph: "E" },
  TRON: { bg: "#EB0029", fg: "#fff", glyph: "T" },
  TRX: { bg: "#EB0029", fg: "#fff", glyph: "T" },
  SOL: { bg: "#14F195", fg: "#1a1a2e", glyph: "S" },
  TON: { bg: "#0098EA", fg: "#fff", glyph: "G" },
  GRAM: { bg: "#0098EA", fg: "#fff", glyph: "G" },
  BTC: { bg: "#F7931A", fg: "#fff", glyph: "B" },
};

export function CoinIcon({ sym, className }: { sym: string; className?: string }) {
  const m = MAP[sym] ?? { bg: "#555", fg: "#fff", glyph: sym.slice(0, 1) };
  return (
    <svg viewBox="0 0 32 32" className={cn("shrink-0", className)} aria-hidden="true">
      <circle cx="16" cy="16" r="16" fill={m.bg} />
      <circle cx="16" cy="16" r="12.5" fill="none" stroke={m.fg} strokeOpacity="0.25" />
      <text x="16" y="21.5" textAnchor="middle" fontFamily="Tektur, sans-serif" fontWeight="800" fontSize="15" fill={m.fg}>{m.glyph}</text>
    </svg>
  );
}
