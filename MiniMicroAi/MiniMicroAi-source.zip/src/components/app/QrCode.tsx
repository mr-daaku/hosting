import { QRCodeSVG } from "qrcode.react";
export function QrCode({ value, size = 160 }: { value: string; size?: number }) {
  return <QRCodeSVG value={value} size={size} bgColor="transparent" fgColor="currentColor" className="text-background" />;
}
