import { useLocation } from "@tanstack/react-router";
import { Gift, Users, LineChart, CircleDollarSign, User } from "lucide-react";
import { cn } from "@/lib/utils";
import { haptic } from "@/hooks/use-telegram";
import { Tap } from "./Tap";

const items = [
  { to: "/gifts", icon: Gift, label: "Gifts" },
  { to: "/friends", icon: Users, label: "Friends" },
  { to: "/", icon: LineChart, label: "Home" },
  { to: "/wallet", icon: CircleDollarSign, label: "Wallet" },
  { to: "/profile", icon: User, label: "Profile" },
] as const;

export function BottomNav({ badge }: { badge?: number }) {
  const { pathname } = useLocation();
  return (
    <nav className="safe-bottom fixed inset-x-0 bottom-0 z-40 px-3">
      <div className="surface mx-auto flex max-w-md items-center justify-between rounded-full p-1.5">
        {items.map((it) => {
          const active = it.to === "/" ? pathname === "/" : pathname.startsWith(it.to);
          const Icon = it.icon;
          return (
            <Tap
              key={it.to}
              to={it.to}
              aria-label={it.label}
              onClick={() => haptic()}
              className={cn(
                "relative grid h-12 w-12 place-items-center rounded-full transition-colors",
                active ? "bg-primary text-primary-foreground glow" : "text-foreground/80 hover:text-foreground",
              )}
            >
              <Icon className="h-6 w-6" strokeWidth={2} />
              {it.to === "/gifts" && !!badge && (
                <span className="absolute right-1 top-1 grid h-4 min-w-4 place-items-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground">{badge}</span>
              )}
            </Tap>
          );
        })}
      </div>
    </nav>
  );
}
