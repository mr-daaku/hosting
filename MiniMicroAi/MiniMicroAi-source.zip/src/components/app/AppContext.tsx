import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { registerAppCache } from "@/lib/app-cache";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { bootstrap, checkJoin, claimWelcome } from "@/lib/api.functions";
import { deviceId, haptic, useNoContextMenu, useTelegramInit } from "@/hooks/use-telegram";
import { JoinGate, WelcomeBonus } from "./Screens";

export type Me = Awaited<ReturnType<typeof bootstrap>>;
type Ctx = { initData: string; me: Me; refresh: () => void };
const AppCtx = createContext<Ctx | null>(null);

export function useApp() {
  const c = useContext(AppCtx);
  if (!c) throw new Error("useApp outside provider");
  return c;
}

export function AppProvider({ children, fallback, loading, error }: { children: ReactNode; fallback: ReactNode; loading: ReactNode; error: (msg: string) => ReactNode }) {
  const { ready, initData } = useTelegramInit();
  useNoContextMenu();
  const boot = useServerFn(bootstrap);
  const join = useServerFn(checkJoin);
  const claim = useServerFn(claimWelcome);
  const qc = useQueryClient();
  const [checking, setChecking] = useState(false);
  const [later, setLater] = useState(false);
  const [claiming, setClaiming] = useState(false);
  // Last known account data is shown instantly on reopen while fresh data loads in the background.
  const [cached, setCached] = useState<Me | undefined>(undefined);
  const cacheKey = initData ? "mw_me_" + (/%22id%22%3A(\d+)/.exec(initData)?.[1] ?? "") : "";
  useEffect(() => {
    registerAppCache();
    if (!cacheKey) return;
    try { const raw = localStorage.getItem(cacheKey); if (raw) setCached(JSON.parse(raw) as Me); } catch {}
  }, [cacheKey]);
  const q = useQuery({
    queryKey: ["me", initData],
    queryFn: async () => {
      const r = await boot({ data: { initData, deviceId: deviceId() } });
      try { localStorage.setItem(cacheKey, JSON.stringify({ ...r, welcomeBonus: 0, dailyGift: false })); } catch {}
      return r;
    },
    placeholderData: () => cached,
    enabled: ready && !!initData,
    staleTime: 60_000,
    refetchOnWindowFocus: false,
    retry: 1,
  });
  const dailyShown = useRef(false);
  useEffect(() => {
    if (q.data?.dailyGift && !q.isPlaceholderData && !dailyShown.current) {
      dailyShown.current = true;
      toast.success("Your free daily gift box is ready in Gifts");
    }
  }, [q.data, q.isPlaceholderData]);
  if (!ready) return <>{loading}</>;
  if (!initData) return <>{fallback}</>;
  if (q.isError && !q.data) return <>{error((q.error as Error).message)}</>;
  if (!q.data) return <>{loading}</>;
  const me = q.data;
  if (me.settings.maintenance && !me.isAdmin) return <>{error("The app is under maintenance. Please come back soon.")}</>;
  if (me.missingChannels.length && !me.isAdmin)
    return (
      <JoinGate
        channels={me.missingChannels}
        checking={checking}
        onCheck={async () => {
          setChecking(true);
          try {
            const r = await join({ data: { initData } });
            if (r.missing.length) {
              haptic("error");
              toast.error(`Join ${r.missing.length === 1 ? "this channel" : "these channels"} first`);
              qc.setQueryData(["me", initData], { ...me, missingChannels: r.missing });
            } else {
              haptic("success");
              qc.setQueryData(["me", initData], { ...me, missingChannels: [] });
            }
          } catch (e) {
            toast.error((e as Error).message);
          } finally {
            setChecking(false);
          }
        }}
      />
    );
  return (
    <AppCtx.Provider value={{ initData, me, refresh: () => qc.invalidateQueries({ queryKey: ["me"] }) }}>
      {children}
      {me.welcomeBonus > 0 && !later && (
        <WelcomeBonus
          points={me.welcomeBonus}
          busy={claiming}
          onLater={() => setLater(true)}
          onClaim={async () => {
            setClaiming(true);
            try {
              const r = await claim({ data: { initData } });
              if ("error" in r) toast.error(r.error);
              else {
                haptic("success");
                toast.success(`+${r.points} points added`);
              }
              qc.setQueryData(["me", initData], { ...me, welcomeBonus: 0, points: me.points + ("points" in r ? r.points : 0) });
            } catch (e) {
              toast.error((e as Error).message);
            } finally {
              setClaiming(false);
            }
          }}
        />
      )}
    </AppCtx.Provider>
  );
}
