// In-app navigation without <a href>, so a long press never shows the app's address.
import { forwardRef, type ButtonHTMLAttributes } from "react";
import { useNavigate } from "@tanstack/react-router";

export type AppPath = "/" | "/wallet" | "/wallet/withdraw" | "/history" | "/legal" | "/admin" | "/gifts" | "/friends" | "/profile";

export const Tap = forwardRef<HTMLButtonElement, ButtonHTMLAttributes<HTMLButtonElement> & { to: AppPath }>(function Tap({ to, onClick, type, ...rest }, ref) {
  const navigate = useNavigate();
  return (
    <button
      ref={ref}
      type={type ?? "button"}
      onClick={(e) => {
        onClick?.(e);
        if (!e.defaultPrevented) navigate({ to });
      }}
      {...rest}
    />
  );
});
