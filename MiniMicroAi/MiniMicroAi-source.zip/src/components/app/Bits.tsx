import { useState, type ReactNode } from "react";
import { useServerFn } from "@tanstack/react-start";
import { prepareInvite } from "@/lib/api.functions";
import { Tap } from "./Tap";
import { Send, CheckCircle2, ChevronRight, Headphones, Copy, UserPlus, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useApp } from "./AppContext";
import { haptic, openExternal, getWebApp } from "@/hooks/use-telegram";

export function fmt(n: number, d = 2) {
  return n.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
}

export function Page({ children, className }: { children: ReactNode; className?: string }) {
  return <main className={cn("safe-top mx-auto max-w-md space-y-4 px-4 pb-28 animate-pop", className)}>{children}</main>;
}

export function SectionTitle({ children, right }: { children: ReactNode; right?: ReactNode }) {
  return (
    <div className="flex items-center justify-between pt-2">
      <h2 className="text-xl font-extrabold tracking-tight">{children}</h2>
      {right}
    </div>
  );
}

export function ProfileHeader() {
  const { me } = useApp();
  const support = me.settings.supportBot;
  return (
    <header className="flex items-center gap-3">
      <div className="relative">
        {me.photo ? (
          <img src={me.photo} alt="" className="h-14 w-14 rounded-full object-cover" />
        ) : (
          <div className="grid h-14 w-14 place-items-center rounded-full bg-violet-grad font-display text-xl font-bold">{me.name.slice(0, 1).toUpperCase()}</div>
        )}
        <span className="absolute bottom-0.5 right-0.5 h-3.5 w-3.5 rounded-full border-2 border-background bg-success" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="truncate font-display text-lg font-bold uppercase tracking-[0.18em]">{me.name}</div>
        <div className="text-sm text-muted-foreground">{me.totalDeposit > 0 ? "Holder" : "Member"}</div>
      </div>
      <div className="border-l border-border pl-3 text-right">
        <div className="font-display text-xl font-bold leading-none">{me.points}</div>
        <div className="text-xs text-muted-foreground">points</div>
      </div>
      <button
        aria-label="Support"
        onClick={() => support && openExternal(`https://t.me/${support.replace(/^@/, "")}`)}
        className="grid h-14 w-14 place-items-center rounded-full bg-accent text-foreground"
      >
        <Headphones className="h-6 w-6" />
      </button>
    </header>
  );
}

export function ChannelCard() {
  const { me } = useApp();
  if (!me.settings.channelUrl) return null;
  return (
    <button onClick={() => openExternal(me.settings.channelUrl)} className="surface flex w-full items-start gap-3 p-4 text-left">
      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-violet-grad text-foreground">
        <Send className="h-5 w-5" />
      </span>
      <span className="flex-1">
        <span className="block font-bold">Subscribe to the channel</span>
        <span className="block text-xs text-muted-foreground">News, updates and new tasks first</span>
      </span>
      <CheckCircle2 className="h-8 w-8 text-success" />
    </button>
  );
}

export function StatTile({ icon, value, label }: { icon: ReactNode; value: ReactNode; label: string }) {
  return (
    <div className="surface flex flex-col items-center gap-1.5 p-3 text-center">
      <span className="grid h-9 w-9 place-items-center rounded-lg border border-border text-foreground/90 [&_svg]:h-4 [&_svg]:w-4">{icon}</span>
      <span className="font-display text-lg font-bold leading-none">{value}</span>
      <span className="text-[11px] leading-tight text-muted-foreground">{label}</span>
    </div>
  );
}

export function MenuRow({ icon, title, sub, to, onClick }: { icon: ReactNode; title: string; sub?: string; to?: "/history" | "/legal" | "/admin"; onClick?: () => void }) {
  const inner = (
    <>
      <span className="grid h-10 w-10 place-items-center rounded-full border border-border [&_svg]:h-5 [&_svg]:w-5">{icon}</span>
      <span className="flex-1 text-left">
        <span className="block font-bold">{title}</span>
        {sub && <span className="block text-xs text-muted-foreground">{sub}</span>}
      </span>
      <ChevronRight className="h-5 w-5 text-muted-foreground" />
    </>
  );
  const cls = "flex w-full items-center gap-3 px-4 py-4 border-b border-border last:border-b-0";
  return to ? <Tap to={to} className={cls}>{inner}</Tap> : <button onClick={onClick} className={cls}>{inner}</button>;
}

export function refLink(botUsername: string, id: number) {
  return `https://t.me/${botUsername || "your_bot"}?start=ref_${id}`;
}

export function InviteButtons() {
  const { me, initData } = useApp();
  const prep = useServerFn(prepareInvite);
  const [busy, setBusy] = useState(false);
  const link = refLink(me.settings.botUsername, me.id);
  const fallbackShare = () => {
    const text = "Join me on Micro Wallet - a crypto wallet inside Telegram";
    const url = `https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent(text)}`;
    if (getWebApp()) getWebApp()!.openTelegramLink(url);
    else window.open(url, "_blank");
  };
  return (
    <div className="grid grid-cols-2 gap-3">
      <Button
        variant="hero"
        size="xl"
        disabled={busy}
        onClick={async () => {
          haptic();
          const wa = getWebApp();
          if (!wa?.shareMessage || !wa.isVersionAtLeast?.("8.0")) return fallbackShare();
          setBusy(true);
          try {
            const r = await prep({ data: { initData } });
            if ("id" in r && r.id) wa.shareMessage(r.id, (sent) => sent && toast.success("Invite sent"));
            else fallbackShare();
          } catch {
            fallbackShare();
          } finally {
            setBusy(false);
          }
        }}
      >
        {busy ? <Loader2 className="animate-spin" /> : <UserPlus />} Invite
      </Button>
      <Button
        variant="ghostline"
        size="xl"
        onClick={async () => {
          await navigator.clipboard.writeText(link).catch(() => {});
          haptic("success");
          toast.success("Invite link copied");
        }}
      >
        <Copy /> Copy link
      </Button>
    </div>
  );
}

export function CopyField({ value, label }: { value: string; label?: string }) {
  return (
    <button
      onClick={async () => {
        await navigator.clipboard.writeText(value).catch(() => {});
        haptic("success");
        toast.success(`${label ?? "Value"} copied`);
      }}
      className="flex w-full items-center gap-2 rounded-xl border border-border bg-background/60 px-3 py-3 text-left"
    >
      <span className="flex-1 break-all font-mono text-xs">{value}</span>
      <Copy className="h-4 w-4 shrink-0 text-primary" />
    </button>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <p className="py-6 text-center text-sm text-muted-foreground">{children}</p>;
}
