import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Search, Ban, ShieldOff, ShieldCheck, Plus, Minus, Send, Trash2, Power, Link2, RefreshCw, ImagePlus, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { useApp } from "@/components/app/AppContext";
import { CopyField, Empty, fmt } from "@/components/app/Bits";
import { CoinIcon } from "@/components/app/CoinIcon";
import { openExternal } from "@/hooks/use-telegram";
import {
  adminStats, adminUsers, adminUserAction, adminWithdrawals, adminWithdrawalAction, adminDeposits, adminCheckDeposit,
  adminGetSettings, adminSaveSettings, adminCreateBroadcast, adminBroadcasts, adminTasks, adminLogs, adminSetupBots, adminTestChannel, adminUploadPhoto,
} from "@/lib/admin.functions";

const Spin = () => <Loader2 className="mx-auto my-6 h-6 w-6 animate-spin text-primary" />;
function Pill({ active, children, onClick }: { active: boolean; children: React.ReactNode; onClick: () => void }) {
  return <button onClick={onClick} className={cn("whitespace-nowrap rounded-full border px-3.5 py-1.5 text-sm font-bold", active ? "border-primary bg-primary text-primary-foreground" : "border-border")}>{children}</button>;
}
function Card({ title, children, className }: { title?: string; children: React.ReactNode; className?: string }) {
  return <div className={cn("surface space-y-3 p-4", className)}>{title && <div className="font-bold">{title}</div>}{children}</div>;
}
function Kpi({ label, value }: { label: string; value: React.ReactNode }) {
  return <div className="surface p-3"><div className="text-xs text-muted-foreground">{label}</div><div className="font-display text-xl font-bold">{value}</div></div>;
}

export function Dashboard() {
  const { initData } = useApp();
  const fn = useServerFn(adminStats);
  const setup = useServerFn(adminSetupBots);
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["a-stats"], queryFn: () => fn({ data: { initData } }) });
  const [busy, setBusy] = useState(false);
  if (q.isLoading) return <Spin />;
  const s = (q.data?.stats ?? {}) as { users?: number; users_today?: number; deposit_total?: number; deposit_today?: number; withdraw_paid?: number; withdraw_pending?: number; balance_total?: number; auto_paid_today?: number };
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2.5">
        <Kpi label="Users" value={s.users} />
        <Kpi label="New today" value={s.users_today} />
        <Kpi label="Deposits total" value={fmt(Number(s.deposit_total))} />
        <Kpi label="Deposits today" value={fmt(Number(s.deposit_today))} />
        <Kpi label="Paid out" value={fmt(Number(s.withdraw_paid))} />
        <Kpi label="Pending withdrawals" value={s.withdraw_pending} />
        <Kpi label="User balances (liability)" value={fmt(Number(s.balance_total))} />
        <Kpi label="Auto paid (24h)" value={fmt(Number(s.auto_paid_today))} />
      </div>
      <Card title="Hot wallet (BEP-20 payouts)">
        {q.data?.hot ? (
          <>
            <CopyField value={q.data.hot.address} label="Hot wallet" />
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="flex items-center gap-2"><CoinIcon sym="USDT" className="h-5 w-5" /> {fmt(Number(q.data.hot.usdt))} USDT</div>
              <div className="flex items-center gap-2"><CoinIcon sym="BNB" className="h-5 w-5" /> {Number(q.data.hot.bnb).toFixed(5)} BNB gas</div>
            </div>
            <p className="text-xs text-muted-foreground">Keep USDT and some BNB for gas here. User deposit addresses are separate and must be swept manually with your seed phrase.</p>
          </>
        ) : <p className="text-sm text-muted-foreground">Could not load hot wallet balance.</p>}
      </Card>
      <Card title="Bot connection">
        <p className="text-sm text-muted-foreground">Connect both bots to this app's address. Run once after publishing, and again if the address changes.</p>
        <Button variant="hero" disabled={busy} onClick={async () => {
          setBusy(true);
          try {
            const r = await setup({ data: { initData, origin: window.location.origin } });
            qc.invalidateQueries({ queryKey: ["a-settings"] });
            toast.success(`Main bot @${r.bot}: ${r.main}. Support bot @${r.supportBot}: ${r.support}`);
          } catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
        }}>{busy ? <Loader2 className="animate-spin" /> : <Link2 />} Connect bots to {typeof window !== "undefined" ? window.location.host : ""}</Button>
      </Card>
    </div>
  );
}

export function Users() {
  const { initData } = useApp();
  const fn = useServerFn(adminUsers);
  const act = useServerFn(adminUserAction);
  const [q, setQ] = useState("");
  const [term, setTerm] = useState("");
  const [page, setPage] = useState(0);
  const [adj, setAdj] = useState<Record<number, string>>({});
  const [pts, setPts] = useState<Record<number, string>>({});
  const qc = useQueryClient();
  // Nothing loads until the admin searches.
  const r = useQuery({ queryKey: ["a-users", term, page], queryFn: () => fn({ data: { initData, q: term, page } }), enabled: !!term.trim() });
  async function run(userId: number, action: "ban" | "unban" | "block_withdraw" | "unblock_withdraw" | "adjust" | "points", amount?: number) {
    try {
      const res = await act({ data: { initData, userId, action, amount, key: crypto.randomUUID(), note: action === "points" ? "Admin points" : "Admin adjustment" } });
      if ("error" in res && res.error) toast.error(res.error); else toast.success("Done");
    } catch (e) { toast.error((e as Error).message); }
    qc.invalidateQueries({ queryKey: ["a-users"] });
  }
  return (
    <div className="space-y-3">
      <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); setPage(0); setTerm(q); }}>
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="User ID, username or name" className="h-11 rounded-xl" />
        <Button variant="hero" className="h-11"><Search /></Button>
      </form>
      {!term.trim() ? <Empty>Search a user by ID, username or name</Empty> : r.isLoading ? <Spin /> : (
        <>
          <div className="text-xs text-muted-foreground">{r.data?.rows.length ? `${r.data.rows.length} shown` : "No users found"}</div>
          {r.data?.rows.map((u) => (
            <Card key={u.id}>
              <div className="flex justify-between gap-2">
                <div className="min-w-0">
                  <div className="truncate font-bold">{u.first_name ?? "-"} {u.username && <span className="text-muted-foreground">@{u.username}</span>}</div>
                  <div className="font-mono text-xs text-muted-foreground">ID {u.id} - wallet #{u.wallet_index}</div>
                </div>
                <div className="text-right">
                  <div className="font-display font-bold">{fmt(u.usdt_balance)}</div>
                  <div className="text-[11px] text-muted-foreground">{u.points} pts</div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-1 text-[11px] text-muted-foreground">
                <span>Dep {fmt(u.total_deposit)}</span><span>Wd {fmt(u.total_withdraw)}</span><span>{new Date(u.created_at).toLocaleDateString()}</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {u.banned && <span className="rounded bg-destructive/20 px-2 py-0.5 text-xs text-destructive">Banned</span>}
                {u.withdraw_blocked && <span className="rounded bg-primary/20 px-2 py-0.5 text-xs text-primary">Withdraw blocked</span>}
              </div>
              <div className="flex flex-wrap gap-1.5">
                <Button size="sm" variant="ghostline" onClick={() => run(u.id, u.banned ? "unban" : "ban")}><Ban /> {u.banned ? "Unban" : "Ban"}</Button>
                <Button size="sm" variant="ghostline" onClick={() => run(u.id, u.withdraw_blocked ? "unblock_withdraw" : "block_withdraw")}>{u.withdraw_blocked ? <ShieldCheck /> : <ShieldOff />} {u.withdraw_blocked ? "Allow withdraw" : "Block withdraw"}</Button>
              </div>
              <div className="flex gap-1.5">
                <Input value={adj[u.id] ?? ""} onChange={(e) => setAdj({ ...adj, [u.id]: e.target.value.replace(/[^0-9.]/g, "") })} placeholder="USDT amount" className="h-9 rounded-lg" inputMode="decimal" />
                <Button size="sm" variant="ghostline" className="h-9" onClick={() => Number(adj[u.id]) > 0 && confirm(`Add ${adj[u.id]} USDT to ${u.id}?`) && run(u.id, "adjust", Number(adj[u.id]))}><Plus /></Button>
                <Button size="sm" variant="ghostline" className="h-9" onClick={() => Number(adj[u.id]) > 0 && confirm(`Remove ${adj[u.id]} USDT from ${u.id}?`) && run(u.id, "adjust", -Number(adj[u.id]))}><Minus /></Button>
              </div>
              <div className="flex gap-1.5">
                <Input value={pts[u.id] ?? ""} onChange={(e) => setPts({ ...pts, [u.id]: e.target.value.replace(/\D/g, "") })} placeholder="Points" className="h-9 rounded-lg" inputMode="numeric" />
                <Button size="sm" variant="ghostline" className="h-9" onClick={() => Number(pts[u.id]) > 0 && confirm(`Add ${pts[u.id]} points to ${u.id}?`) && run(u.id, "points", Number(pts[u.id]))}><Plus /> pts</Button>
                <Button size="sm" variant="ghostline" className="h-9" onClick={() => Number(pts[u.id]) > 0 && confirm(`Remove ${pts[u.id]} points from ${u.id}?`) && run(u.id, "points", -Number(pts[u.id]))}><Minus /> pts</Button>
              </div>
            </Card>
          ))}
          <div className="flex justify-between">
            <Button size="sm" variant="ghostline" disabled={page === 0} onClick={() => setPage(page - 1)}>Previous</Button>
            <Button size="sm" variant="ghostline" disabled={(r.data?.rows.length ?? 0) < 30} onClick={() => setPage(page + 1)}>Next</Button>
          </div>
        </>
      )}
    </div>
  );
}

export function Withdrawals() {
  const { initData } = useApp();
  const fn = useServerFn(adminWithdrawals);
  const act = useServerFn(adminWithdrawalAction);
  const qc = useQueryClient();
  const [status, setStatus] = useState<"pending" | "paid" | "rejected">("pending");
  const [busy, setBusy] = useState<number | null>(null);
  const r = useQuery({ queryKey: ["a-wd", status], queryFn: () => fn({ data: { initData, status, page: 0 } }) });
  async function run(id: number, action: "pay" | "mark_paid" | "reject") {
    let txHash: string | undefined, reason: string | undefined;
    if (action === "mark_paid") { txHash = prompt("Paste the BEP-20 transaction hash (0x...)") ?? undefined; if (!txHash) return; }
    if (action === "reject") { reason = prompt("Reason (shown to the user)") ?? undefined; if (reason === undefined) return; }
    if (action === "pay" && !confirm(`Send withdrawal #${id} from the hot wallet now?`)) return;
    setBusy(id);
    try {
      const res = await act({ data: { initData, id, action, txHash, reason } });
      if (!res.ok) toast.error(("error" in res && res.error) || "Failed"); else toast.success(action === "pay" ? "Paid" : "Updated");
    } catch (e) { toast.error((e as Error).message); } finally { setBusy(null); qc.invalidateQueries({ queryKey: ["a-wd"] }); }
  }
  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <Pill active={status === "pending"} onClick={() => setStatus("pending")}>Pending</Pill>
        <Pill active={status === "paid"} onClick={() => setStatus("paid")}>Paid</Pill>
        <Pill active={status === "rejected"} onClick={() => setStatus("rejected")}>Rejected</Pill>
      </div>
      {r.isLoading ? <Spin /> : !r.data?.length ? <Empty>Nothing here</Empty> : r.data.map((w) => (
        <Card key={w.id}>
          <div className="flex justify-between"><span className="font-bold">#{w.id} - {fmt(w.amount)} USDT</span><span className="text-xs capitalize text-muted-foreground">{w.status}</span></div>
          <div className="text-xs text-muted-foreground">User {w.user_id} - fee {fmt(w.fee)} - {new Date(w.created_at).toLocaleString()}</div>
          <CopyField value={w.address} label="Address" />
          {w.tx_hash && <button type="button" className="block w-full truncate text-left text-xs text-primary" onClick={() => openExternal(`https://bscscan.com/tx/${w.tx_hash}`)}>{w.tx_hash}</button>}
          {w.reject_reason && <div className="text-xs text-destructive">{w.reject_reason}</div>}
          {w.status === "pending" && (
            <div className="grid grid-cols-3 gap-1.5">
              <Button size="sm" variant="hero" disabled={busy === w.id} onClick={() => run(w.id, "pay")}>{busy === w.id ? <Loader2 className="animate-spin" /> : <Send />} Pay</Button>
              <Button size="sm" variant="ghostline" disabled={busy === w.id} onClick={() => run(w.id, "mark_paid")}>Mark paid</Button>
              <Button size="sm" variant="destructive" disabled={busy === w.id} onClick={() => run(w.id, "reject")}>Reject</Button>
            </div>
          )}
          {w.status === "processing" && <div className="text-xs text-primary">Payment in progress. If it stays stuck, check the hot wallet on BscScan, then Mark paid or Reject.</div>}
          {w.status === "processing" && (
            <div className="grid grid-cols-2 gap-1.5">
              <Button size="sm" variant="destructive" onClick={() => run(w.id, "reject")}>Reject and refund</Button>
            </div>
          )}
        </Card>
      ))}
    </div>
  );
}

export function Deposits() {
  const { initData } = useApp();
  const fn = useServerFn(adminDeposits);
  const [page, setPage] = useState(0);
  const r = useQuery({ queryKey: ["a-dep", page], queryFn: () => fn({ data: { initData, page } }) });
  return (
    <div className="space-y-2">
      {r.isLoading ? <Spin /> : !r.data?.length ? <Empty>No deposits yet</Empty> : r.data.map((d) => <DepositRow key={d.id} d={d} />)}
      <div className="flex justify-between">
        <Button size="sm" variant="ghostline" disabled={page === 0} onClick={() => setPage(page - 1)}>Previous</Button>
        <Button size="sm" variant="ghostline" disabled={(r.data?.length ?? 0) < 30} onClick={() => setPage(page + 1)}>Next</Button>
      </div>
    </div>
  );
}
function DepositRow({ d }: { d: { id: number; user_id: number; chain: string; asset: string; amount: string; usd_value: number; status: string; tx_hash: string; created_at: string } }) {
  return (
    <div className="surface flex items-center gap-3 p-3">
      <CoinIcon sym={d.asset} className="h-8 w-8" />
      <div className="min-w-0 flex-1">
        <div className="text-sm font-bold">{d.amount} {d.asset} <span className="text-xs text-muted-foreground">{d.chain} - user {d.user_id}</span></div>
        <div className="truncate font-mono text-[10px] text-muted-foreground">{d.tx_hash}</div>
      </div>
      <div className="text-right">
        <div className="font-display text-sm font-bold">{fmt(d.usd_value)}</div>
        <div className={cn("text-[10px] font-bold", d.status === "credited" ? "text-success" : "text-destructive")}>{d.status}</div>
      </div>
    </div>
  );
}

export function CheckDeposit() {
  const { initData } = useApp();
  const fn = useServerFn(adminCheckDeposit);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<Awaited<ReturnType<typeof adminCheckDeposit>> | null>(null);
  return (
    <div className="space-y-3">
      <Card title="Check by user ID or transaction hash">
        <p className="text-xs text-muted-foreground">A user ID scans all six networks for that user and credits any confirmed deposit that was missed. A hash looks it up in recorded deposits. Fake or duplicate hashes are never credited.</p>
        <form className="flex gap-2" onSubmit={async (e) => {
          e.preventDefault(); setBusy(true);
          try { setRes(await fn({ data: { initData, query: q } })); } catch (er) { toast.error((er as Error).message); } finally { setBusy(false); }
        }}>
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="User ID or tx hash" className="h-11 rounded-xl font-mono" />
          <Button variant="hero" className="h-11" disabled={busy || q.length < 3}>{busy ? <Loader2 className="animate-spin" /> : <Search />}</Button>
        </form>
      </Card>
      {res && "error" in res && res.error && <p className="text-sm text-destructive">{res.error}</p>}
      {res && "mode" in res && res.mode === "user" && (
        <Card title={`Scan result: ${res.credited.length} new`}>
          {res.credited.map((c, i) => <div key={i} className="text-sm">{c.status === "credited" ? "Credited" : "Below min"}: {c.amount} {c.asset} on {c.chain} = {fmt(c.usd)} USDT</div>)}
          {!!res.errors?.length && <div className="text-xs text-destructive">Some networks failed: {res.errors.join("; ").slice(0, 300)}</div>}
          <div className="space-y-1.5 pt-2 text-xs">
            {Object.entries(res.addresses).map(([k, v]) => <div key={k}><span className="font-bold uppercase text-muted-foreground">{k}</span><CopyField value={v} label={k} /></div>)}
          </div>
        </Card>
      )}
      {res && "mode" in res && res.mode === "tx" && (res.rows.length ? res.rows.map((d) => <DepositRow key={d.id} d={d} />) : <Empty>No deposit recorded with this hash. Check the user ID instead.</Empty>)}
    </div>
  );
}

type S = Awaited<ReturnType<typeof adminGetSettings>>;
const FIELDS: { k: keyof S; label: string; type: "num" | "bool" | "text"; group: string }[] = [
  { k: "deposit_enabled", label: "Deposits enabled", type: "bool", group: "Deposits" },
  { k: "min_deposit_usd", label: "Minimum deposit (USD)", type: "num", group: "Deposits" },
  { k: "withdraw_enabled", label: "Withdrawals enabled", type: "bool", group: "Withdrawals" },
  { k: "min_withdraw_usd", label: "Minimum withdrawal (USDT)", type: "num", group: "Withdrawals" },
  { k: "withdraw_fee_usd", label: "Withdrawal fee (USDT)", type: "num", group: "Withdrawals" },
  { k: "min_account_age_minutes", label: "Account age before withdraw (minutes)", type: "num", group: "Withdrawals" },
  { k: "gift_min", label: "Gift box minimum points", type: "num", group: "Rewards" },
  { k: "gift_max", label: "Gift box maximum points", type: "num", group: "Rewards" },
  { k: "welcome_bonus_points", label: "Welcome bonus points (0 = off)", type: "num", group: "Rewards" },
  { k: "free_withdraw_usd", label: "Free withdraw without deposit (USDT, 0 = off)", type: "num", group: "Withdrawals" },
  { k: "channel_url", label: "Channel link", type: "text", group: "App" },
  { k: "support_bot_username", label: "Support bot username", type: "text", group: "App" },
  { k: "bot_username", label: "Main bot username", type: "text", group: "App" },
  { k: "webapp_url", label: "Mini app URL", type: "text", group: "App" },
  { k: "maintenance", label: "Maintenance mode", type: "bool", group: "App" },
];

function useSettingsForm() {
  const { initData } = useApp();
  const get = useServerFn(adminGetSettings);
  const save = useServerFn(adminSaveSettings);
  const qc = useQueryClient();
  // Always re-read on open so values changed elsewhere (bot connect, the other admin) are not shown stale.
  const q = useQuery({ queryKey: ["a-settings"], queryFn: () => get({ data: { initData } }), refetchOnWindowFocus: false, refetchOnMount: "always" });
  const [v, setV] = useState<Partial<S>>({});
  // Fill the form once from the server; later edits are never overwritten by a background refetch.
  const [filled, setFilled] = useState(false);
  useEffect(() => { if (q.data && q.isFetchedAfterMount && !filled) { setV(q.data); setFilled(true); } }, [q.data, q.isFetchedAfterMount, filled]);
  const [saving, setSaving] = useState(false);
  const submit = async (keys: (keyof S)[]) => {
    const values: Record<string, unknown> = {};
    for (const k of keys) {
      const f = FIELDS.find((x) => x.k === k);
      const isNum = f?.type === "num" || ["auto_pay_max_usd", "auto_pay_daily_limit_usd"].includes(k);
      if (isNum) {
        const n = Number(String(v[k] ?? "").replace(",", ".").trim());
        if (!Number.isFinite(n)) { toast.error(`${f?.label ?? k}: enter a number`); return; }
        values[k] = n;
      } else if (f?.type === "text") values[k] = String(v[k] ?? "").trim();
      else values[k] = v[k];
    }
    // Send only what this admin changed, so an older open form never puts back other saved values.
    const base = (q.data ?? {}) as Record<string, unknown>;
    for (const k of Object.keys(values)) if (JSON.stringify(values[k]) === JSON.stringify(base[k])) delete values[k];
    if (!Object.keys(values).length) { toast.info("No changes to save"); return; }
    setSaving(true);
    try {
      const r = await save({ data: { initData, values } });
      if ("error" in r && r.error) toast.error(r.error);
      else {
        toast.success("Settings saved");
        const fresh = await q.refetch();
        if (fresh.data) setV(fresh.data);
        qc.invalidateQueries({ queryKey: ["me"] });
      }
    } catch (e) { toast.error((e as Error).message); } finally { setSaving(false); }
  };
  return { q, v, setV, submit, saving, ready: filled };
}

export function SettingsPanel() {
  const { v, setV, submit, saving, ready } = useSettingsForm();
  if (!ready) return <Spin />;
  const groups = [...new Set(FIELDS.map((f) => f.group))];
  return (
    <div className="space-y-3">
      {groups.map((g) => (
        <Card key={g} title={g}>
          {FIELDS.filter((f) => f.group === g).map((f) => (
            <label key={f.k} className="flex items-center justify-between gap-3">
              <span className="text-sm">{f.label}</span>
              {f.type === "bool" ? (
                <Switch checked={!!v[f.k]} onCheckedChange={(c) => setV({ ...v, [f.k]: c })} />
              ) : (
                <Input value={String(v[f.k] ?? "")} onChange={(e) => setV({ ...v, [f.k]: e.target.value })} className={cn("h-10 rounded-lg", f.type === "num" ? "w-28 text-right" : "w-44")} inputMode={f.type === "num" ? "decimal" : "text"} />
              )}
            </label>
          ))}
        </Card>
      ))}
      <Button variant="hero" size="xl" className="w-full" disabled={saving} onClick={() => submit(FIELDS.map((f) => f.k))}>{saving && <Loader2 className="animate-spin" />} Save settings</Button>
    </div>
  );
}

export function AutoPay() {
  const { v, setV, submit, saving, ready } = useSettingsForm();
  if (!ready) return <Spin />;
  return (
    <div className="space-y-3">
      <Card title="Automatic withdrawals">
        <label className="flex items-center justify-between"><span className="flex items-center gap-2 text-sm"><Power className="h-4 w-4" /> Auto pay</span><Switch checked={!!v.auto_pay_enabled} onCheckedChange={(c) => setV({ ...v, auto_pay_enabled: c })} /></label>
        <label className="flex items-center justify-between gap-3"><span className="text-sm">Max per withdrawal (USDT)</span><Input value={String(v.auto_pay_max_usd ?? "")} onChange={(e) => setV({ ...v, auto_pay_max_usd: e.target.value as never })} className="h-10 w-28 rounded-lg text-right" /></label>
        <label className="flex items-center justify-between gap-3"><span className="text-sm">Daily auto pay limit (USDT)</span><Input value={String(v.auto_pay_daily_limit_usd ?? "")} onChange={(e) => setV({ ...v, auto_pay_daily_limit_usd: e.target.value as never })} className="h-10 w-28 rounded-lg text-right" /></label>
        <p className="text-xs text-muted-foreground">Withdrawals within these limits are sent instantly from the hot wallet. Bigger ones wait in Pending for an admin.</p>
        <Button variant="hero" className="w-full" disabled={saving} onClick={() => submit(["auto_pay_enabled", "auto_pay_max_usd", "auto_pay_daily_limit_usd"])}>{saving && <Loader2 className="animate-spin" />} Save auto pay</Button>
      </Card>
    </div>
  );
}

export function Broadcast() {
  const { initData } = useApp();
  const create = useServerFn(adminCreateBroadcast);
  const list = useServerFn(adminBroadcasts);
  const [target, setTarget] = useState<"all" | "single" | "multiple">("all");
  const [text, setText] = useState("");
  const [ids, setIds] = useState("");
  const [busy, setBusy] = useState(false);
  const upload = useServerFn(adminUploadPhoto);
  const [photo, setPhoto] = useState<{ id: string; preview: string } | null>(null);
  const [uploading, setUploading] = useState(false);
  const [btns, setBtns] = useState<{ text: string; url: string; sameRow: boolean }[]>([]);
  async function pickPhoto(file: File) {
    setUploading(true);
    try {
      const dataUrl = await shrinkImage(file);
      const res = await upload({ data: { initData, dataUrl } });
      if ("error" in res) toast.error(res.error);
      else { setPhoto({ id: res.photoId, preview: dataUrl }); toast.success("Image ready. A preview was sent to you in the bot."); }
    } catch (e) { toast.error((e as Error).message); } finally { setUploading(false); }
  }
  function rows() {
    const out: { text: string; url: string }[][] = [];
    for (const b of btns) {
      if (!b.text.trim() || !b.url.trim()) continue;
      const item = { text: b.text.trim(), url: b.url.trim() };
      if (b.sameRow && out.length && out[out.length - 1]!.length < 4) out[out.length - 1]!.push(item);
      else out.push([item]);
    }
    return out;
  }
  const r = useQuery({ queryKey: ["a-bc"], queryFn: () => list({ data: { initData } }) });
  const running = r.data?.find((b) => b.status === "running");
  // While a broadcast runs, drive batches from here too (the scheduled worker also sends).
  useEffect(() => {
    if (!running) return;
    let stop = false;
    const loop = async () => {
      while (!stop) {
        try { await list({ data: { initData, process: running.id } }); } catch {}
        await r.refetch();
        await new Promise((res) => setTimeout(res, 1500));
        if ((await r.refetch()).data?.find((b) => b.id === running.id)?.status !== "running") break;
      }
    };
    loop();
    return () => { stop = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running?.id]);
  return (
    <div className="space-y-3">
      <Card title="New broadcast">
        <div className="flex gap-2">
          <Pill active={target === "all"} onClick={() => setTarget("all")}>All users</Pill>
          <Pill active={target === "single"} onClick={() => setTarget("single")}>Single</Pill>
          <Pill active={target === "multiple"} onClick={() => setTarget("multiple")}>Multiple</Pill>
        </div>
        {target !== "all" && <Input value={ids} onChange={(e) => setIds(e.target.value)} placeholder={target === "single" ? "User ID" : "User IDs, separated by commas or spaces"} className="h-11 rounded-xl font-mono" />}
        <Textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="Message. Basic HTML allowed: <b>, <i>, <a href>" rows={5} className="rounded-xl" maxLength={photo ? 1024 : 4000} />
        <div className="text-right text-[11px] text-muted-foreground">{text.length}/{photo ? 1024 : 4000}</div>
        {photo ? (
          <div className="relative overflow-hidden rounded-xl border border-border">
            <img src={photo.preview} alt="Broadcast image" className="max-h-48 w-full object-cover" />
            <button type="button" aria-label="Remove image" onClick={() => setPhoto(null)} className="absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-background/80"><X className="h-4 w-4" /></button>
          </div>
        ) : (
          <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-border py-3 text-sm font-bold text-muted-foreground">
            {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-4 w-4" />} {uploading ? "Uploading..." : "Add image (optional)"}
            <input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" disabled={uploading} onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ""; if (f) pickPhoto(f); }} />
          </label>
        )}
        <div className="space-y-2">
          <div className="text-sm font-bold">Buttons (optional)</div>
          {btns.map((b, i) => (
            <div key={i} className="space-y-1.5 rounded-xl border border-border p-2">
              <div className="flex gap-1.5">
                <Input value={b.text} onChange={(e) => setBtns((x) => x.map((y, j) => (j === i ? { ...y, text: e.target.value } : y)))} placeholder="Button text" className="h-10 rounded-lg" maxLength={64} />
                <Button size="icon" variant="ghostline" aria-label="Remove button" onClick={() => setBtns((x) => x.filter((_, j) => j !== i))}><Trash2 /></Button>
              </div>
              <Input value={b.url} onChange={(e) => setBtns((x) => x.map((y, j) => (j === i ? { ...y, url: e.target.value } : y)))} placeholder="https://..." className="h-10 rounded-lg font-mono text-xs" />
              {i > 0 && (
                <label className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Switch checked={b.sameRow} onCheckedChange={(v) => setBtns((x) => x.map((y, j) => (j === i ? { ...y, sameRow: v } : y)))} /> Same line as the button above
                </label>
              )}
            </div>
          ))}
          {btns.length < 12 && <Button variant="ghostline" size="sm" className="w-full" onClick={() => setBtns((x) => [...x, { text: "", url: "", sameRow: false }])}><Plus /> Add button</Button>}
        </div>
        <Button variant="hero" className="w-full" disabled={busy || !text.trim() || !!running} onClick={async () => {
          setBusy(true);
          try {
            const list = ids.split(/[\s,]+/).map(Number).filter((n) => Number.isSafeInteger(n) && n > 0);
            const buttons = rows();
            const res = await create({ data: { initData, text, target, ids: list, ...(photo ? { photoId: photo.id } : {}), ...(buttons.length ? { buttons } : {}) } });
            if ("error" in res) toast.error(res.error); else { toast.success(`Broadcast #${res.id} started`); setText(""); setPhoto(null); setBtns([]); r.refetch(); }
          } catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
        }}><Send /> {running ? "Another broadcast is running" : "Send"}</Button>
      </Card>
      {r.data?.map((b) => (
        <Card key={b.id}>
          <div className="flex justify-between text-sm"><span className="font-bold">#{b.id} - {b.target}</span><span className={b.status === "running" ? "text-primary" : "text-success"}>{b.status}</span></div>
          <p className="line-clamp-2 text-xs text-muted-foreground">{b.photo_id ? "[image] " : ""}{b.text}{Array.isArray(b.buttons) && b.buttons.length ? ` [${(b.buttons as unknown[][]).flat().length} buttons]` : ""}</p>
          <div className="h-2 overflow-hidden rounded-full bg-accent"><div className="h-full bg-primary" style={{ width: `${b.total ? ((b.sent + b.failed) / b.total) * 100 : 100}%` }} /></div>
          <div className="grid grid-cols-3 text-xs"><span>Total {b.total}</span><span className="text-success">Delivered {b.sent}</span><span className="text-destructive">Failed {b.failed}</span></div>
        </Card>
      ))}
    </div>
  );
}

export function Tasks() {
  const { initData } = useApp();
  const fn = useServerFn(adminTasks);
  const qc = useQueryClient();
  const r = useQuery({ queryKey: ["a-tasks"], queryFn: () => fn({ data: { initData, op: "list" } }) });
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [reward, setReward] = useState("5");
  const [rtype, setRtype] = useState<"points" | "usdt">("points");
  const [usdt, setUsdt] = useState("0.01");
  const op = async (o: "create" | "toggle" | "delete", id?: number) => {
    try {
      const rows = await fn({ data: { initData, op: o, id, title: o === "create" ? title : undefined, url: o === "create" ? url : undefined, reward: Number(reward) || 0, rewardType: rtype, rewardUsdt: Number(usdt) || 0 } });
      qc.setQueryData(["a-tasks"], rows);
      if (o === "create") { setTitle(""); setUrl(""); toast.success("Task created"); }
    } catch (e) { toast.error((e as Error).message); }
  };
  return (
    <div className="space-y-3">
      <Card title="Create a task">
        <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Task title" maxLength={80} className="h-11 rounded-xl" />
        <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://t.me/your_channel" className="h-11 rounded-xl" />
        <div className="flex gap-2">
          <Pill active={rtype === "points"} onClick={() => setRtype("points")}>Points reward</Pill>
          <Pill active={rtype === "usdt"} onClick={() => setRtype("usdt")}>USDT reward</Pill>
        </div>
        {rtype === "points" ? (
          <Input value={reward} onChange={(e) => setReward(e.target.value.replace(/\D/g, ""))} placeholder="Reward points" className="h-11 rounded-xl" inputMode="numeric" />
        ) : (
          <Input value={usdt} onChange={(e) => setUsdt(e.target.value.replace(/[^0-9.]/g, ""))} placeholder="Reward in USDT" className="h-11 rounded-xl" inputMode="decimal" />
        )}
        {rtype === "usdt" && <p className="text-xs text-muted-foreground">USDT rewards are added to the user's real balance and can be withdrawn. Every completed task costs you this amount.</p>}
        <p className="text-xs text-muted-foreground">For t.me channel links, make the main bot an admin of the channel so joining can be verified.</p>
        <Button variant="hero" className="w-full" disabled={!title || !/^https:\/\//.test(url)} onClick={() => op("create")}><Plus /> Create task</Button>
      </Card>
      {r.isLoading ? <Spin /> : r.data?.map((t) => (
        <div key={t.id} className="surface flex items-center gap-3 p-3">
          <div className="min-w-0 flex-1">
            <div className="truncate font-bold">{t.title}</div>
            <div className="truncate text-xs text-muted-foreground">{t.url} - {t.reward_type === "usdt" ? `${t.reward_usdt} USDT` : `${t.reward_points} pts`}</div>
          </div>
          <Switch checked={t.active} onCheckedChange={() => op("toggle", t.id)} />
          <button aria-label="Delete" onClick={() => confirm("Delete this task?") && op("delete", t.id)}><Trash2 className="h-4 w-4 text-destructive" /></button>
        </div>
      ))}
    </div>
  );
}

export function Logs() {
  const { initData } = useApp();
  const fn = useServerFn(adminLogs);
  const r = useQuery({ queryKey: ["a-logs"], queryFn: () => fn({ data: { initData } }) });
  return (
    <div className="space-y-2">
      <Button size="sm" variant="ghostline" onClick={() => r.refetch()}><RefreshCw /> Refresh</Button>
      {r.isLoading ? <Spin /> : !r.data?.length ? <Empty>No admin actions yet</Empty> : r.data.map((l) => (
        <div key={l.id} className="surface p-3 text-xs">
          <div className="flex justify-between"><span className="font-bold">{l.action}</span><span className="text-muted-foreground">{new Date(l.created_at).toLocaleString()}</span></div>
          <div className="text-muted-foreground">Admin {l.admin_id}</div>
          <div className="break-all font-mono text-[10px]">{l.details}</div>
        </div>
      ))}
    </div>
  );
}

export function Channels() {
  const { initData } = useApp();
  const get = useServerFn(adminGetSettings);
  const save = useServerFn(adminSaveSettings);
  const test = useServerFn(adminTestChannel);
  const q = useQuery({ queryKey: ["a-settings"], queryFn: () => get({ data: { initData } }), refetchOnWindowFocus: false, refetchOnMount: "always" });
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false);
  const list = q.data?.required_channels ?? [];
  async function store(next: typeof list) {
    const r = await save({ data: { initData, values: { required_channels: next } } });
    if ("error" in r && r.error) { toast.error(r.error); return false; }
    await q.refetch();
    return true;
  }
  if (!q.isFetchedAfterMount) return <Spin />;
  return (
    <div className="space-y-3">
      <Card title="Add a required channel">
        <p className="text-xs text-muted-foreground">Users must join every channel here before the app opens. Make the main bot an admin of each channel so joining can be checked.</p>
        <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Channel name shown to users" maxLength={60} className="h-11 rounded-xl" />
        <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://t.me/your_channel" className="h-11 rounded-xl" />
        <Button variant="hero" className="w-full" disabled={busy || !title.trim() || url.trim().length < 3} onClick={async () => {
          setBusy(true);
          try {
            const t = await test({ data: { initData, url: url.trim() } });
            if (!t.ok) { toast.error(t.error ?? "Bot cannot check this channel"); return; }
            if (await store([...list, { title: title.trim(), url: url.trim(), chat: t.chat ?? "" }])) { setTitle(""); setUrl(""); toast.success("Channel added"); }
          } catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
        }}>{busy ? <Loader2 className="animate-spin" /> : <Plus />} Add channel</Button>
      </Card>
      {!list.length ? <Empty>No required channels. The app opens for everyone.</Empty> : list.map((c, i) => (
        <div key={c.url + i} className="surface flex items-center gap-3 p-3">
          <div className="min-w-0 flex-1">
            <div className="truncate font-bold">{c.title}</div>
            <div className="truncate text-xs text-muted-foreground">{c.url}</div>
          </div>
          <button aria-label="Remove" onClick={async () => { if (confirm(`Remove ${c.title}?`) && (await store(list.filter((_, j) => j !== i)))) toast.success("Removed"); }}><Trash2 className="h-4 w-4 text-destructive" /></button>
        </div>
      ))}
    </div>
  );
}

/** Resizes a picked image to at most 1280px and JPEG, so uploads stay small. */
async function shrinkImage(file: File): Promise<string> {
  if (file.size > 15_000_000) throw new Error("Image is too large");
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error("Could not read this image")); i.src = url; });
    const k = Math.min(1, 1280 / Math.max(img.width, img.height));
    const c = document.createElement("canvas");
    c.width = Math.round(img.width * k);
    c.height = Math.round(img.height * k);
    c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL("image/jpeg", 0.85);
  } finally {
    URL.revokeObjectURL(url);
  }
}
