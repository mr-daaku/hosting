# OminiAi Prompt 4 update

## Goal
Polish the home actions and fullscreen spacing, make deposit rates reliable, add English/Russian/Chinese/Arabic language support, install the new OminiAi icon, and hide the Lovable badge.

## What will change
- Replace the two home action buttons with one compact split control: **Claim | How to earn**.
- Add an admin-editable minimum claim amount, defaulting to **0.01 USDT**. Enforce it both visually and on the server.
- Reduce the top spacing to roughly 60% of its current Telegram-safe offset while still using Telegram/device safe-area values.
- Make live native-coin conversion resilient: visible loading state, retry, cached price data, and a last-updated/fallback state instead of permanent ellipses.
- Cache frequently read app settings briefly in server memory and invalidate that cache after an admin saves settings.
- Add `react-i18next` with English, Russian, Chinese, and Arabic translation resources; connect the Account language selector, persist the choice, and set page direction for Arabic.
- Externalize user-facing interface copy across the customer-facing screens and shared navigation. Admin operational copy remains English unless it is also shared with customer screens.
- Use the generated OminiAi app icon in the app/loading experience and create a lightweight matching favicon.
- Hide the Lovable badge globally.

## Data and safety
- Add `min_claim_usdt = 0.01` to app settings through a database migration.
- Keep the existing estimated/non-guaranteed profit wording and current yield rate unchanged.
- Keep live-rate caching short-lived so displayed conversions remain current.

## Verification
- Check code/build diagnostics after changes.
- Verify home, deposit, account language switching, Arabic RTL, and icon rendering in desktop and narrow mobile views.
- Confirm a claim below 0.01 is disabled in the interface and rejected by the server.
