import { Toaster as Sonner } from "sonner";

type ToasterProps = React.ComponentProps<typeof Sonner>;

/** OminiAi-branded toasts: card surface, lime accent edge, display font. */
const Toaster = ({ ...props }: ToasterProps) => {
  return (
    <Sonner
      className="toaster group"
      offset={{ top: "calc(var(--tg-content-safe-area-inset-top, 0px) + var(--tg-safe-area-inset-top, 0px) + 12px)" }}
      toastOptions={{
        unstyled: true,
        classNames: {
          toast:
            "flex w-full items-center gap-3 rounded-2xl border border-primary/30 border-l-4 border-l-primary bg-popover/95 px-4 py-3 text-sm font-semibold text-popover-foreground shadow-2xl backdrop-blur font-display",
          title: "leading-snug",
          description: "text-xs font-normal text-muted-foreground",
          success: "!border-l-success [&_[data-icon]]:text-success",
          error: "!border-l-destructive [&_[data-icon]]:text-destructive",
          icon: "text-primary",
          actionButton: "rounded-lg bg-primary px-2 py-1 text-primary-foreground",
          cancelButton: "rounded-lg bg-muted px-2 py-1 text-muted-foreground",
        },
      }}
      {...props}
    />
  );
};

export { Toaster };
