import { Link } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { verifyChannels } from "@/lib/app.functions";
import { openLink } from "@/lib/tg";
import { CandlestickChart, Users, Gift, User, Home, Loader2, ShieldAlert, Send } from "lucide-react";
import { useMe, useTg } from "@/lib/tg";
import { LOGO } from "@/lib/assets";
import { useTranslation } from "react-i18next";
import appIcon from "@/assets/ominiai-app-icon.png";

export function CoinImg({ src = LOGO.COIN, size = 20, className = "" }: { src?: string; size?: number; className?: string }) {
  return <img src={src} alt="" width={size} height={size} className={`inline-block shrink-0 rounded-full object-contain ${className}`} style={{ width: size, height: size }} loading="lazy" />;
}

const NAV = [
  { to: "/trade", label: "nav.trade", icon: CandlestickChart },
  { to: "/friends", label: "nav.friends", icon: Users },
  { to: "/gifts", label: "nav.gifts", icon: Gift },
  { to: "/account", label: "nav.account", icon: User },
] as const;

export function Shell({ children, hideNav, isPublic }: { children: ReactNode; hideNav?: boolean; isPublic?: boolean }) {
  const { t } = useTranslation();
  const { status, error } = useTg();
  const me = useMe();

  let body: ReactNode = children;
  if (isPublic) {
    body = children;
  } else if (status === "loading" || (status === "ready" && me.isLoading)) {
    body = <Center><img src={appIcon} alt="OminiAi" width={1024} height={1024} className="h-20 w-20 animate-pulse rounded-2xl" /><Loader2 className="mt-4 h-5 w-5 animate-spin text-primary" /></Center>;
  } else if (status === "outside") {
    body = (
      <Center>
        <img src={appIcon} alt="OminiAi" width={1024} height={1024} className="mb-6 h-28 w-28 rounded-3xl" />
        <h1 className="text-2xl font-bold">{t("shell.openTitle")}</h1>
        <p className="mt-2 text-sm text-muted-foreground">{t("shell.openText")}</p>
        <a href="https://t.me/OminixAiBot" className="mt-6 inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground">
          <Send className="h-4 w-4" /> {t("shell.openBot")}
        </a>
        <Link to="/legal" className="mt-4 text-sm text-muted-foreground underline">{t("shell.legal")}</Link>
      </Center>
    );
  } else if (status === "error" || (me.error && !me.data)) {
    body = (
      <Center>
        <ShieldAlert className="mb-3 h-10 w-10 text-destructive" />
        <p className="font-semibold">{t("shell.error")}</p>
        <p className="mt-1 text-sm text-muted-foreground">{error || (me.error as Error)?.message}</p>
        <button onClick={() => void me.refetch()} disabled={me.isFetching} aria-busy={me.isFetching} className="mt-5 inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground disabled:opacity-60">
          {me.isFetching ? <Loader2 className="h-4 w-4 animate-spin" /> : null}{t("common.retry")}
        </button>
      </Center>
    );
  } else if (me.data?.me.banned) {
    body = (
      <Center>
        <ShieldAlert className="mb-3 h-10 w-10 text-destructive" />
        <p className="text-lg font-semibold">{t("shell.restricted")}</p>
        <p className="mt-1 text-sm text-muted-foreground">
          {me.data.me.banReason === "duplicate device" ? t("shell.duplicate") : t("shell.restrictedText")} {t("shell.support")}
        </p>
      </Center>
    );
  }

  return (
    <div className="safe-top mx-auto min-h-screen w-full max-w-md overflow-x-hidden px-4 pb-36">
      {body}
      {!isPublic && status === "ready" && me.data && !me.data.me.banned && me.data.settings.channels.length > 0 && <JoinGate channels={me.data.settings.channels} />}
      {!hideNav && status === "ready" && me.data && !me.data.me.banned && <BottomNav />}
    </div>
  );
}

function Center({ children }: { children: ReactNode }) {
  return <div className="flex min-h-[70vh] flex-col items-center justify-center text-center">{children}</div>;
}

function BottomNav() {
  const { t } = useTranslation();
  const item = "flex flex-1 flex-col items-center gap-1 py-2 text-[11px] font-medium text-muted-foreground";
  return (
    <nav className="safe-bottom fixed inset-x-0 bottom-0 z-50 mx-auto w-full max-w-md px-3">
      <div className="relative flex items-end rounded-3xl border border-border bg-popover/95 px-2 pt-1 shadow-2xl backdrop-blur">
        {NAV.slice(0, 2).map((n) => (
          <Link key={n.to} to={n.to} className={item} activeProps={{ className: "!text-primary" }}>
            <n.icon className="h-5 w-5" />{t(n.label)}
          </Link>
        ))}
        <div className="flex flex-1 justify-center">
          <Link to="/" aria-label={t("nav.home")} className="-mt-7 mb-2 flex h-16 w-16 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg ring-4 ring-background">
            <Home className="h-7 w-7" />
          </Link>
        </div>
        {NAV.slice(2).map((n) => (
          <Link key={n.to} to={n.to} className={item} activeProps={{ className: "!text-primary" }}>
            <n.icon className="h-5 w-5" />{t(n.label)}
          </Link>
        ))}
      </div>
    </nav>
  );
}

export function PageTitle({ children, right }: { children: ReactNode; right?: ReactNode }) {
  return (
    <div className="mb-4 flex items-center justify-between">
      <h1 className="text-2xl font-bold">{children}</h1>
      {right}
    </div>
  );
}

export const card = "rounded-3xl border border-border bg-card p-4";

// Channels are checked on every app open; passing is remembered only for this open session.
let gatePassed = false;
function markGatePassed() { gatePassed = true; }
function JoinGate({ channels }: { channels: string[] }) {
  const { t } = useTranslation();
  const { initData } = useTg();
  const [done, setDone] = useState(gatePassed);
  const [busy, setBusy] = useState(false);
  const [missing, setMissing] = useState<string[]>([]);
  const [checked, setChecked] = useState(gatePassed);
  useEffect(() => {
    if (gatePassed) return;
    verifyChannels({ data: { initData } }).then((r) => {
      if (r.ok) { markGatePassed(); setDone(true); }
      else setMissing(r.results.filter((x) => !x.joined).map((x) => x.channel));
    // Check failed: keep the join pop-up; user can tap Verify to retry.
    }).catch(() => {}).finally(() => setChecked(true));
  }, [initData]);
  if (done) return null;
  if (!checked) return <div className="fixed inset-0 z-[60] flex items-center justify-center bg-background"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>;
  const link = (c: string) => (/^-100/.test(c) ? null : /^https?:/i.test(c) ? c : `https://t.me/${c.replace(/^@/, "")}`);
  const verify = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const r = await verifyChannels({ data: { initData } });
      if (r.ok) { markGatePassed(); setDone(true); }
      else setMissing(r.results.filter((x) => !x.joined).map((x) => x.channel));
    } catch { /* keep gate */ } finally { setBusy(false); }
  };
  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-background p-4 sm:items-center">
      <div className="w-full max-w-md rounded-3xl border border-border bg-card p-5 shadow-2xl">
        <img src={appIcon} alt="" width={1024} height={1024} className="mx-auto h-14 w-14 rounded-2xl" />
        <h2 className="mt-3 text-center text-xl font-bold">{t("gate.title")}</h2>
        <p className="mt-1 text-center text-sm text-muted-foreground">{t("gate.text")}</p>
        <div className="mt-4 space-y-2">
          {channels.map((c, i) => {
            const url = link(c);
            const miss = missing.includes(c);
            return (
              <div key={c} className={`flex items-center gap-3 rounded-2xl border p-3 ${miss ? "border-destructive" : "border-border"} bg-muted`}>
                <div className="min-w-0 flex-1">
                  <p className="text-xs text-muted-foreground">{i === 0 && channels.length > 1 ? t("gate.channel") : channels.length > 1 ? t("gate.payment") : t("gate.channel")}</p>
                  <p className="truncate font-semibold">{c.replace(/^https?:\/\/t\.me\//, "@")}</p>
                  {miss && <p className="text-xs text-destructive">{t("gate.missing")}</p>}
                </div>
                {url && <button onClick={() => openLink(url)} className="rounded-full bg-primary px-4 py-2 text-sm font-bold text-primary-foreground">{t("gate.join")}</button>}
              </div>
            );
          })}
        </div>
        <button disabled={busy} aria-busy={busy} onClick={verify} className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-secondary py-3 font-bold text-secondary-foreground disabled:opacity-60">
          {busy && <Loader2 className="h-4 w-4 animate-spin" />}{t("gate.verify")}
        </button>
      </div>
    </div>
  );
}
