import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { Copy, Send } from "lucide-react";
import { Shell, CoinImg, PageTitle, card } from "@/components/app/Shell";
import { useMe, useTg, openLink, haptic } from "@/lib/tg";
import { getHistory } from "@/lib/app.functions";
import { fmt } from "@/lib/assets";
import { useTranslation } from "react-i18next";

export const Route = createFileRoute("/friends")({
  head: () => ({
    meta: [
      { title: "Invite friends — OminiAi" },
      { name: "description", content: "Share your invite link and earn coins for every friend who joins and deposits." },
      { property: "og:title", content: "Invite friends — OminiAi" },
      { property: "og:description", content: "Earn coins for every friend you invite to OminiAi." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => <Shell><Friends /></Shell>,
});

function Friends() {
  const { t } = useTranslation();
  const { data } = useMe();
  const { initData, status } = useTg();
  const hist = useQuery({ queryKey: ["history"], queryFn: () => getHistory({ data: { initData } }), enabled: status === "ready" });
  if (!data) return null;
  const share = () => openLink(`https://t.me/share/url?url=${encodeURIComponent(data.refLink)}&text=${encodeURIComponent(t("friends.shareText"))}`);

  return (
    <div className="space-y-4">
      <PageTitle>{t("friends.title")}</PageTitle>
      <div className={card}>
         <p className="text-lg font-bold">{t("friends.heading")}</p>
        <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
           <li className="flex items-center gap-2"><CoinImg size={16} /> {t("friends.join", { coins: data.settings.referralCoins })}</li>
        </ul>
        <div className="mt-4 flex items-center gap-2 rounded-2xl bg-muted p-3">
          <p className="flex-1 truncate font-mono text-xs">{data.refLink}</p>
           <button onClick={() => navigator.clipboard.writeText(data.refLink).then(() => { haptic("success"); toast.success(t("friends.copied")); })} aria-label={t("friends.copied")}><Copy className="h-4 w-4" /></button>
        </div>
         <button onClick={share} className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-3 font-bold text-primary-foreground"><Send className="h-4 w-4" /> {t("friends.share")}</button>
      </div>

      <div className="grid grid-cols-2 gap-3">
         <div className={card}><p className="text-xs text-muted-foreground">{t("friends.invited")}</p><p className="font-display text-2xl font-bold">{data.invited}</p></div>
         <div className={card}><p className="text-xs text-muted-foreground">{t("friends.total")}</p><p className="flex items-center gap-1 font-display text-2xl font-bold"><CoinImg size={20} />{fmt(data.me.referralEarnings, 0)}</p></div>
      </div>

      <div>
         <p className="mb-2 font-semibold">{t("friends.yourFriends")}</p>
         {(hist.data?.friends ?? []).length === 0 ? <p className="text-sm text-muted-foreground">{t("friends.empty")}</p> : (
          <div className="space-y-2">
            {hist.data!.friends.map((f) => (
              <div key={f.id} className={`${card} flex items-center gap-3 py-3`}>
                <div className="flex h-9 w-9 items-center justify-center overflow-hidden rounded-full bg-muted font-bold">{f.photo ? <img src={f.photo} alt="" className="h-full w-full object-cover" /> : f.name[0]}</div>
                <p className="flex-1 truncate font-medium">{f.name}</p>
                <span className="flex items-center gap-1 text-sm text-success">+{fmt(f.earned, 0)} <CoinImg size={14} /></span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
