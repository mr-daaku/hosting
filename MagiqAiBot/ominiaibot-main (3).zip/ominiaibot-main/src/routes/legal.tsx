import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { useState } from "react";
import { Shell, PageTitle, card } from "@/components/app/Shell";

export const Route = createFileRoute("/legal")({
  head: () => ({
    meta: [
      { title: "Legal — OminiAi" },
      { name: "description", content: "OminiAi Terms of Service, Privacy Policy, Risk Disclosure, AML policy and reward rules." },
      { property: "og:title", content: "Legal — OminiAi" },
      { property: "og:description", content: "Terms, privacy, risk disclosure and reward rules for OminiAi." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => <Shell isPublic><Legal /></Shell>,
});

const UPDATED = "September 24, 2026";

const DOCS: { id: string; title: string; sections: [string, string][] }[] = [
  {
    id: "terms", title: "Terms of Service",
    sections: [
      ["1. Acceptance", "By opening or using the OminiAi Telegram Mini App (\"the Service\") you agree to these Terms. If you do not agree, do not use the Service."],
      ["2. Eligibility", "You must be at least 18 years old and legally allowed to use crypto-asset services in your country. You are responsible for complying with your local laws and tax obligations."],
      ["3. Accounts", "Each person may hold only one account. Accounts are linked to your Telegram profile and device. Accounts created from a device that already has an account are automatically restricted and are not eligible for any rewards."],
      ["4. Deposits", "Each user receives personal deposit addresses. Only send the exact coin and network shown. Deposits sent on the wrong network, below the minimum, or without the required GRAM memo may be lost and cannot be guaranteed to be recovered."],
      ["5. Coins", "Coins are an internal reward unit of the Service. They are not a cryptocurrency, security or legal tender and cannot be transferred outside the Service."],
      ["6. Profit and returns", "Any income, profit or yield figures shown in the Service are estimates only. Returns are NOT guaranteed, can change at any time, and past results do not indicate future results. You may lose some or all of the value you deposit."],
      ["7. Withdrawals", "Withdrawals are reviewed manually and may be delayed, limited or rejected, for example for security, suspected fraud, or legal reasons. Minimums and fees are shown before you submit a request."],
      ["8. Prohibited use", "You may not use the Service for money laundering, fraud, multi-accounting, bots or exploiting bugs. We may restrict accounts and withhold rewards obtained through prohibited use."],
      ["9. Changes and termination", "We may change reward rates, fees, features or these Terms, or suspend the Service. Continued use after changes means you accept them."],
      ["10. Liability", "The Service is provided \"as is\". To the maximum extent permitted by law, the operator is not liable for indirect losses, market losses, blockchain network issues, or losses caused by user error."],
    ],
  },
  {
    id: "privacy", title: "Privacy Policy",
    sections: [
      ["Data we collect", "Telegram ID, name, username and profile photo provided by Telegram; your balances and withdrawal requests. Deposit addresses are generated from your account number and are not stored as a list."],
      ["How we use it", "To run your account, credit deposits, process withdrawals, pay rewards, prevent fraud, and send service messages through the Telegram bot."],
      ["Sharing", "We do not sell your data. Public blockchain data is visible to anyone. We may share data when required by law or to prevent fraud."],
      ["Retention", "We keep account and transaction records for as long as needed to operate the Service and meet legal obligations."],
      ["Your choices", "You can stop using the Service at any time and contact support to request access to or deletion of your personal data, subject to legal record-keeping requirements."],
    ],
  },
  {
    id: "risk", title: "Risk Disclosure",
    sections: [
      ["High risk", "Crypto-assets are highly volatile. Their value can fall sharply and quickly. Only deposit what you can afford to lose."],
      ["No guarantee", "Estimated income shown in the app is not a promise or guarantee of profit. Rates may be changed or stopped at any time."],
      ["Trading risk", "Where funds are used in trading activity, trading can result in losses, including total loss."],
      ["Operational risk", "Blockchain networks, third-party services and software can fail, be delayed or be attacked."],
      ["Regulatory risk", "Laws on crypto-assets differ by country and can change. The Service may not be available or legal where you live."],
      ["Not advice", "Nothing in the Service is financial, investment, legal or tax advice."],
    ],
  },
  {
    id: "aml", title: "AML & Anti-Fraud Policy",
    sections: [
      ["Monitoring", "We monitor deposits, withdrawals and account activity for suspicious behaviour."],
      ["Verification", "We may ask for identity verification before processing withdrawals, especially large or unusual ones."],
      ["Actions", "We may delay, reject or report transactions and restrict accounts involved in money laundering, fraud, sanctions violations or multi-accounting."],
    ],
  },
  {
    id: "rewards", title: "Rewards & Referral Rules",
    sections: [
      ["Welcome bonus", "New eligible accounts receive a one-time coin bonus."],
      ["Referrals", "You earn coins when an eligible new user opens the app from your link, and a percentage of their deposits in coins. Self-referrals and duplicate-device accounts do not qualify."],
      ["Gifts", "A free gift with a random number of coins can be opened once per account."],
      ["Changes", "Reward amounts and percentages can be changed at any time and are shown in the app."],
    ],
  },
];

function Legal() {
  const [open, setOpen] = useState("terms");
  const doc = DOCS.find((d) => d.id === open)!;
  return (
    <div>
      <PageTitle right={<Link to="/account" className="inline-flex items-center gap-1 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" />Back</Link>}>Legal</PageTitle>
      <div className="-mx-4 mb-4 flex gap-2 overflow-x-auto px-4 pb-1">
        {DOCS.map((d) => (
          <button key={d.id} onClick={() => setOpen(d.id)} className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold ${open === d.id ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>{d.title}</button>
        ))}
      </div>
      <article className={`${card} space-y-4`}>
        <div><h2 className="text-xl font-bold">{doc.title}</h2><p className="text-xs text-muted-foreground">Last updated {UPDATED}</p></div>
        {doc.sections.map(([h, t]) => (
          <section key={h}><h3 className="font-semibold">{h}</h3><p className="mt-1 text-sm leading-relaxed text-muted-foreground">{t}</p></section>
        ))}
        <p className="border-t border-border pt-3 text-xs text-muted-foreground">Questions? Contact support through @OminixAiBot on Telegram.</p>
      </article>
    </div>
  );
}
