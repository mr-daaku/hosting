import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, ChevronRight, Info } from "lucide-react";
import { Shell, CoinImg, PageTitle, card } from "@/components/app/Shell";
import { WITHDRAW_OPTIONS, fmt } from "@/lib/assets";
import { useMe, useTg, useRefreshMe, haptic } from "@/lib/tg";
import { requestWithdrawal } from "@/lib/app.functions";
import { useTranslation } from "react-i18next";

export const Route = createFileRoute("/withdraw")({
  head: () => ({
    meta: [
      { title: "USDT withdrawal — OminiAi" },
      { name: "description", content: "Request a USDT withdrawal to your BEP20 or GRAM wallet." },
      { property: "og:title", content: "USDT withdrawal — OminiAi" },
      { property: "og:description", content: "Withdraw your USDT balance to your own BEP20 or GRAM wallet." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => <Shell><Withdraw /></Shell>,
});

function Withdraw() {
  const { t, i18n } = useTranslation();
  const { data } = useMe();
  const { initData } = useTg();
  const refresh = useRefreshMe();
  const nav = useNavigate();
  const [amount, setAmount] = useState("");
  const [sel, setSel] = useState<number | null>(null);
  const [address, setAddress] = useState("");
  const [busy, setBusy] = useState(false);
  if (!data) return null;
  const s = data.settings;
  const me = data.me;
  const available = Math.max(0, me.usdt - me.adminFrozen);
  const noDeposit = me.totalDeposit < Math.max(s.minDepositUsd || 0, 1e-9);
  const freeLeft = Math.max(0, s.freeWithdrawalCap - me.withdrawnOrPending);

  if (s.withdrawalsOpen === false) {
    const lang = (i18n.language || "en").slice(0, 2);
    const msg = ({
      en: ["Withdrawals are closed", "Withdrawals are temporarily turned off. Please try again later — your balance is safe."],
      ru: ["Вывод закрыт", "Вывод временно отключён. Попробуйте позже — ваш баланс в безопасности."],
      zh: ["提现已关闭", "提现暂时关闭，请稍后再试——您的余额是安全的。"],
      ar: ["السحب مغلق", "السحب متوقف مؤقتًا. يرجى المحاولة لاحقًا — رصيدك آمن."],
    } as Record<string, [string, string]>)[lang] ?? ["Withdrawals are closed", "Withdrawals are temporarily turned off. Please try again later — your balance is safe."];
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 p-6 backdrop-blur-sm">
        <div className={`${card} w-full max-w-sm text-center`}>
          <Info className="mx-auto h-10 w-10 text-gold" />
          <p className="mt-3 text-lg font-bold">{msg[0]}</p>
          <p className="mt-2 text-sm text-muted-foreground">{msg[1]}</p>
          <Link to="/" className="mt-4 block rounded-2xl bg-primary py-3 font-bold text-primary-foreground">{t("common.back")}</Link>
        </div>
      </div>
    );
  }

  if (sel === null) {
    return (
      <div>
        <PageTitle right={<Link to="/" className="inline-flex items-center gap-1 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" />{t("common.back")}</Link>}>{t("withdraw.title")}</PageTitle>
        <p className="mb-3 text-sm text-muted-foreground">{t("withdraw.choose")}</p>
        <div className="space-y-2">
          {WITHDRAW_OPTIONS.map((o, i) => (
            <button key={o.chain} onClick={() => { if ((o.chain === "ton" ? s.gramOpen : s.bep20Open) === false) { toast.error("This withdrawal method is not available right now."); return; } setSel(i); }} className={`${card} flex w-full items-center gap-3 text-left`}>
              <span className="relative"><CoinImg src={o.logo} size={36} /><CoinImg src={o.chainLogo} size={16} className="absolute -bottom-1 -right-1 ring-2 ring-card" /></span>
              <div className="flex-1"><p className="font-semibold">{o.label}</p><p className="text-xs text-muted-foreground">{o.network}</p></div>
              {(o.chain === "ton" ? s.gramOpen : s.bep20Open) === false ? <span className="text-xs font-semibold text-destructive">Not available</span> : <ChevronRight className="h-5 w-5 text-muted-foreground" />}
            </button>
          ))}
        </div>
      </div>
    );
  }

  const opt = WITHDRAW_OPTIONS[sel]!;
  const amt = Number(amount) || 0;
  const fee = s.feeType === "percent" ? (amt * s.feeValue) / 100 : s.feeValue;
  const max = noDeposit ? Math.min(available, freeLeft) : available;

  const submit = async (): Promise<void> => {
    if (amt < s.minWithdrawal) { toast.error(`Minimum is ${s.minWithdrawal} USDT`); return; }
    if (amt > available) { toast.error("Not enough available USDT"); return; }
    if (noDeposit && amt > freeLeft) { toast.error(freeLeft <= 0 ? `Free withdrawal limit used. Please deposit at least $${s.minDepositUsd} first.` : `Without a deposit you can withdraw up to ${freeLeft.toFixed(4)} USDT more.`); return; }
    if (address.trim().length < 10) { toast.error("Enter your wallet address"); return; }
    setBusy(true);
    try {
      await requestWithdrawal({ data: { initData, chain: opt.chain, asset: opt.asset, address: address.trim(), amount: amt } });
      haptic("success");
      toast.success("Withdrawal request submitted. It will be reviewed shortly.");
      refresh();
      nav({ to: "/account" });
    } catch (e) { haptic("error"); toast.error((e as Error).message); } finally { setBusy(false); }
  };

  return (
    <div>
       <PageTitle right={<button onClick={() => setSel(null)} className="inline-flex items-center gap-1 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" />{t("common.back")}</button>}>
        <span className="inline-flex items-center gap-2"><CoinImg src={opt.logo} size={28} /> {opt.label}</span>
      </PageTitle>
      <div className={`${card} grid grid-cols-2 gap-2`}>
         <div className="min-w-0"><p className="text-xs text-muted-foreground">{t("withdraw.available")}</p><p className="truncate font-mono text-lg">{fmt(available, 4)}</p></div>
         <div className="min-w-0"><p className="text-xs text-muted-foreground">{t("withdraw.frozen")}</p><p className="truncate font-mono text-lg">{fmt(me.frozen + me.adminFrozen, 4)}</p></div>
      </div>
      {noDeposit && (
        <div className="mt-3 flex gap-2 rounded-2xl bg-muted p-3 text-xs text-muted-foreground">
          <Info className="h-4 w-4 shrink-0 text-secondary" />
          {freeLeft > 0 ? `Without a deposit you can withdraw up to ${s.freeWithdrawalCap} USDT in total. Remaining: ${freeLeft.toFixed(4)} USDT.` : `You have used your free withdrawal limit. Please deposit at least $${s.minDepositUsd} to withdraw more.`}
        </div>
      )}

       <p className="mb-2 mt-4 text-sm font-semibold text-muted-foreground">{t("withdraw.amount")}</p>
      <div className={`${card} flex items-center`}>
        <input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))} placeholder="0.00" className="w-full min-w-0 bg-transparent font-display text-2xl font-bold outline-none" />
        <button onClick={() => setAmount(String(Math.floor(max * 1e4) / 1e4))} className="mr-2 text-xs font-semibold text-primary">MAX</button>
        <span className="text-muted-foreground">USDT</span>
      </div>
       <p className="mt-1 text-xs text-muted-foreground">{t("withdraw.minimum", { amount: s.minWithdrawal })} · {t("withdraw.fee", { amount: fee.toFixed(4) })} · {t("withdraw.receive", { amount: Math.max(0, amt - fee).toFixed(4) })}</p>

       <p className="mb-2 mt-4 text-sm font-semibold text-muted-foreground">{t("withdraw.address", { coin: opt.label })}</p>
      <input value={address} onChange={(e) => setAddress(e.target.value)} placeholder={opt.chain === "ton" ? "UQ… or EQ…" : "0x…"} className={`${card} w-full font-mono text-sm outline-none`} />

      <button onClick={submit} disabled={busy} aria-busy={busy} className="mt-5 w-full rounded-2xl bg-primary py-4 font-bold text-primary-foreground disabled:opacity-60">
         {busy ? t("withdraw.submitting") : t("withdraw.submit")}
      </button>
       <p className="mt-2 text-center text-xs text-muted-foreground">{t("withdraw.note")}</p>
    </div>
  );
}
