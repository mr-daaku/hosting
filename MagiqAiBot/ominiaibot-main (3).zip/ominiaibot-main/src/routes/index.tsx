import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { TrendingUp, Upload, Download, Zap, Info, Shield } from "lucide-react";
import { Shell, CoinImg, card } from "@/components/app/Shell";
import { useMe, useTg, useRefreshMe, haptic } from "@/lib/tg";
import { claimProfit } from "@/lib/app.functions";
import { LOGO, fmt } from "@/lib/assets";
import { useTranslation } from "react-i18next";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "OminiAi — Your crypto wallet & rewards" },
      { name: "description", content: "Check your coins and USDT balance, claim estimated daily profit and top up with crypto." },
      { property: "og:title", content: "OminiAi — Your crypto wallet & rewards" },
      { property: "og:description", content: "Coins, USDT balance, estimated daily profit and deposits on Telegram." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Home,
});

function Home() {
  return <Shell><HomeBody /></Shell>;
}

function HomeBody() {
  const { t } = useTranslation();
  const { data } = useMe();
  const { initData } = useTg();
  const refresh = useRefreshMe();
  const [busy, setBusy] = useState(false);
  const [live, setLive] = useState(0);
  const [showInfo, setShowInfo] = useState(false);

  const me = data?.me;
  const perDay = me ? (me.coins * (data!.settings.dailyYieldPct)) / 100 : 0;

  useEffect(() => {
    if (!me) return;
    const tick = () => {
      const days = (Date.now() - new Date(me.lastYieldAt).getTime()) / 86400000;
      setLive(Math.max(0, perDay * days));
    };
    tick();
    const t = setInterval(tick, 200);
    return () => clearInterval(t);
  }, [me?.lastYieldAt, perDay]);

  if (!data || !me) return null;

  const claim = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const r = await claimProfit({ data: { initData } });
      haptic("success");
      toast.success(t("home.claimed", { amount: r.amount.toFixed(6) }));
      refresh();
    } catch (e) {
      haptic("error");
      toast.error((e as Error).message);
    } finally { setBusy(false); }
  };

  const whole = Math.floor(live);
  const frac = (live - whole).toFixed(8).slice(1);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <div className="h-20 w-20 shrink-0 overflow-hidden rounded-full bg-muted ring-4 ring-secondary">
          {me.photo ? <img src={me.photo} alt="" className="h-full w-full object-cover" /> : <div className="flex h-full items-center justify-center text-2xl font-bold">{me.name[0]}</div>}
        </div>
        <div className="min-w-0">
          <div className="truncate rounded-full bg-secondary px-3 py-1 text-sm font-bold tracking-widest text-secondary-foreground">{me.name}</div>
          <div className="mt-2 flex min-w-0 items-center gap-2 truncate text-xl font-bold font-display">
            <CoinImg src={LOGO.USDT} size={26} /> {fmt(me.usdt, 4)} <span className="text-sm font-medium text-muted-foreground">USDT</span>
          </div>
        </div>
      </div>

      <div>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
           <span className="font-semibold text-muted-foreground">{t("home.estimated")}</span>
          <span className="font-semibold">${(perDay / 24).toFixed(4)}<span className="text-muted-foreground">/hr</span></span>
          <span className="font-semibold">${perDay.toFixed(4)}<span className="text-muted-foreground">/day</span></span>
          <span className="font-semibold">${(perDay * 30).toFixed(2)}<span className="text-muted-foreground">/mo</span></span>
        </div>
        <div className="mt-1 max-w-full truncate font-display text-3xl font-extrabold tracking-tight sm:text-4xl">
          ${whole}<span className="text-muted-foreground/60">{frac}</span>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">{t("home.disclaimer")}</p>
      </div>

      <div className="grid h-12 grid-cols-[minmax(0,1fr)_1px_minmax(0,1fr)] items-center overflow-hidden rounded-2xl bg-muted">
        <button onClick={claim} aria-busy={busy} disabled={busy || live < data.settings.minClaim} className="inline-flex h-full min-w-0 items-center justify-center gap-2 px-3 text-sm font-bold text-primary disabled:opacity-50" title={live < data.settings.minClaim ? t("home.minClaim", { amount: data.settings.minClaim }) : undefined}>
          <TrendingUp className="h-4 w-4 shrink-0" /> <span className="truncate">{busy ? t("home.claiming") : t("home.claim")}</span>
        </button>
        <span className="h-6 bg-border" />
        <button onClick={() => setShowInfo((v) => !v)} className="inline-flex h-full min-w-0 items-center justify-center gap-2 px-3 text-sm font-semibold">
          <Info className="h-4 w-4 shrink-0 text-secondary" /> <span className="truncate">{t("home.how")}</span>
        </button>
      </div>
      {live < data.settings.minClaim && <p className="-mt-2 text-center text-xs text-muted-foreground">{t("home.minClaim", { amount: data.settings.minClaim })}</p>}
      {showInfo && (
        <div className={`${card} text-sm text-muted-foreground`}>
          <p>• {t("home.ruleDeposit", { rate: data.settings.coinRate })}</p>
          <p>• {t("home.ruleYield", { pct: data.settings.dailyYieldPct })}</p>
          <p>• {t("home.ruleInvite", { coins: data.settings.referralCoins })}</p>
          <p className="mt-2 flex gap-2 text-xs"><Shield className="h-4 w-4 shrink-0" /> {t("home.risk")}</p>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3">
        <div className="relative overflow-hidden rounded-3xl border border-gold/40 bg-card p-4">
          <p className="font-semibold">{t("home.coins")}</p>
          <CoinImg size={44} className="absolute right-3 top-3" />
          <p className="mt-3 truncate font-display text-xl font-bold">{fmt(me.coins, 0)}</p>
          <p className="mt-2 text-xs"><span className="rounded-full bg-success/15 px-2 py-0.5 font-semibold text-success">{data.settings.dailyYieldPct}%</span> <span className="text-muted-foreground">{t("home.perDay")}</span></p>
        </div>
        <div className="relative overflow-hidden rounded-3xl border border-border bg-card p-4">
          <p className="font-semibold">{t("home.usdtBalance")}</p>
          <CoinImg src={LOGO.USDT} size={44} className="absolute right-3 top-3" />
          <p className="mt-3 truncate font-display text-xl font-bold">${fmt(me.usdt, 4)}</p>
          <p className="mt-2 text-xs text-muted-foreground">{t("home.frozen", { amount: fmt(me.frozen, 2) })}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Link to="/deposit" className="inline-flex items-center justify-center gap-2 rounded-2xl bg-secondary py-4 font-bold text-secondary-foreground">
          <Upload className="h-5 w-5" /> {t("home.topUp")}
        </Link>
        <Link to="/withdraw" className="inline-flex items-center justify-center gap-2 rounded-2xl bg-primary py-4 font-bold text-primary-foreground">
          <Download className="h-5 w-5" /> {t("home.withdraw")}
        </Link>
      </div>

      <Link to="/friends" className={`${card} block`}>
        <p className="text-lg font-bold">{t("home.inviteTitle", { coins: data.settings.referralCoins })}</p>
        <p className="mt-2 flex items-center gap-2 text-sm text-muted-foreground"><Zap className="h-4 w-4 text-primary" /> {t("home.inviteBonus")}</p>
        <p className="mt-1 text-sm text-muted-foreground">{t("home.invited", { count: data.invited })}</p>
      </Link>

      {data.isAdmin && (
        <Link to="/admin" className="block rounded-2xl border border-dashed border-primary/50 py-3 text-center text-sm font-semibold text-primary">Open admin panel</Link>
      )}
    </div>
  );
}
