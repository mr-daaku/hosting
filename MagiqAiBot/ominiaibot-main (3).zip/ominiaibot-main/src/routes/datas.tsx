import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { exportTable, DATA_TABLES } from "@/lib/datas.functions";

export const Route = createFileRoute("/datas")({
  head: () => ({ meta: [
    { title: "Data export — OminiAi" },
    { name: "description", content: "Owner-only data export." },
    { property: "og:title", content: "Data export — OminiAi" },
    { property: "og:description", content: "Owner-only data export." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
    { name: "robots", content: "noindex" },
  ] }),
  component: Datas,
});

function toCsv(rows: Record<string, unknown>[]) {
  if (!rows.length) return "";
  const cols = Array.from(new Set(rows.flatMap((r) => Object.keys(r))));
  const esc = (v: unknown) => {
    if (v === null || v === undefined) return "";
    const s = typeof v === "object" ? JSON.stringify(v) : String(v);
    return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [cols.join(","), ...rows.map((r) => cols.map((c) => esc(r[c])).join(","))].join("\n");
}

function download(name: string, text: string) {
  const url = URL.createObjectURL(new Blob(["\uFEFF" + text], { type: "text/csv;charset=utf-8" }));
  const a = document.createElement("a");
  a.href = url; a.download = `${name}.csv`; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

function Datas() {
  const [key, setKey] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [log, setLog] = useState<string[]>([]);
  const run = async (tables: readonly string[]) => {
    for (const t of tables) {
      setBusy(t);
      try {
        const r = await exportTable({ data: { key, table: t as any } });
        download(t, toCsv(JSON.parse(r.json)));
        setLog((l) => [...l, `✅ ${t}: ${r.count} rows`]);
      } catch (e) {
        setLog((l) => [...l, `❌ ${t}: ${(e as Error).message}`]);
      }
    }
    setBusy(null);
  };
  return (
    <div className="mx-auto max-w-md p-5">
      <h1 className="text-2xl font-bold">Data export</h1>
      <p className="mt-1 text-sm text-muted-foreground">Password = your Telegram bot token.</p>
      <input type="password" value={key} onChange={(e) => setKey(e.target.value)} placeholder="Bot token" className="mt-4 w-full rounded-xl border border-border bg-muted p-3" />
      <button disabled={!!busy || !key} onClick={() => run(DATA_TABLES)} className="mt-3 w-full rounded-xl bg-primary py-3 font-bold text-primary-foreground disabled:opacity-60 disabled:cursor-wait">
        {busy ? `Downloading ${busy}…` : "Download all tables"}
      </button>
      <div className="mt-3 grid grid-cols-2 gap-2">
        {DATA_TABLES.map((t) => (
          <button key={t} disabled={!!busy || !key} onClick={() => run([t])} className="rounded-xl bg-secondary py-2 text-sm font-semibold text-secondary-foreground disabled:opacity-60">{t}</button>
        ))}
      </div>
      <div className="mt-4 space-y-1 text-sm">{log.map((l, i) => <p key={i}>{l}</p>)}</div>
    </div>
  );
}
