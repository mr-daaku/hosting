import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { toast } from "sonner";
import { ArrowLeft, Copy, RefreshCw, Wallet, ChevronRight, AlertTriangle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Shell, CoinImg, PageTitle, card } from "@/components/app/Shell";
import { CHAINS, chainById, walletLink, type ChainDef } from "@/lib/assets";
import { useMe, useTg, useRefreshMe, haptic, openLink, tgUserId } from "@/lib/tg";
import { checkDeposit, getDepositAddress } from "@/lib/app.functions";
import { livePrices } from "@/lib/prices";
import { useTranslation } from "react-i18next";

export const Route = createFileRoute("/deposit")({
  head: () => ({
    meta: [
      { title: "Top up — OminiAi" },
      { name: "description", content: "Deposit ETH, BNB, GRAM or stablecoins to your personal OminiAi address." },
      { property: "og:title", content: "Top up — OminiAi" },
      { property: "og:description", content: "Pick a network and coin, then send to your personal deposit address." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  validateSearch: (s: Record<string, unknown>): { chain?: string; asset?: string } => ({
    ...(typeof s["chain"] === "string" ? { chain: s["chain"] } : {}),
    ...(typeof s["asset"] === "string" ? { asset: s["asset"] } : {}),
  }),
  component: () => <Shell><Deposit /></Shell>,
});

function copy(text: string, what: string) {
  navigator.clipboard.writeText(text).then(() => { haptic("success"); toast.success(`${what} copied`); });
}

function Deposit() {
  const { chain, asset } = Route.useSearch();
  const c = chain ? chainById(chain) : undefined;
  const a = c?.assets.find((x) => x.symbol === asset);
  if (c && a) return <Address chain={c} asset={a.symbol} />;
  if (c) return <PickAsset chain={c} />;
  return <PickChain />;
}

function PickChain() {
  const { t } = useTranslation();
  return (
    <div>
      <PageTitle right={<Link to="/" className="inline-flex items-center gap-1 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" />{t("common.back")}</Link>}>{t("deposit.selectNetwork")}</PageTitle>
      <div className="space-y-2">
        {CHAINS.map((c) => (
          <Link key={c.id} to="/deposit" search={{ chain: c.id }} className={`${card} flex items-center gap-3`}>
            <CoinImg src={c.logo} size={36} />
            <div className="flex-1"><p className="font-semibold">{c.name}</p><p className="text-xs text-muted-foreground">{c.network}</p></div>
            <ChevronRight className="h-5 w-5 text-muted-foreground" />
          </Link>
        ))}
      </div>
    </div>
  );
}

function PickAsset({ chain }: { chain: ChainDef }) {
  const { t } = useTranslation();
  return (
    <div>
      <PageTitle right={<Link to="/deposit" search={{}} className="inline-flex items-center gap-1 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" />{t("common.back")}</Link>}>{chain.name}</PageTitle>
      <p className="mb-3 text-sm text-muted-foreground">{t("deposit.chooseCoin")}</p>
      <div className="grid grid-cols-2 gap-2">
        {chain.assets.map((a) => (
          <Link key={a.symbol} to="/deposit" search={{ chain: chain.id, asset: a.symbol }} className={`${card} flex items-center gap-3`}>
            <span className="relative"><CoinImg src={a.logo} size={36} /><CoinImg src={chain.logo} size={16} className="absolute -bottom-1 -right-1 ring-2 ring-card" /></span>
            <div><p className="font-semibold">{a.label}</p><p className="text-xs text-muted-foreground">{a.stable ? t("deposit.stablecoin") : t("deposit.native")}</p></div>
          </Link>
        ))}
      </div>
    </div>
  );
}

function Address({ chain, asset }: { chain: ChainDef; asset: string }) {
  const { t, i18n } = useTranslation();
  const { data } = useMe();
  const { initData, status } = useTg();
  const refresh = useRefreshMe();
  const [checking, setChecking] = useState(false);
  const px = useQuery({ queryKey: ["prices"], queryFn: livePrices, refetchInterval: 60000, retry: 2, staleTime: 45000 });
  // EVM: generated from the wallet index when the method is picked. GRAM: fixed address + Telegram ID memo.
  const addrChain = chain.wallet === "ton" ? "ton" : chain.id === "eth" ? "eth" : "bsc";
  const dep = useQuery({
    queryKey: ["deposit-address", chain.wallet === "evm" ? "evm" : "ton"],
    queryFn: () => getDepositAddress({ data: { initData, chain: addrChain } }),
    enabled: status === "ready", staleTime: Infinity, gcTime: Infinity,
  });
  if (!data) return null;
  const address = dep.data?.address ?? null;
  const uid = tgUserId() ?? data.me.id;
  const memo = chain.wallet === "ton" && dep.data ? `${dep.data.memoPrefix}${uid}` : null;
  const a = chain.assets.find((x) => x.symbol === asset)!;
  const priceData = px.data;
  const liveRate = priceData?.values[a.symbol];

  const check = async () => {
    setChecking(true);
    try {
      const r = await checkDeposit({ data: { initData } });
      for (const b of r.belowMinimum) toast.warning(t("deposit.belowMin", { amount: b.amount, asset: b.asset, usd: b.usd, minimum: r.minDeposit }));
      if (r.credited.length) {
        haptic("success");
        for (const c of r.credited) toast.success(t("deposit.received", c));
        refresh();
      } else if (!r.belowMinimum.length) toast(t("deposit.noDeposit"));
    } catch (e) { toast.error((e as Error).message); } finally { setChecking(false); }
  };

  return (
    <div>
      <PageTitle right={<Link to="/deposit" search={{ chain: chain.id }} className="inline-flex items-center gap-1 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" />{t("common.back")}</Link>}>
        <span className="inline-flex items-center gap-2"><CoinImg src={a.logo} size={28} /> {t("deposit.title", { coin: a.label })}</span>
      </PageTitle>

      {!address ? (dep.isError
        ? <button onClick={() => dep.refetch()} className="inline-flex items-center gap-2 text-sm font-semibold text-primary"><RefreshCw className="h-4 w-4" />{t("common.retry", { defaultValue: "Try again" })}</button>
        : <div className="space-y-3"><div className="mx-auto h-[232px] w-[232px] animate-pulse rounded-3xl bg-muted" /><div className="h-16 animate-pulse rounded-2xl bg-muted" /></div>) : (
        <div className="space-y-3">
          <div className="mx-auto w-fit rounded-3xl bg-foreground p-4">
            <QRCodeSVG value={address} size={200} />
          </div>
          <div className={card}>
             <p className="text-xs text-muted-foreground">{t("deposit.address", { chain: chain.name, network: chain.network })}</p>
            <div className="mt-1 flex items-center gap-2">
              <p className="flex-1 break-all font-mono text-sm">{address}</p>
               <button onClick={() => copy(address, t("deposit.copyAddress"))} className="rounded-xl bg-muted p-2" aria-label={t("deposit.copyAddress")}><Copy className="h-4 w-4" /></button>
            </div>
          </div>
          {memo && (
            <div className={`${card} border-primary/60`}>
               <p className="text-xs font-semibold text-primary">{t("deposit.memo")}</p>
              <div className="mt-1 flex items-center gap-2">
                <p className="flex-1 font-mono text-lg font-bold">{memo}</p>
                 <button onClick={() => copy(memo, t("deposit.copyMemo"))} className="rounded-xl bg-muted p-2" aria-label={t("deposit.copyMemo")}><Copy className="h-4 w-4" /></button>
              </div>
               <p className="mt-2 text-xs text-muted-foreground">{t("deposit.memoWarning")}</p>
            </div>
          )}
          {!a.stable && (
            <div className={`${card} text-center`}>
               <p className="text-xs text-muted-foreground">{t("deposit.live")}</p>
               {px.isLoading ? <div className="mx-auto mt-2 h-5 w-3/4 animate-pulse rounded bg-muted" /> : liveRate && priceData ? <>
                 <p className="mt-1 break-words font-display text-base font-bold">1 {a.symbol} = {liveRate.toLocaleString(i18n.language, { maximumFractionDigits: 4 })} USDT = {Math.round(liveRate * data.settings.coinRate).toLocaleString(i18n.language)} coins</p>
                 <p className="mt-1 text-xs font-semibold text-gold">{t("deposit.minNative", { amount: (data.settings.minDepositUsd / liveRate).toLocaleString(i18n.language, { maximumSignificantDigits: 4 }), coin: a.symbol, usd: data.settings.minDepositUsd })}</p>
                 <p className="mt-1 text-xs text-muted-foreground">{t("deposit.updated", { time: new Date(priceData.updatedAt).toLocaleTimeString(i18n.language, { hour: "2-digit", minute: "2-digit" }) })}{priceData.stale ? ` · ${t("deposit.unavailable")}` : ""}</p>
               </> : <button onClick={() => px.refetch()} className="mt-2 inline-flex items-center gap-2 text-sm font-semibold text-primary"><RefreshCw className="h-4 w-4" />{t("deposit.retryRate")}</button>}
            </div>
          )}
          <div className="flex gap-2 rounded-2xl bg-muted p-3 text-xs text-muted-foreground">
            <AlertTriangle className="h-4 w-4 shrink-0 text-gold" />
             {t("deposit.sendOnly", { coin: a.label, chain: chain.name, official: a.stable ? t("deposit.official") : "", minimum: data.settings.minDepositUsd, rate: data.settings.coinRate })}
          </div>
          <button onClick={check} disabled={checking} aria-busy={checking} className="flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-4 font-bold text-primary-foreground disabled:opacity-60">
             <RefreshCw className={`h-5 w-5 ${checking ? "animate-spin" : ""}`} /> {checking ? t("deposit.checking") : t("deposit.check")}
          </button>
          <button onClick={() => openLink(walletLink(chain, address, memo))} className="flex w-full items-center justify-center gap-2 rounded-2xl bg-secondary py-4 font-bold text-secondary-foreground">
             <Wallet className="h-5 w-5" /> {t("deposit.wallet")}
          </button>
        </div>
      )}
    </div>
  );
}
