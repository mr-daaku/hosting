import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState, type ReactNode } from "react";
import { ChevronDown, ChevronRight, Globe, History, HelpCircle, Moon, Sun, Scale, UserPlus, Users, Wallet } from "lucide-react";
import { Shell, CoinImg, card } from "@/components/app/Shell";
import { useMe, useTg, useTheme } from "@/lib/tg";
import { getHistory } from "@/lib/app.functions";
import { LOGO, fmt } from "@/lib/assets";
import { useTranslation } from "react-i18next";
import { LANGUAGES, applyLanguage } from "@/lib/i18n";

export const Route = createFileRoute("/account")({
  head: () => ({
    meta: [
      { title: "My account — OminiAi" },
      { name: "description", content: "Your OminiAi profile, balances, referral earnings, settings and history." },
      { property: "og:title", content: "My account — OminiAi" },
      { property: "og:description", content: "Profile, balances, referral earnings and history." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => <Shell><Account /></Shell>,
});

const STATUS: Record<string, string> = { pending: "text-gold", paid: "text-success", rejected: "text-destructive" };
const LEVELS = [0, 1000, 5000, 20000, 50000];

const FAQ: [string, string][] = [
  ["How do I get coins?", "Deposit crypto from the Top up page. Every $1 deposited gives you coins at the current rate, credited after the transfer is confirmed."],
  ["How is profit calculated?", "Your coin balance generates an estimated small daily USDT amount. It is an estimate, not guaranteed, and the rate can change."],
  ["Which networks can I withdraw to?", "USDT on BNB Chain (BEP20) or USDT on GRAM. Payouts are always in USDT."],
  ["Can I withdraw without depositing?", "Yes, up to a small free limit in total. After that, a deposit is required."],
  ["Why was my deposit not credited?", "Make sure you sent the exact coin on the right network, above the minimum, and with the memo on GRAM. Fake USDT/USDC tokens are rejected."],
];

function Stat({ label, value, icon }: { label: string; value: ReactNode; icon?: ReactNode }) {
  return (
    <div className={`${card} min-w-0`}>
      <p className="flex items-center gap-1 text-xs text-muted-foreground">{icon}{label}</p>
      <p className="mt-1 truncate font-display text-lg font-bold">{value}</p>
    </div>
  );
}

function Row({ icon, label, right, onClick, to }: { icon: ReactNode; label: string; right?: ReactNode; onClick?: () => void; to?: "/legal" }) {
  const inner = (<><span className="text-secondary">{icon}</span><span className="flex-1 font-semibold">{label}</span>{right ?? <ChevronRight className="h-4 w-4 text-muted-foreground" />}</>);
  const cls = "flex w-full items-center gap-3 px-4 py-3 text-left text-sm";
  return to ? <Link to={to} className={cls}>{inner}</Link> : <button onClick={onClick} className={cls}>{inner}</button>;
}

function Account() {
  const { t, i18n } = useTranslation();
  const { data } = useMe();
  const { initData, status } = useTg();
  const [theme, setTheme] = useTheme();
  const [open, setOpen] = useState<"history" | "faq" | null>(null);
  const [faq, setFaq] = useState<number | null>(null);
  const [showLanguages, setShowLanguages] = useState(false);
  const hist = useQuery({ queryKey: ["history"], queryFn: () => getHistory({ data: { initData } }), enabled: status === "ready" && open === "history" });
  if (!data) return null;
  const me = data.me;
  const rate = data.settings.coinRate || 100;
  const level = LEVELS.filter((l) => me.coins >= l).length;
  const total = me.usdt + me.frozen;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <div className="h-16 w-16 shrink-0 overflow-hidden rounded-full bg-muted ring-4 ring-secondary">
          {me.photo ? <img src={me.photo} alt="" className="h-full w-full object-cover" /> : <div className="flex h-full items-center justify-center text-xl font-bold">{me.name[0]}</div>}
        </div>
        <div className="min-w-0">
          <p className="truncate text-lg font-bold">{me.name}</p>
          <p className="truncate text-xs text-muted-foreground">@{me.username} · ID {me.id}</p>
           <span className="mt-1 inline-block rounded-full bg-primary/15 px-2 py-0.5 text-xs font-bold text-primary">{t("account.level", { level })}</span>
        </div>
      </div>

      <div className={`${card} border-secondary/40`}>
         <p className="text-xs text-muted-foreground">{t("account.total")}</p>
        <p className="mt-1 flex items-center gap-2 truncate font-display text-2xl font-extrabold"><CoinImg src={LOGO.USDT} size={24} /> {fmt(total, 4)} <span className="text-sm font-medium text-muted-foreground">USDT</span></p>
      </div>

      <div className="grid grid-cols-2 gap-3">
         <Stat label={t("account.invitedBy")} icon={<UserPlus className="h-3 w-3" />} value={me.referredBy ?? "—"} />
         <Stat label={t("account.coinBalance")} icon={<CoinImg size={12} />} value={fmt(me.coins, 0)} />
         <Stat label={t("account.usdtBalance")} icon={<CoinImg src={LOGO.USDT} size={12} />} value={fmt(me.usdt, 4)} />
         <Stat label={t("account.referralIncome")} icon={<Users className="h-3 w-3" />} value={`$${fmt(me.referralEarnings / rate, 4)}`} />
         <Stat label={t("account.referralCoins")} icon={<CoinImg size={12} />} value={fmt(me.referralEarnings, 0)} />
         <Stat label={t("account.withdrawn")} icon={<Wallet className="h-3 w-3" />} value={fmt(me.totalWithdrawal, 4)} />
      </div>

      <div className={`${card} divide-y divide-border p-0`}>
         <Row icon={<Globe className="h-4 w-4" />} label={t("account.language")} onClick={() => setShowLanguages((v) => !v)} right={<span className="text-sm text-muted-foreground">{LANGUAGES.find((l) => l.code === i18n.language)?.label ?? "English"}</span>} />
         {showLanguages && <div className="grid grid-cols-2 gap-2 p-3">{LANGUAGES.map((language) => <button key={language.code} onClick={() => { localStorage.setItem("omini-language", language.code); applyLanguage(language.code); setShowLanguages(false); }} className={`rounded-xl px-3 py-2 text-sm font-semibold ${i18n.language === language.code ? "bg-primary text-primary-foreground" : "bg-muted"}`}>{language.label}</button>)}</div>}
         <Row icon={theme === "dark" ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />} label={t("account.theme")} onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
           right={<span className="rounded-full bg-muted px-3 py-1 text-xs font-semibold">{theme === "dark" ? t("account.dark") : t("account.light")}</span>} />
         <Row icon={<History className="h-4 w-4" />} label={t("account.history")} onClick={() => setOpen(open === "history" ? null : "history")}
          right={<ChevronDown className={`h-4 w-4 text-muted-foreground transition ${open === "history" ? "rotate-180" : ""}`} />} />
        {open === "history" && (
          <div className="space-y-2 p-3">
            <p className="text-xs font-semibold text-muted-foreground">{t("account.withdrawals")}</p>
            {hist.isLoading && <p className="text-xs text-muted-foreground">Loading…</p>}
            {(hist.data?.withdrawals ?? []).map((w) => (
              <div key={w.id} className="rounded-2xl bg-muted px-3 py-2 text-xs">
                <div className="flex justify-between"><p className="font-semibold">{Number(w.amount)} USDT · {w.chain === "ton" ? "GRAM" : "BEP20"}</p><span className={`font-semibold capitalize ${STATUS[w.status]}`}>{w.status}</span></div>
                <p className="truncate font-mono text-muted-foreground">{w.address}</p>
                {w.reject_reason && <p className="text-destructive">{w.reject_reason}</p>}
                {w.tx_hash && <p className="truncate font-mono text-success">Tx {w.tx_hash}</p>}
              </div>
            ))}
            {hist.data && !hist.data.withdrawals.length && <p className="text-xs text-muted-foreground">{t("account.nothing")}</p>}
          </div>
        )}
         <Row icon={<HelpCircle className="h-4 w-4" />} label={t("account.faq")} onClick={() => setOpen(open === "faq" ? null : "faq")}
          right={<ChevronDown className={`h-4 w-4 text-muted-foreground transition ${open === "faq" ? "rotate-180" : ""}`} />} />
        {open === "faq" && (
          <div className="space-y-2 p-3">
            {FAQ.map(([q, a], i) => (
              <button key={q} onClick={() => setFaq(faq === i ? null : i)} className="block w-full rounded-2xl bg-muted px-3 py-2 text-left">
                <p className="text-sm font-semibold">{q}</p>
                {faq === i && <p className="mt-1 text-xs text-muted-foreground">{a}</p>}
              </button>
            ))}
          </div>
        )}
         <Row icon={<Scale className="h-4 w-4" />} label={t("account.legal")} to="/legal" />
      </div>
    </div>
  );
}
