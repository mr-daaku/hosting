import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell, CoinImg, PageTitle, card } from "@/components/app/Shell";
import { useTheme } from "@/lib/tg";
import { useTranslation } from "react-i18next";

export const Route = createFileRoute("/trade")({
  head: () => ({
    meta: [
      { title: "BTC market — OminiAi" },
      { name: "description", content: "Live BTC/USDT price and chart from real public market data." },
      { property: "og:title", content: "BTC market — OminiAi" },
      { property: "og:description", content: "Live BTC/USDT chart and 24h market stats." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => <Shell><Trade /></Shell>,
});

const BTC_LOGO = "https://assets.coingecko.com/coins/images/1/large/bitcoin.png";
const INTERVALS = [["15", "15m"], ["60", "1h"], ["240", "4h"], ["D", "1D"]] as const;

type Ticker = { lastPrice: string; priceChangePercent: string; highPrice: string; lowPrice: string; quoteVolume: string };

function Trade() {
  const { t } = useTranslation();
  const [theme] = useTheme();
  const [ticker, setTicker] = useState<Ticker | null>(null);
  const [iv, setIv] = useState<string>("60");

  useEffect(() => {
    let alive = true;
    const load = () =>
      fetch("https://api.binance.com/api/v3/ticker/24hr?symbol=BTCUSDT")
        .then((r) => (r.ok ? r.json() : null))
        .then((j) => { if (alive && j) setTicker(j as Ticker); })
        .catch(() => {});
    load();
    const id = setInterval(load, 10000);
    return () => { alive = false; clearInterval(id); };
  }, []);

  const chg = Number(ticker?.priceChangePercent ?? 0);
  const usd = (v?: string, d = 2) => (v ? Number(v).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d }) : "—");
  const src = `https://s.tradingview.com/widgetembed/?symbol=BINANCE%3ABTCUSDT&interval=${iv}&hidesidetoolbar=1&symboledit=0&saveimage=0&toolbarbg=1a2140&theme=${theme}&style=1&timezone=Etc%2FUTC&locale=en`;

  return (
    <div className="space-y-4">
      <PageTitle>{t("trade.title")}</PageTitle>
      <div className={`${card} flex items-center gap-3`}>
        <CoinImg src={BTC_LOGO} size={40} />
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-muted-foreground">BTC / USDT</p>
           <p className="truncate font-display text-2xl font-bold">${usd(ticker?.lastPrice)}</p>
        </div>
        <span className={`rounded-full px-2 py-1 text-xs font-bold ${chg >= 0 ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"}`}>
          {chg >= 0 ? "+" : ""}{chg.toFixed(2)}%
        </span>
      </div>

      <div className="flex gap-2 rounded-full bg-muted p-1">
        {INTERVALS.map(([v, label]) => (
          <button key={v} onClick={() => setIv(v)} className={`flex-1 rounded-full py-1.5 text-sm font-semibold ${iv === v ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>{label}</button>
        ))}
      </div>

      <div className="overflow-hidden rounded-3xl border border-border bg-card">
        <iframe key={`${iv}-${theme}`} title="BTC/USDT chart" src={src} className="h-[420px] w-full" loading="lazy" />
      </div>

      <div className="grid grid-cols-3 gap-2 text-center">
         <div className={card}><p className="text-xs text-muted-foreground">{t("trade.high")}</p><p className="truncate text-sm font-bold">${usd(ticker?.highPrice, 0)}</p></div>
         <div className={card}><p className="text-xs text-muted-foreground">{t("trade.low")}</p><p className="truncate text-sm font-bold">${usd(ticker?.lowPrice, 0)}</p></div>
         <div className={card}><p className="text-xs text-muted-foreground">{t("trade.volume")}</p><p className="truncate text-sm font-bold">${ticker ? (Number(ticker.quoteVolume) / 1e9).toFixed(2) + "B" : "—"}</p></div>
      </div>
      <p className="text-center text-xs text-muted-foreground">{t("trade.note")}</p>
    </div>
  );
}
