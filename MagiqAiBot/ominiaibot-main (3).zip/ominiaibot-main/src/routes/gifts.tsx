import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Shell, CoinImg, PageTitle, card } from "@/components/app/Shell";
import { useMe, useTg, useRefreshMe, haptic } from "@/lib/tg";
import { openGift } from "@/lib/app.functions";
import { LOGO } from "@/lib/assets";
import { useTranslation } from "react-i18next";

export const Route = createFileRoute("/gifts")({
  head: () => ({
    meta: [
      { title: "Gift — OminiAi" },
      { name: "description", content: "Open your one-time welcome gift box for free coins." },
      { property: "og:title", content: "Gift — OminiAi" },
      { property: "og:description", content: "Open your one-time gift box on OminiAi." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => <Shell><Gifts /></Shell>,
});

function Gifts() {
  const { t } = useTranslation();
  const { data } = useMe();
  const { initData } = useTg();
  const refresh = useRefreshMe();
  const [busy, setBusy] = useState(false);
  const [won, setWon] = useState<number | null>(null);
  if (!data) return null;
  const used = !!data.me.lastGiftAt;
  const boxes = data.me.giftBoxes ?? 0;
  const canOpen = !used || boxes > 0;

  const open = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const r = await openGift({ data: { initData } });
      haptic("success");
      setWon(r.coins);
      refresh();
    } catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
  };

  return (
    <div>
      <PageTitle>{t("gifts.title")}</PageTitle>
      <div className={`${card} flex flex-col items-center py-10 text-center`}>
        <img src={LOGO.GIFT} alt="Gift box" width={140} height={140} className={`${busy ? "animate-bounce" : ""} ${used && won === null ? "opacity-50 grayscale" : ""}`} />
        {won !== null ? (
          <>
             <p className="mt-4 text-sm text-muted-foreground">{t("gifts.won")}</p>
            <p className="flex items-center gap-2 font-display text-4xl font-extrabold text-primary"><CoinImg size={36} /> +{won}</p>
          </>
        ) : (
           <p className="mt-4 text-lg font-bold">{canOpen ? t("gifts.waiting") : t("gifts.usedTitle")}</p>
        )}
        {used && boxes > 0 && won === null && (
          <p className="mt-2 text-sm font-semibold text-primary">{t("gifts.boxesLeft", { count: boxes })}</p>
        )}
        <button onClick={open} aria-busy={busy} disabled={busy || !canOpen} className="mt-6 w-full rounded-2xl bg-primary py-4 font-bold text-primary-foreground disabled:bg-muted disabled:text-muted-foreground">
           {!canOpen ? t("gifts.used") : busy ? t("gifts.opening") : t("gifts.open")}
        </button>
         <p className="mt-3 text-xs text-muted-foreground">{t("gifts.one")}</p>
      </div>
    </div>
  );
}
