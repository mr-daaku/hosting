import { createFileRoute } from "@tanstack/react-router";

// Public health check: server + database, each reported separately. No user data.
// Cached 10s at the edge so repeated checks never pile onto the database.
export const Route = createFileRoute("/api/public/health")({
  server: {
    handlers: {
      GET: async () => {
        const t0 = Date.now();
        let db: { ok: boolean; ms: number; error?: string };
        try {
          const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
          const { error } = await supabaseAdmin.from("app_settings").select("key", { head: true, count: "exact" }).limit(1);
          db = error ? { ok: false, ms: Date.now() - t0, error: error.message } : { ok: true, ms: Date.now() - t0 };
        } catch (e) {
          db = { ok: false, ms: Date.now() - t0, error: (e as Error).message };
        }
        return Response.json(
          { server: { ok: true }, database: db, at: new Date().toISOString() },
          { status: db.ok ? 200 : 503, headers: { "cache-control": "public, max-age=10" } },
        );
      },
    },
  },
});
