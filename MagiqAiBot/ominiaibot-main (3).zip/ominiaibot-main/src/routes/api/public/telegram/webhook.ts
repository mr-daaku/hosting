import { createFileRoute } from "@tanstack/react-router";
import { timingSafeEqual } from "crypto";

export const Route = createFileRoute("/api/public/telegram/webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { webhookSecret, tgApi, appLink } = await import("@/lib/telegram.server");
        const got = Buffer.from(request.headers.get("X-Telegram-Bot-Api-Secret-Token") ?? "");
        const exp = Buffer.from(webhookSecret());
        if (got.length !== exp.length || !timingSafeEqual(got, exp)) return new Response("Unauthorized", { status: 401 });

        const update = (await request.json()) as any;
        if (update?.callback_query) { await handleCallback(update.callback_query); return Response.json({ ok: true }); }
        const msg = update?.message;
        const text: string = msg?.text ?? "";
        if (!msg?.chat?.id) return Response.json({ ok: true });
        if (!text.startsWith("/start")) return Response.json({ ok: true });

        const payload = text.split(/\s+/)[1];
        const ref = payload && /^\d+$/.test(payload) && Number(payload) !== msg.from?.id ? payload : String(msg.from?.id ?? "");
        const origin = new URL(request.url).origin;
        try {
          await tgApi("sendPhoto", {
            chat_id: msg.chat.id,
            photo: `${origin}/welcome.jpg`,
            caption: `<b>Welcome to OminiAi, ${escapeHtml(msg.from?.first_name ?? "friend")}!</b>\n\nYour personal crypto wallet with coins, daily rewards and friend bonuses.\n\nTap <b>Open App</b> to get started.`,
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "🚀 Open App", url: appLink(ref) }]] },
          });
        } catch (e) {
          console.error(e);
        }
        return Response.json({ ok: true });
      },
    },
  },
});

function escapeHtml(s: string) {
  return s.replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[c]!);
}

async function handleCallback(cb: any): Promise<void> {
  const { tgApi } = await import("@/lib/telegram.server");
  const { isAdmin } = await import("@/lib/core.server");
  const ack = (text: string, alert = false) => tgApi("answerCallbackQuery", { callback_query_id: cb.id, text, show_alert: alert }).catch(() => {});
  const m = /^wd:(pay|auto|rej|rejr):([0-9a-f-]{36})$/.exec(String(cb.data ?? ""));
  if (!m) { await ack("Unknown action"); return; }
  if (!cb.from?.id || !(await isAdmin(Number(cb.from.id)))) { await ack("Only admins can do this", true); return; }
  const [, act, id] = m;
  const paying = act === "pay" || act === "auto";
  const msgRef = cb.message ? { chat_id: cb.message.chat.id, message_id: cb.message.message_id } : null;
  const base = cb.message?.text ? escapeHtml(String(cb.message.text)) : "Withdrawal";
  const edit = (status: string, keepButtons = false) => msgRef && tgApi("editMessageText", { ...msgRef, text: `${base}\n\n${status}`, parse_mode: "HTML", ...(keepButtons ? { reply_markup: cb.message.reply_markup } : {}) }).catch(() => {});
  await ack(act === "auto" ? "Sending payment…" : paying ? "Marking paid…" : "Rejecting…");
  await edit(act === "auto" ? "⏳ Sending USDT…" : "⏳ Processing…");
  try {
    const { reviewWithdrawal } = await import("@/lib/payout.server");
    const r = await reviewWithdrawal({ id: id!, action: paying ? "pay" : "reject", adminId: Number(cb.from.id), auto: act === "auto", refund: act === "rejr", reason: paying ? undefined : "Rejected by admin" });
    const link = r.txHash ? (r.chain === "ton" ? `https://tonscan.org/tx/${encodeURIComponent(r.txHash)}` : `https://bscscan.com/tx/${r.txHash}`) : "";
    if (paying) await edit(`✅ <b>PAID${act === "auto" ? " (auto)" : ""}</b>${link ? `\n🧾 <a href="${link}">${escapeHtml(r.txHash!)}</a>` : ""}`);
    else await edit(act === "rejr" ? "❌ <b>REJECTED</b> (refunded)" : "❌ <b>REJECTED</b> (no refund)");
  } catch (e) {
    const msg = escapeHtml((e as Error).message);
    await edit(msg === "Already reviewed" ? "ℹ️ Already reviewed" : `⚠️ Failed: ${msg}\nTry again with the buttons.`, msg !== "Already reviewed");
  }
}
