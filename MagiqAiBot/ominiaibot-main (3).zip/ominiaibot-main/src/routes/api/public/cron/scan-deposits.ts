import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/cron/scan-deposits")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data } = await supabaseAdmin.from("app_settings").select("value").eq("key", "cron_key").maybeSingle();
        const key = request.headers.get("x-cron-key");
        if (!data || !key || JSON.stringify(key) !== JSON.stringify(data.value)) return new Response("Unauthorized", { status: 401 });
        const { scanActiveUsers } = await import("@/lib/deposits.server");
        return Response.json(await scanActiveUsers());
      },
    },
  },
});
