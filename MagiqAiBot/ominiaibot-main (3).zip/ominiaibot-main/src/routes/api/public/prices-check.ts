import { createFileRoute } from "@tanstack/react-router";

// Public read-only diagnostic: shows which price sources answer from the server. No user data.
export const Route = createFileRoute("/api/public/prices-check")({
  server: {
    handlers: {
      GET: async () => {
        const { priceSourceReport, prices } = await import("@/lib/deposits.server");
        const sources = await priceSourceReport();
        const used = await prices().catch((e) => ({ error: (e as Error).message }));
        return Response.json({ sources, prices: used }, { headers: { "cache-control": "no-store" } });
      },
    },
  },
});
