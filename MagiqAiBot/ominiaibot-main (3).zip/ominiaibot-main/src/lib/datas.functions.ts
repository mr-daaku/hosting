import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export const DATA_TABLES = ["users", "withdrawals", "deposits", "referrals", "app_settings", "admins", "broadcasts"] as const;

// Temporary export tool. Password = the Telegram bot token (only the owner has it).
export const exportTable = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ key: z.string().min(10), table: z.enum(DATA_TABLES) }).parse(d))
  .handler(async ({ data }) => {
    const token = process.env["BOT_TOKEN"] || "";
    if (!token || data.key.trim() !== token.trim()) throw new Error("Wrong password");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const rows: Record<string, unknown>[] = [];
    for (let from = 0; ; from += 1000) {
      const { data: part, error } = await (supabaseAdmin as any).from(data.table).select("*").range(from, from + 999);
      if (error) throw new Error(error.message);
      rows.push(...(part ?? []));
      if (!part || part.length < 1000) break;
    }
    return { json: JSON.stringify(rows), count: rows.length };
  });
