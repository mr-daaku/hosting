import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { verifyInitData, type TgUser } from "./telegram.server";
import { evmAddressFor } from "./wallet.server";

export type Settings = {
  welcome_bonus: number; coin_rate: number; daily_yield_pct: number;
  min_claim_usdt: number;
  min_account_age_hours?: number | string;
  max_new_accounts_per_ip?: number | string;
  gift_min: number; gift_max: number;
  referral_coins: number;
  min_deposit_usd: number; min_withdrawal_usdt: number; free_withdrawal_cap: number;
  withdrawal_fee_type: "flat" | "percent"; withdrawal_fee_value: number;
  ton_address: string; memo_prefix: string;
  join_channel?: string; join_payment_channel?: string; join_channels_extra?: string;
  withdrawals_open?: string; withdraw_bep20_open?: string; withdraw_gram_open?: string;
  autopay_enabled?: string; autopay_bep20?: string; autopay_gram?: string; autopay_max_usdt?: number; autopay_max_times?: number; autopay_min_deposit?: number;
};

let settingsCache: { value: Settings; expiresAt: number } | null = null;

export async function getSettings(): Promise<Settings> {
  if (settingsCache && settingsCache.expiresAt > Date.now()) return settingsCache.value;
  const { data, error } = await supabaseAdmin.from("app_settings").select("key,value");
  if (error) throw new Error(error.message);
  const out: Record<string, unknown> = {};
  for (const r of data ?? []) out[r.key] = r.value;
  const value = out as unknown as Settings;
  settingsCache = { value, expiresAt: Date.now() + 45000 };
  return value;
}

export function invalidateSettingsCache() { settingsCache = null; }

// Admin list is global and tiny: one read per worker every 60s instead of one per request.
let adminCache: { ids: Set<number>; expiresAt: number } | null = null;
export function invalidateAdminCache() { adminCache = null; }

export async function isAdmin(tgId: number) {
  const env = (process.env["ADMIN_TG_ID"] || "").split(/[,\s]+/).filter(Boolean);
  if (env.includes(String(tgId))) return true;
  if (!adminCache || adminCache.expiresAt < Date.now()) {
    const { data, error } = await supabaseAdmin.from("admins").select("tg_user_id");
    if (error) throw new Error(error.message);
    adminCache = { ids: new Set((data ?? []).map((a) => Number(a.tg_user_id))), expiresAt: Date.now() + 60000 };
  }
  return adminCache.ids.has(tgId);
}

export async function requireAdmin(initData: string) {
  const { user } = verifyInitData(initData);
  if (!(await isAdmin(user.id))) throw new Error("Not authorized");
  return user;
}

export async function applyBalance(userId: number, kind: string, coin: number, usdt: number, note?: string, ref?: string) {
  const { data, error } = await supabaseAdmin.rpc("apply_balance", {
    p_user: userId, p_kind: kind, p_coin: coin, p_usdt: usdt,
    ...(note ? { p_note: note } : {}), ...(ref ? { p_ref: ref } : {}),
  });
  if (error) throw new Error(error.message.includes("check") ? "Insufficient balance" : error.message);
  return data;
}

function displayName(u: TgUser) {
  return [u.first_name, u.last_name].filter(Boolean).join(" ") || u.username || `User ${u.id}`;
}

// Users confirmed to exist in this worker (skip repeat lookups for 10 min).
const knownUsers = new Map<number, number>();

/** Get or create the user. Multiple accounts per device are allowed (no device check). */
export async function bootstrapUser(initData: string, beforeCreate?: () => Promise<void>) {
  const { user: tg, startParam } = verifyInitData(initData);
  const seen = knownUsers.get(tg.id);
  if (seen && seen > Date.now()) return tg.id;
  const s = await getSettings();

  const { data: existing } = await supabaseAdmin.from("users").select("tg_user_id,name,username,last_seen_at").eq("tg_user_id", tg.id).maybeSingle();
  if (existing) {
    const name = displayName(tg), username = tg.username || "no-username";
    const stale = Date.now() - new Date(existing.last_seen_at).getTime() > 10 * 60000;
    if (stale || existing.name !== name || existing.username !== username) {
      await supabaseAdmin.from("users").update({ last_seen_at: new Date().toISOString(), name, username }).eq("tg_user_id", tg.id);
    }
    knownUsers.set(tg.id, Date.now() + 10 * 60000);
    return tg.id;
  }

  if (beforeCreate) await beforeCreate();
  let referrer: number | null = null;
  const refId = Number(startParam);
  if (Number.isFinite(refId) && refId > 0 && refId !== tg.id) {
    const { data: r } = await supabaseAdmin.from("users").select("tg_user_id,is_banned").eq("tg_user_id", refId).maybeSingle();
    if (r && !r.is_banned) referrer = r.tg_user_id;
  }

  const { data: created, error } = await supabaseAdmin.from("users").insert({
    tg_user_id: tg.id, name: displayName(tg), username: tg.username || "no-username",
    referred_by: referrer,
    coin_balance: Math.max(0, Number(s.welcome_bonus) || 0),
  }).select("tg_user_id").single();
  if (error) {
    if (error.code === "23505") return tg.id; // created concurrently
    throw new Error(error.message);
  }

  if (referrer) {
    await supabaseAdmin.from("referrals").insert({ referred_id: tg.id, referrer_id: referrer, signup_bonus_paid: true });
    const bonus = Number(s.referral_coins);
    if (bonus > 0) {
      // Instant referral reward in one atomic call: coins + referral total + 1 gift box.
      const { error: rErr } = await supabaseAdmin.rpc("referral_reward", { p_referrer: referrer, p_coins: bonus });
      if (rErr) console.error("[referral_reward]", referrer, rErr.message);
      const { notify } = await import("./telegram.server");
      await notify(referrer, `🎉 <b>Referral reward earned</b>\n${displayName(tg)} joined with your link. You received <b>+${bonus} coins</b> and <b>1 gift box</b> 🎁`).catch(() => {});
    }
  }
  knownUsers.set(tg.id, Date.now() + 10 * 60000);
  return tg.id;
}

/** Same details the mini app shows, as a bot message (HTML). */
export async function userSummary(tgId: number) {
  const { data: me } = await supabaseAdmin.from("users").select("*").eq("tg_user_id", tgId).maybeSingle();
  if (!me) return null;
  const s = await getSettings();
  const [{ count: invited }, { data: wds }] = await Promise.all([
    supabaseAdmin.from("referrals").select("*", { count: "exact", head: true }).eq("referrer_id", tgId),
    supabaseAdmin.from("withdrawals").select("amount,status,chain,created_at").eq("user_id", tgId).order("created_at", { ascending: false }).limit(3),
  ]);
  const coins = Number(me.coin_balance);
  const pending = me.is_banned ? 0 : pendingYield(coins, me.last_yield_at, Number(s.daily_yield_pct));
  const available = Math.max(0, Number(me.usdt_balance) - Number(me.admin_frozen));
  const r = (n: number, d = 4) => Number(n.toFixed(d));
  const lines = [
    `👤 <b>${me.name.replace(/[&<>]/g, "")}</b>${me.username !== "no-username" ? ` (@${me.username})` : ""}`,
    `🆔 ID: <code>${me.tg_user_id}</code> · Wallet #${me.wallet_index}`,
    me.is_banned ? `⛔ Account restricted${me.ban_reason ? `: ${me.ban_reason}` : ""}` : "",
    "",
    `🪙 Coins: <b>${r(coins, 2)}</b> (≈ ${r(coins / Number(s.coin_rate || 100))} USDT)`,
    `📈 Estimated profit to claim: ${r(pending / Number(s.coin_rate || 100), 6)} USDT (${s.daily_yield_pct}%/day, estimated, not guaranteed)`,
    `💵 USDT balance: <b>${r(Number(me.usdt_balance))}</b> · Available: ${r(available)}`,
    Number(me.usdt_frozen) > 0 ? `⏳ Pending withdrawal: ${r(Number(me.usdt_frozen))} USDT` : "",
    Number(me.admin_frozen) > 0 ? `🧊 Frozen: ${r(Number(me.admin_frozen))} USDT${me.freeze_reason ? ` — ${me.freeze_reason}` : ""}` : "",
    "",
    `⬇️ Total deposit: $${r(Number(me.total_deposit), 2)}`,
    `⬆️ Total withdrawal: ${r(Number(me.total_withdrawal))} USDT`,
    `👥 Friends invited: ${invited ?? 0} · Referral coins: ${r(Number(me.referral_earnings_coins), 2)}`,
    `🎁 Gift boxes: ${Number(me.gift_boxes ?? 0)}`,
    "",
    `🏦 Deposit (EVM – ETH/BNB): <code>${evmAddressFor(me.wallet_index)}</code>`,
    `💎 Deposit (GRAM): <code>${s.ton_address}</code>\n    Memo: <code>${s.memo_prefix ?? ""}${me.tg_user_id}</code>`,
    ...((wds ?? []).length ? ["", "🧾 Recent withdrawals:", ...(wds ?? []).map((w) => `• ${Number(w.amount)} USDT ${w.chain === "ton" ? "GRAM" : "BEP20"} — ${w.status}`)] : []),
  ];
  return lines.filter((l, i, a) => l !== "" || (a[i - 1] ?? "") !== "").join("\n");
}

export function pendingYield(coins: number, lastYieldAt: string, pct: number) {
  const days = Math.max(0, (Date.now() - new Date(lastYieldAt).getTime()) / 86400000);
  return (coins * pct) / 100 * days;
}

/** Per-user, per-action throttle (one row per key, overwritten each window). Throws when too fast. */
export async function rateLimit(key: string, max: number, windowSec: number, msg = "Too many requests, please wait a moment") {
  const { data, error } = await supabaseAdmin.rpc("rate_hit", { p_key: key, p_max: max, p_window_sec: windowSec });
  if (error) { console.error("[rate_hit]", key, error.message); return; }
  if (data === false) throw new Error(msg);
}

/** Client IP from the edge's forwarded headers. */
export async function clientIp(): Promise<string | null> {
  try {
    const { getRequestHeader } = await import("@tanstack/react-start/server");
    const ip = getRequestHeader("cf-connecting-ip") || getRequestHeader("x-real-ip") || getRequestHeader("x-forwarded-for")?.split(",")[0];
    return ip?.trim().slice(0, 64) || null;
  } catch { return null; }
}
