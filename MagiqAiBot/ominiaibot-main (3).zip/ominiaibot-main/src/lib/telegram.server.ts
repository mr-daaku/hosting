import { createHmac, createHash, timingSafeEqual } from "crypto";

export interface TgUser {
  id: number;
  first_name?: string;
  last_name?: string;
  username?: string;
  photo_url?: string;
}

function botToken() {
  const t = process.env["BOT_TOKEN"];
  if (!t) throw new Error("BOT_TOKEN is not configured");
  return t;
}

/** Verifies Telegram WebApp initData. Throws when invalid. */
export function verifyInitData(initData: string, maxAgeSec = 6 * 3600): { user: TgUser; startParam: string | null } {
  if (!initData) throw new Error("Please open this app inside Telegram");
  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) throw new Error("Invalid Telegram session");
  params.delete("hash");
  const dataCheck = [...params.entries()]
    .map(([k, v]) => `${k}=${v}`)
    .sort()
    .join("\n");
  const secret = createHmac("sha256", "WebAppData").update(botToken()).digest();
  const expected = createHmac("sha256", secret).update(dataCheck).digest("hex");
  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(hash, "hex");
  if (a.length !== b.length || !timingSafeEqual(a, b)) throw new Error("Invalid Telegram session");
  const authDate = Number(params.get("auth_date") || 0);
  if (Date.now() / 1000 - authDate > maxAgeSec) throw new Error("Telegram session expired, please reopen the app");
  const user = JSON.parse(params.get("user") || "null") as TgUser | null;
  if (!user?.id) throw new Error("Invalid Telegram session");
  return { user, startParam: params.get("start_param") };
}

export function webhookSecret() {
  return createHash("sha256").update(`tg-webhook:${botToken()}`).digest("base64url");
}

export async function tgApi(method: string, body: unknown) {
  const res = await fetch(`https://api.telegram.org/bot${botToken()}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const json = (await res.json()) as { ok: boolean; description?: string; result?: unknown };
  if (!json.ok) throw new Error(`Telegram ${method} failed [${res.status}]: ${json.description}`);
  return json.result;
}

export const BOT_USERNAME = "OminixAiBot";
export const appLink = (startapp: string | number) => `https://t.me/${BOT_USERNAME}/Trade?startapp=${startapp}`;

/** Fire-and-forget bot DM; never throws. */
export async function notify(chatId: number, html: string) {
  try {
    await tgApi("sendMessage", {
      chat_id: chatId, text: html, parse_mode: "HTML",
      reply_markup: { inline_keyboard: [[{ text: "Open OminiAi", url: `https://t.me/${BOT_USERNAME}/Trade` }]] },
    });
  } catch (e) { console.error("notify", chatId, e); }
}

/** "@name", "name", "https://t.me/name" or "-100…" → chat id. */
export function channelChatId(raw: string) {
  const v = raw.trim();
  if (/^-100\d+$/.test(v)) return v;
  const name = v.replace(/^https?:\/\/(t\.me|telegram\.me)\//i, "").replace(/^@/, "").split(/[/?]/)[0] ?? "";
  return name ? `@${name}` : "";
}

/** Post to a channel; skips silently when not configured, never throws. */
export async function postToChannel(raw: string | undefined | null, html: string) {
  const chatId = channelChatId(String(raw ?? ""));
  if (!chatId) return;
  try {
    await tgApi("sendMessage", { chat_id: chatId, text: html, parse_mode: "HTML", disable_web_page_preview: true });
  } catch (e) { console.error("postToChannel failed (is the bot an admin of the channel?)", chatId, e); }
}
