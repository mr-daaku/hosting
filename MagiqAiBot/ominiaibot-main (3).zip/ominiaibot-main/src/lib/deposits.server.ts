import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { getSettings, type Settings } from "./core.server";
import { notify } from "./telegram.server";

type Found = { chain: string; asset: string; tx: string; amount: number; fake?: boolean };
const looksStable = (sym: unknown) => /^(USDT|USDC|USD₮|USD₮0|TETHER)/i.test(String(sym ?? "").trim());

const EVM = {
  eth: { chainid: 1, native: "ETH", tokens: { USDT: "0xdac17f958d2ee523a2206206994597c13d831ec7", USDC: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48" } },
  bsc: { chainid: 56, native: "BNB", tokens: { USDT: "0x55d398326f99059ff775485246999027b3197955", USDC: "0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d" } },
} as const;
const TON_USDT_MASTER = "0:b113a994b5024a16719f69139328eb759596c38a25f59028b146fecdc3621dfe";
const GECKO: Record<string, string> = { ETH: "ethereum", BNB: "binancecoin", POL: "polygon-ecosystem-token", TRX: "tron", SOL: "solana", GRAM: "the-open-network" };

async function getJson(url: string, init?: RequestInit) {
  const r = await fetch(url, init);
  if (!r.ok) throw new Error(`${url.split("?")[0]} [${r.status}]`);
  return r.json() as Promise<any>;
}

let priceCache: { at: number; p: Record<string, number> } | null = null;
let inflight: Promise<{ values: Record<string, number>; updatedAt: number; stale: boolean }> | null = null;
/** Binance prices, cached 60s; concurrent callers share one request. */
export function prices() {
  if (priceCache && Date.now() - priceCache.at < 60000) return Promise.resolve({ values: priceCache.p, updatedAt: priceCache.at, stale: false });
  inflight ??= fetchPrices().finally(() => { inflight = null; });
  return inflight;
}
/** Coinbase public spot price — reachable from the server where Binance/CoinGecko block (451/403). */
async function coinbaseOne(sym: string) {
  try { const d = await getJson(`https://api.coinbase.com/v2/prices/${sym}-USD/spot`); const v = Number(d?.data?.amount); return v > 0 ? v : 0; } catch { return 0; }
}
async function okxOne(sym: string) {
  try { const d = await getJson(`https://www.okx.com/api/v5/market/ticker?instId=${sym}-USDT`); const v = Number(d?.data?.[0]?.last); return v > 0 ? v : 0; } catch { return 0; }
}
const MAIN = ["BNB", "ETH", "GRAM"] as const; // TON was renamed to GRAM; Binance lists GRAMUSDT
async function fetchPrices(): Promise<{ values: Record<string, number>; updatedAt: number; stale: boolean }> {
  const p: Record<string, number> = {};
  // 1) Binance (same as price-ficher.js). Binance blocks many cloud servers, so it may fail here.
  for (const host of ["https://api.binance.com", "https://data-api.binance.vision"]) {
    try {
      const arr = await getJson(`${host}/api/v3/ticker/price?symbols=${encodeURIComponent(JSON.stringify(MAIN.map((s) => `${s}USDT`)))}`);
      for (const s of MAIN) { const r = (arr as any[]).find((x) => x.symbol === `${s}USDT`); if (Number(r?.price) > 0) p[s] = Number(r.price); }
      if (MAIN.every((s) => p[s])) break;
    } catch { /* blocked from this server, try next */ }
  }
  // 2) Coinbase, 3) OKX for anything still missing
  await Promise.all(MAIN.filter((s) => !p[s]).map(async (s) => { p[s] = (await coinbaseOne(s)) || (await okxOne(s)); }));
  // 4) CoinGecko last
  if (MAIN.some((s) => !p[s])) {
    try {
      const j = await getJson(`https://api.coingecko.com/api/v3/simple/price?ids=${Object.values(GECKO).join(",")}&vs_currencies=usd`);
      for (const [sym, id] of Object.entries(GECKO)) if (!p[sym]) p[sym] = Number(j[id]?.usd ?? 0);
    } catch { /* blocked */ }
  }
  for (const k of Object.keys(p)) if (!(p[k]! > 0)) delete p[k];
  if (Object.keys(p).length) { priceCache = { at: Date.now(), p: { ...(priceCache?.p ?? {}), ...p } }; return { values: priceCache.p, updatedAt: priceCache.at, stale: false }; }
  console.error("price: all sources failed");
  if (priceCache) return { values: priceCache.p, updatedAt: priceCache.at, stale: true };
  throw new Error("Live price is unavailable right now");
}

/** Per-source check used by /api/public/prices-check. */
export async function priceSourceReport() {
  const test = async (name: string, url: string, pick: (j: any) => unknown) => {
    const t = Date.now();
    try { const r = await fetch(url); const j = await r.json().catch(() => null); return { name, status: r.status, ok: r.ok, value: r.ok ? pick(j) : null, ms: Date.now() - t }; }
    catch (e) { return { name, status: 0, ok: false, value: String((e as Error).message), ms: Date.now() - t }; }
  };
  return Promise.all([
    test("binance", "https://api.binance.com/api/v3/ticker/price?symbol=BNBUSDT", (j) => j?.price),
    test("binance-vision", "https://data-api.binance.vision/api/v3/ticker/price?symbol=BNBUSDT", (j) => j?.price),
    test("coinbase", "https://api.coinbase.com/v2/prices/GRAM-USD/spot", (j) => j?.data?.amount),
    test("okx", "https://www.okx.com/api/v5/market/ticker?instId=BNB-USDT", (j) => j?.data?.[0]?.last),
    test("coingecko", "https://api.coingecko.com/api/v3/simple/price?ids=binancecoin&vs_currencies=usd", (j) => j?.binancecoin?.usd),
  ]);
}

/** BigInt-safe hex → decimal amount. */
function formatUnits(hex: string, decimals: number): number {
  let v: bigint;
  try { v = BigInt(hex || "0x0"); } catch { return 0; }
  const base = 10n ** BigInt(decimals);
  const whole = v / base;
  const frac = (v % base).toString().padStart(decimals, "0").replace(/0+$/, "");
  return Number(frac ? `${whole}.${frac}` : whole.toString());
}

async function knownTx(hashes: string[]) {
  if (!hashes.length) return new Set<string>();
  const { data } = await supabaseAdmin.from("deposits").select("tx_hash").in("tx_hash", hashes);
  return new Set((data ?? []).map((d) => d.tx_hash));
}

const NODEREAL = { eth: { secret: "ETH_API", host: "eth-mainnet", dec: 6 }, bsc: { secret: "BSC_API", host: "bsc-mainnet", dec: 18 } } as const;

/** ETH & BSC via NodeReal nr_getTransactionByAddress — incoming only. */
async function scanEvm(address: string): Promise<Found[]> {
  const out: Found[] = [];
  const me = address.toLowerCase();
  for (const chain of ["eth", "bsc"] as const) {
    const key = process.env[NODEREAL[chain].secret];
    if (!key) { console.error(`${NODEREAL[chain].secret} not configured`); continue; }
    const cfg = EVM[chain];
    try {
      const j = await getJson(`https://${NODEREAL[chain].host}.nodereal.io/v1/${key}`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "nr_getTransactionByAddress",
          params: [{ category: ["external", "20"], address, order: "desc", maxCount: "0x64" }] }),
      });
      if (j.error) throw new Error(j.error.message);
      for (const t of (j.result?.transfers ?? []) as any[]) {
        const from = String(t.from ?? "").toLowerCase(), to = String(t.to ?? "").toLowerCase();
        if (from === me || to !== me) continue; // deposits only
        const tx = String(t.hash);
        if (t.category === "external") {
          const amount = formatUnits(t.value, 18);
          if (amount > 0) out.push({ chain, asset: cfg.native, tx, amount });
          continue;
        }
        const contract = String(t.contractAddress ?? "").toLowerCase();
        const sym = Object.entries(cfg.tokens).find(([, c]) => c === contract)?.[0];
        if (sym) out.push({ chain, asset: sym, tx, amount: formatUnits(t.value, NODEREAL[chain].dec) });
        else if (looksStable(t.asset)) out.push({ chain, asset: String(t.asset).slice(0, 10), tx, amount: formatUnits(t.value, Number(t.decimal ?? 18)), fake: true });
      }
    } catch (e) { console.error("evm scan", chain, e); }
  }
  return out;
}

/** Admin: every incoming/outgoing transfer for an EVM address on ETH + BSC (same NodeReal method as scanning). */
export async function inspectEvmAddress(address: string) {
  const me = address.toLowerCase();
  const rows: { chain: string; asset: string; amount: number; from: string; to: string; tx: string; direction: "in" | "out"; official: boolean; time: number | null }[] = [];
  const errors: string[] = [];
  for (const chain of ["bsc", "eth"] as const) {
    const key = process.env[NODEREAL[chain].secret];
    if (!key) { errors.push(`${chain}: API key missing`); continue; }
    const cfg = EVM[chain];
    try {
      const j = await getJson(`https://${NODEREAL[chain].host}.nodereal.io/v1/${key}`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "nr_getTransactionByAddress",
          params: [{ category: ["external", "20"], address, order: "desc", maxCount: "0x64" }] }),
      });
      if (j.error) throw new Error(j.error.message);
      for (const t of (j.result?.transfers ?? []) as any[]) {
        const from = String(t.from ?? "").toLowerCase(), to = String(t.to ?? "").toLowerCase();
        const contract = String(t.contractAddress ?? "").toLowerCase();
        const sym = t.category === "external" ? cfg.native : Object.entries(cfg.tokens).find(([, c]) => c === contract)?.[0];
        const dec = t.category === "external" ? 18 : sym ? NODEREAL[chain].dec : Number(t.decimal ?? 18);
        rows.push({ chain, asset: sym ?? String(t.asset || "TOKEN").slice(0, 12), amount: formatUnits(t.value, dec), from, to, tx: String(t.hash),
          direction: to === me ? "in" : "out", official: !!sym, time: t.blockTimeStamp ? Number(t.blockTimeStamp) * 1000 : null });
      }
    } catch (e) { errors.push(`${chain}: ${(e as Error).message}`); }
  }
  const { data: known } = await supabaseAdmin.from("deposits").select("tx_hash,status").in("tx_hash", rows.map((r) => r.tx).slice(0, 200));
  const st = new Map((known ?? []).map((k: any) => [k.tx_hash, k.status ?? "confirmed"]));
  return { rows: rows.map((r) => ({ ...r, recorded: st.get(r.tx) ?? null })), errors };
}

/** Any GRAM (ex-TON) address form (UQ…/EQ…/0:hex) → canonical "wc:hex" so bounceable & non-bounceable match. */
export function tonRaw(addr: string): string {
  const a = String(addr ?? "").trim();
  if (/^-?\d+:[0-9a-fA-F]{64}$/.test(a)) { const [wc, h] = a.split(":"); return `${Number(wc)}:${h!.toLowerCase()}`; }
  try {
    const buf = Buffer.from(a.replace(/-/g, "+").replace(/_/g, "/"), "base64");
    if (buf.length !== 36) return a.toLowerCase();
    return `${buf.readInt8(1)}:${buf.subarray(2, 34).toString("hex")}`;
  } catch { return a.toLowerCase(); }
}

/**
 * Plain-text comment from a TonCenter v2 message (same idea as ton-scan.js). TonCenter decodes text
 * comments into msg.dataText; msg.dataRaw is binary (jetton notifications, encrypted) → null.
 */
function tonMemo(m: any): string | null {
  const d = m?.msg_data;
  if (d?.["@type"] === "msg.dataText") {
    try { const t = Buffer.from(String(d.text ?? ""), "base64").toString("utf8").replace(/[^\x20-\x7E\u0900-\u097F]/g, "").trim(); if (t) return t; } catch { /* fall through */ }
    return typeof m.message === "string" && m.message.trim() ? m.message.trim() : null;
  }
  if (d?.["@type"] === "msg.dataRaw") return null;
  return typeof m?.message === "string" && m.message.trim() ? m.message.trim() : null;
}

const TON_USDT_FRIENDLY = "EQCxE6mUtQJKFnGfaROTKOt1lZbDiiX1kCixRv7Nw2Id_sDs";
const b64hex = (s: string) => { try { return Buffer.from(s, "base64").toString("hex"); } catch { return s; } };

async function withRetry<T>(fn: () => Promise<T>, tries = 3): Promise<T> {
  let last: unknown;
  for (let i = 0; i < tries; i++) {
    try { return await fn(); } catch (e) { last = e; await new Promise((r) => setTimeout(r, 800 * (i + 1))); }
  }
  throw last;
}

/** USDT on GRAM via TonCenter v3 (decoded comment). Tx key = trace id in hex (same as TonAPI event_id). */
async function scanTonUsdtCenter(tonAddress: string, key?: string): Promise<(Found & { memo: string })[]> {
  const out: (Found & { memo: string })[] = [];
  const me = tonRaw(tonAddress);
  const j = await withRetry(() => getJson(`https://toncenter.com/api/v3/jetton/transfers?owner_address=${encodeURIComponent(tonAddress)}&direction=in&limit=50&sort=desc`, key ? { headers: { "X-API-Key": key } } : undefined));
  for (const t of (j.jetton_transfers ?? []) as any[]) {
    if (t.transaction_aborted || tonRaw(t.destination) !== me) continue;
    const memo = String(t.decoded_forward_payload?.comment ?? t.comment ?? "").trim();
    if (!memo) continue;
    const master = tonRaw(t.jetton_master);
    const tx = t.trace_id ? b64hex(t.trace_id) : b64hex(t.transaction_hash);
    if (master === TON_USDT_MASTER) { out.push({ chain: "ton", asset: "USDT", tx, amount: Number(t.amount) / 1e6, memo }); continue; }
    const meta = j.metadata?.[t.jetton_master] ?? j.metadata?.[String(t.jetton_master).toUpperCase()];
    const info = meta?.token_info?.[0];
    if (looksStable(info?.symbol)) out.push({ chain: "ton", asset: String(info.symbol).slice(0, 10), tx, amount: Number(t.amount) / 10 ** Number(info?.extra?.decimals ?? 6), memo, fake: true });
  }
  return out;
}

/** Fallback: USDT jetton history via TonAPI (same method as scan.html). */
async function scanTonUsdtApi(tonAddress: string): Promise<(Found & { memo: string })[]> {
  const out: (Found & { memo: string })[] = [];
  const me = tonRaw(tonAddress);
  const j = await withRetry(() => getJson(`https://tonapi.io/v2/accounts/${encodeURIComponent(tonAddress)}/jettons/${TON_USDT_FRIENDLY}/history?limit=50`));
  for (const ev of j.events ?? []) {
    if (ev.in_progress) continue;
    for (const a of ev.actions ?? []) {
      const jt = a.JettonTransfer;
      if (a.status !== "ok" || a.type !== "JettonTransfer" || !jt?.comment) continue;
      if (tonRaw(jt.recipient?.address) !== me || tonRaw(jt.jetton?.address) !== TON_USDT_MASTER) continue;
      out.push({ chain: "ton", asset: "USDT", tx: String(ev.event_id), amount: Number(jt.amount) / 1e6, memo: String(jt.comment).trim() });
    }
  }
  return out;
}

/** GRAM (ex-TON): one shared address; native GRAM via TonCenter v2 (memo mandatory), USDT via TonCenter v3 → TonAPI. */
export async function scanTon(tonAddress: string): Promise<(Found & { memo: string })[]> {
  const out: (Found & { memo: string })[] = [];
  const me = tonRaw(tonAddress);
  const key = process.env["TON_API_KEY"];
  try {
    const j = await withRetry(() => getJson(`https://toncenter.com/api/v2/getTransactions?address=${encodeURIComponent(tonAddress)}&limit=50&archival=true`, key ? { headers: { "X-API-Key": key } } : undefined));
    if (j.ok === false) throw new Error(String(j.error));
    for (const t of (j.result ?? []) as any[]) {
      const m = t.in_msg;
      // TonCenter returns the bounceable EQ… form while settings hold UQ…, so compare raw addresses.
      if (!m?.source || tonRaw(m.destination) !== me || m.bounced) continue;
      const amount = formatUnits("0x" + BigInt(m.value || "0").toString(16), 9);
      if (amount <= 0) continue;
      const memo = tonMemo(m);
      const tx = String(t.transaction_id?.hash ?? "");
      if (!memo) continue;
      out.push({ chain: "ton", asset: "GRAM", tx, amount, memo });
    }
  } catch (e) { console.error("gram scan", e); }
  let usdt: (Found & { memo: string })[] = [];
  try { usdt = await scanTonUsdtCenter(tonAddress, key); }
  catch (e) {
    console.error("gram usdt scan (toncenter)", e);
    try { usdt = await scanTonUsdtApi(tonAddress); } catch (e2) { console.error("gram usdt scan (tonapi)", e2); }
  }
  out.push(...usdt);
  return out;
}

async function rejectFake(userId: number, f: Found) {
  const { data } = await supabaseAdmin.from("deposits").upsert({
    user_id: userId, chain: f.chain, asset: f.asset, tx_hash: f.tx, amount: f.amount, usd_value: 0, coins_credited: 0, status: "fake",
  }, { onConflict: "tx_hash,asset", ignoreDuplicates: true }).select("id");
  if (data?.length)
    await notify(userId, `⚠️ <b>Fake token detected</b>\nA transfer of ${f.amount} "${f.asset}" on ${f.chain} is not the official USDT/USDC contract and was <b>not credited</b>.\nTx: <code>${f.tx}</code>`);
  return data?.length ? { ...f, usd: 0, coins: 0 } : null;
}

/** Native → USDT (live price) → coins (coin_rate). Deduped by tx hash. */
export async function credit(userId: number, f: Found, s: Settings, opts: { force?: boolean } = {}) {
  if (f.fake) return rejectFake(userId, f);
  const stable = f.asset === "USDT" || f.asset === "USDC";
  const p: Record<string, number> = stable ? {} : (await prices()).values;
  const usd = Math.round(f.amount * (stable ? 1 : p[f.asset] ?? 0) * 1e4) / 1e4;
  if (!opts.force && usd < Number(s.min_deposit_usd)) {
    const { data } = await supabaseAdmin.from("deposits").upsert({
      user_id: userId, chain: f.chain, asset: f.asset, tx_hash: f.tx, amount: f.amount, usd_value: usd, coins_credited: 0, status: "below_minimum",
    }, { onConflict: "tx_hash,asset", ignoreDuplicates: true }).select("id");
    return data?.length ? { ...f, usd, coins: 0, below: true } : null;
  }
  if (usd <= 0) return null;
  // No referral deposit bonus any more (p_ref_pct = 0).
  const { data, error } = await supabaseAdmin.rpc("credit_deposit", {
    p_user: userId, p_chain: f.chain, p_asset: f.asset, p_tx: f.tx, p_amount: f.amount, p_usd: usd,
    p_rate: Number(s.coin_rate), p_ref_pct: 0,
  });
  if (error) { console.error("credit", error); throw new Error(error.message); }
  if (data == null) return null;
  const coins = Number(data);
  await notify(userId, `✅ <b>Deposit confirmed</b>\n${f.amount} ${f.asset} (${f.chain}) ≈ $${usd} → <b>+${coins} coins</b>\nTx: <code>${f.tx}</code>`);
  return { ...f, usd, coins };
}

type UserRow = { tg_user_id: number; wallet_index: number; is_banned: boolean };
export const USER_SCAN_COLS = "tg_user_id,wallet_index,is_banned";

export async function scanUser(u: UserRow, tonCache?: (Found & { memo: string })[]) {
  if (u.is_banned) return [];
  const s = await getSettings();
  const found: Found[] = [];
  // Address is generated from the wallet index on the spot (not read from the database).
  const { evmAddressFor } = await import("./wallet.server");
  found.push(...(await scanEvm(evmAddressFor(u.wallet_index))));
  const ton = tonCache ?? (await scanTon(s.ton_address));
  const myMemo = `${s.memo_prefix}${u.tg_user_id}`.trim().toUpperCase();
  if (myMemo) found.push(...ton.filter((t) => t.memo.trim().toUpperCase() === myMemo));
  const known = await knownTx(found.map((f) => f.tx));
  const credited = [];
  for (const f of found) {
    if (known.has(f.tx)) continue;
    try {
      const c = await credit(u.tg_user_id, f, s);
      if (c) credited.push(c);
    } catch (e) { console.error("credit failed", e); }
  }
  return credited;
}

export async function scanActiveUsers() {
  const s = await getSettings();
  const since = new Date(Date.now() - 48 * 3600000).toISOString();
  const { data: users } = await supabaseAdmin.from("users")
    .select(USER_SCAN_COLS)
    .eq("is_banned", false).gte("last_seen_at", since).limit(200);
  const ton = await scanTon(s.ton_address);
  let total = 0;
  for (const u of users ?? []) total += (await scanUser(u, ton)).length;
  return { users: users?.length ?? 0, credited: total };
}
