// Client-safe chain / coin catalogue with real coin logos from the internet.
export const LOGO = {
  COIN: "https://img.icons8.com/fluency/96/coins.png",
  GIFT: "https://img.icons8.com/3d-fluency/94/gift.png",
  USDT: "https://assets.coingecko.com/coins/images/325/large/Tether.png",
  USDC: "https://assets.coingecko.com/coins/images/6319/large/usdc.png",
  ETH: "https://assets.coingecko.com/coins/images/279/large/ethereum.png",
  BNB: "https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png",
  POL: "https://assets.coingecko.com/coins/images/32440/large/polygon.png",
  TRX: "https://assets.coingecko.com/coins/images/1094/large/tron-logo.png",
  SOL: "https://assets.coingecko.com/coins/images/4128/large/solana.png",
  GRAM: "https://assets.coingecko.com/coins/images/17980/large/ton_symbol.png",
} as const;

export type ChainId = "eth" | "bsc" | "polygon" | "tron" | "solana" | "ton";
export type WalletKind = "evm" | "tron" | "solana" | "ton";

export interface AssetDef {
  symbol: string;
  label: string;
  logo: string;
  stable: boolean;
}

export interface ChainDef {
  id: ChainId;
  name: string;
  network: string;
  logo: string;
  wallet: WalletKind;
  explorerTx: string;
  assets: AssetDef[];
}

export const CHAINS: ChainDef[] = [
  {
    id: "eth", name: "Ethereum", network: "ERC20", logo: LOGO.ETH, wallet: "evm",
    explorerTx: "https://etherscan.io/tx/",
    assets: [
      { symbol: "ETH", label: "ETH", logo: LOGO.ETH, stable: false },
      { symbol: "USDT", label: "USDT ERC20", logo: LOGO.USDT, stable: true },
      { symbol: "USDC", label: "USDC ERC20", logo: LOGO.USDC, stable: true },
    ],
  },
  {
    id: "bsc", name: "BNB Chain", network: "BEP20", logo: LOGO.BNB, wallet: "evm",
    explorerTx: "https://bscscan.com/tx/",
    assets: [
      { symbol: "BNB", label: "BNB", logo: LOGO.BNB, stable: false },
      { symbol: "USDT", label: "USDT BEP20", logo: LOGO.USDT, stable: true },
      { symbol: "USDC", label: "USDC BEP20", logo: LOGO.USDC, stable: true },
    ],
  },
  {
    id: "ton", name: "GRAM", network: "GRAM", logo: LOGO.GRAM, wallet: "ton",
    explorerTx: "https://tonviewer.com/transaction/",
    assets: [
      { symbol: "GRAM", label: "GRAM", logo: LOGO.GRAM, stable: false },
      { symbol: "USDT", label: "USDT GRAM", logo: LOGO.USDT, stable: true },
    ],
  },
];

export const chainById = (id: string) => CHAINS.find((c) => c.id === id);

/** Payouts are always USDT, only on BEP20 or GRAM (ex-TON). */
export const WITHDRAW_OPTIONS = [
  { chain: "bsc", asset: "USDT", label: "USDT BEP20", network: "BNB Chain", logo: LOGO.USDT, chainLogo: LOGO.BNB },
  { chain: "ton", asset: "USDT", label: "USDT GRAM", network: "GRAM", logo: LOGO.USDT, chainLogo: LOGO.GRAM },
] as const;

const TRUST_COIN: Record<ChainId, number> = { eth: 60, bsc: 20000714, polygon: 966, tron: 195, solana: 501, ton: 607 };

/** Deep link that opens a wallet app with the deposit address pre-filled. */
export function walletLink(chain: ChainDef, address: string, memo?: string | null) {
  if (chain.wallet === "ton") return `https://app.tonkeeper.com/transfer/${address}${memo ? `?text=${encodeURIComponent(memo)}` : ""}`;
  return `https://link.trustwallet.com/send?coin=${TRUST_COIN[chain.id]}&address=${address}`;
}

export const fmt = (n: number, d = 2) =>
  Number(n || 0).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
