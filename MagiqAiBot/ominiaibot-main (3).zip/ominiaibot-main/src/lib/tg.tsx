import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getMe } from "./app.functions";

/** Telegram user id straight from the Telegram app (no server call). */
export function tgUserId(): number | null {
  const id = window.Telegram?.WebApp?.initDataUnsafe?.user?.id;
  return typeof id === "number" ? id : null;
}
import { applyLanguage } from "./i18n";

declare global {
  interface Window {
    Telegram?: { WebApp?: any };
  }
}

type Ctx = { initData: string; status: "loading" | "ready" | "outside" | "error"; error?: string };
const TgCtx = createContext<Ctx>({ initData: "", status: "loading" });

const ME_CACHE = "omini-me-cache";
type MeData = Awaited<ReturnType<typeof getMe>>;

/** Last-known home data from this phone (shown instantly on open, then refreshed). */
function readMeCache(userId: number | null): MeData | undefined {
  try {
    const raw = localStorage.getItem(ME_CACHE);
    if (!raw || userId == null) return undefined;
    const c = JSON.parse(raw) as { id: number; data: MeData };
    return c.id === userId ? c.data : undefined;
  } catch { return undefined; }
}
function writeMeCache(data: MeData) {
  try { localStorage.setItem(ME_CACHE, JSON.stringify({ id: data.me.id, data })); } catch { /* storage full/blocked */ }
}

export function TgProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<Ctx>({ initData: "", status: "loading" });
  const qc = useQueryClient();

  useEffect(() => {
    let cancelled = false;
    let tries = 0;
    const start = async () => {
      const wa = window.Telegram?.WebApp;
      if (!wa && tries++ < 20) return void setTimeout(start, 150);
      const initData: string = wa?.initData ?? "";
      if (!initData) return setState({ initData: "", status: "outside" });
      try {
        wa.ready?.();
        wa.expand?.();
        const mobile = ["android", "ios"].includes(String(wa.platform));
        if (mobile && typeof wa.requestFullscreen === "function" && wa.isVersionAtLeast?.("8.0")) wa.requestFullscreen();
        wa.disableVerticalSwipes?.();
        wa.setHeaderColor?.("#1a2140");
        wa.setBackgroundColor?.("#1a2140");
      } catch { /* older clients: expand() already applied */ }
      // Show last session's data at once (marked stale so it refreshes in the background).
      const cached = readMeCache(tgUserId());
      if (cached && !qc.getQueryData(["me"])) qc.setQueryData(["me"], cached, { updatedAt: 0 });
      // Account setup happens inside the first getMe request (one round trip on open).
      if (!cancelled) setState({ initData, status: "ready" });
    };
    start();
    return () => { cancelled = true; };
  }, [qc]);

  return <TgCtx.Provider value={state}>{children}</TgCtx.Provider>;
}

export const useTg = () => useContext(TgCtx);

/** Device fingerprint: SHA-256 of stable hardware/browser signals (same for every Telegram account on this phone). */
let fpPromise: Promise<string | undefined> | null = null;
function deviceFingerprint(): Promise<string | undefined> {
  if (fpPromise) return fpPromise;
  fpPromise = (async () => {
    try {
      let gpu = "";
      try {
        const gl = document.createElement("canvas").getContext("webgl") as WebGLRenderingContext | null;
        const ext = gl?.getExtension("WEBGL_debug_renderer_info");
        if (gl && ext) gpu = `${gl.getParameter(ext.UNMASKED_VENDOR_WEBGL)}|${gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)}`;
      } catch { /* no webgl */ }
      const s = window.screen;
      const parts = [navigator.userAgent, navigator.platform, navigator.hardwareConcurrency, (navigator as any).deviceMemory,
        s.width, s.height, s.colorDepth, window.devicePixelRatio, Intl.DateTimeFormat().resolvedOptions().timeZone, gpu, navigator.maxTouchPoints].join("~");
      const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(parts));
      return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
    } catch {
      // Fallback hash so the device check is never skipped.
      const str = `${navigator.userAgent}~${screen.width}x${screen.height}~${navigator.hardwareConcurrency}`;
      let h = "";
      for (let k = 0; k < 8; k++) { let x = 2166136261 ^ k; for (let i = 0; i < str.length; i++) x = Math.imul(x ^ str.charCodeAt(i), 16777619); h += (x >>> 0).toString(16).padStart(8, "0"); }
      return h;
    }
  })();
  return fpPromise;
}

export function useMe(opts: { live?: boolean } = {}) {
  const { initData, status } = useTg();
  return useQuery({
    queryKey: ["me"],
    queryFn: async () => {
      const fp = await deviceFingerprint();
      const d = await getMe({ data: { initData, fp: fp ?? "0".repeat(64) } });
      writeMeCache(d);
      return d;
    },
    enabled: status === "ready",
    staleTime: 30_000,
    // Profile photo comes live from Telegram on every open; it is never stored.
    select: (d) => {
      const u = (window as any).Telegram?.WebApp?.initDataUnsafe?.user;
      const photo: string | null = typeof u?.photo_url === "string" && u.photo_url ? u.photo_url : null;
      return photo ? { ...d, me: { ...d.me, photo } } : d;
    },
    // Poll only where live numbers matter; nothing polls by default.
    refetchInterval: opts.live ? 60_000 : false,
  });
}

export function useRefreshMe() {
  const qc = useQueryClient();
  return () => qc.invalidateQueries({ queryKey: ["me"] });
}

export function haptic(kind: "success" | "error" | "light" = "light") {
  const h = window.Telegram?.WebApp?.HapticFeedback;
  if (!h) return;
  if (kind === "light") h.impactOccurred?.("light");
  else h.notificationOccurred?.(kind);
}

export function openLink(url: string) {
  const wa = window.Telegram?.WebApp;
  if (url.startsWith("https://t.me/") && wa?.openTelegramLink) wa.openTelegramLink(url);
  else if (wa?.openLink) wa.openLink(url);
  else window.open(url, "_blank");
}

export type Theme = "dark" | "light";
export function useTheme(): [Theme, (t: Theme) => void] {
  const [theme, setTheme] = useState<Theme>("dark");
  useEffect(() => {
    const t = (localStorage.getItem("omini-theme") as Theme) || "dark";
    setTheme(t);
  }, []);
  const set = (t: Theme) => {
    setTheme(t);
    localStorage.setItem("omini-theme", t);
    document.documentElement.classList.toggle("light", t === "light");
  };
  return [theme, set];
}

/** Apply the saved theme once on load. */
export function useApplyTheme() {
  useEffect(() => {
    document.documentElement.classList.toggle("light", localStorage.getItem("omini-theme") === "light");
    applyLanguage(localStorage.getItem("omini-language") || "en");
  }, []);
}
