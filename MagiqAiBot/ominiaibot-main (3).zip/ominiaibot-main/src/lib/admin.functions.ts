import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const auth = z.object({ initData: z.string().min(1).max(8000) });

async function ctx(initData: string) {
  const { requireAdmin } = await import("./core.server");
  const admin = await requireAdmin(initData);
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return { admin, db: supabaseAdmin };
}

export const adminDashboard = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.parse(d))
  .handler(async ({ data }) => {
    const { db } = await ctx(data.initData);
    const now = Date.now();
    const cnt = (q: any) => q.then((r: any) => r.count ?? 0);
    const midnight = new Date(); midnight.setUTCHours(0, 0, 0, 0);
    const [users, banned, today, pending, sums] = await Promise.all([
      cnt(db.from("users").select("*", { count: "exact", head: true })),
      cnt(db.from("users").select("*", { count: "exact", head: true }).eq("is_banned", true)),
      cnt(db.from("users").select("*", { count: "exact", head: true }).gte("joined_at", new Date(now - 86400000).toISOString())),
      cnt(db.from("withdrawals").select("*", { count: "exact", head: true }).eq("status", "pending")),
      // Summed in SQL: reading user rows was capped at 1000 rows, so totals were wrong.
      db.rpc("admin_totals" as any, { p_since: midnight.toISOString() } as any),
    ]);
    if (sums.error) throw new Error(sums.error.message);
    const t = (sums.data ?? {}) as Record<string, number>;
    const n = (k: string) => Number(t[k] ?? 0);
    return {
      users, banned, today, pending, coins: n("coins"),
      deposits: n("dep_all"), withdrawals: n("wd_all"),
      depositsToday: n("dep_today"), withdrawalsToday: n("wd_today"),
      profitToday: n("dep_today") - n("wd_today"), profitAll: n("dep_all") - n("wd_all"),
    };
  });

export const adminSearchUsers = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ q: z.string().max(100) }).parse(d))
  .handler(async ({ data }) => {
    const { db } = await ctx(data.initData);
    const q = data.q.trim().replace(/[%,()]/g, "");
    if (!q) return [];
    let query = db.from("users").select("tg_user_id,name,username,coin_balance,usdt_balance,is_banned").order("joined_at", { ascending: false }).limit(30);
    query = /^\d+$/.test(q) ? query.eq("tg_user_id", Number(q)) : query.or(`username.ilike.%${q}%,name.ilike.%${q}%`);
    const { data: rows } = await query;
    return rows ?? [];
  });

export const adminGetUser = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ id: z.number() }).parse(d))
  .handler(async ({ data }) => {
    const { db } = await ctx(data.initData);
    const [{ data: u }, { count: invited }, s] = await Promise.all([
      db.from("users").select("*").eq("tg_user_id", data.id).single(),
      db.from("referrals").select("*", { count: "exact", head: true }).eq("referrer_id", data.id),
      (await import("./core.server")).getSettings(),
    ]);
    if (!u) throw new Error("User not found");
    const { evmAddressFor } = await import("./wallet.server");
    return { user: u, invited: invited ?? 0, evm: evmAddressFor(u.wallet_index), gramMemo: `${s.memo_prefix ?? ""}${u.tg_user_id}` };
  });

export const adminUpdateUser = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({
    id: z.number(), coinDelta: z.number().optional(), usdtDelta: z.number().optional(),
    banned: z.boolean().optional(), banReason: z.string().max(200).optional(),
    freeze: z.number().min(0).max(1e9).optional(), freezeReason: z.string().max(200).optional(),
  }).parse(d))
  .handler(async ({ data }) => {
    const { db, admin } = await ctx(data.initData);
    const { applyBalance } = await import("./core.server");
    if (data.coinDelta || data.usdtDelta)
      await applyBalance(data.id, "admin_adjust", data.coinDelta ?? 0, data.usdtDelta ?? 0, `By admin ${admin.id}`);
    if (data.banned === true) await db.rpc("ban_user", { p_user: data.id, p_reason: data.banReason || "manual", p_ip: "" });
    else if (data.banned === false)
      await db.from("users").update({ is_banned: data.banned, ban_reason: data.banned ? data.banReason || "manual" : null }).eq("tg_user_id", data.id);
    if (data.freeze !== undefined)
      await db.from("users").update({ admin_frozen: data.freeze, freeze_reason: data.freeze > 0 ? data.freezeReason || null : null }).eq("tg_user_id", data.id);
    return { ok: true };
  });

export const adminManualDeposit = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({
    id: z.number(), chain: z.enum(["eth", "bsc", "ton"]),
    asset: z.string().max(10), tx: z.string().trim().min(8).max(200), amount: z.number().positive().max(1e9),
  }).parse(d))
  .handler(async ({ data }) => {
    const { db } = await ctx(data.initData);
    const { chainById } = await import("./assets");
    const { getSettings } = await import("./core.server");
    const { credit } = await import("./deposits.server");
    const c = chainById(data.chain);
    if (!c?.assets.some((a) => a.symbol === data.asset)) throw new Error("Unsupported coin for this network");
    const { data: dup } = await db.from("deposits").select("id").eq("tx_hash", data.tx).limit(1);
    if (dup?.length) throw new Error("This tx hash is already recorded");
    const r = await credit(data.id, { chain: data.chain, asset: data.asset, tx: data.tx, amount: data.amount }, await getSettings(), { force: true });
    if (!r) throw new Error("Could not credit (price unavailable or duplicate)");
    return { usd: r.usd, coins: r.coins };
  });

export const adminAddAdmin = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ id: z.number().int().positive() }).parse(d))
  .handler(async ({ data }) => {
    const { db } = await ctx(data.initData);
    await db.from("admins").upsert({ tg_user_id: data.id }, { ignoreDuplicates: true });
    (await import("./core.server")).invalidateAdminCache();
    return { ok: true };
  });

export const adminRemoveAdmin = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ id: z.number().int().positive() }).parse(d))
  .handler(async ({ data }) => {
    const { db, admin } = await ctx(data.initData);
    if (data.id === admin.id) throw new Error("You cannot remove yourself");
    await db.from("admins").delete().eq("tg_user_id", data.id);
    (await import("./core.server")).invalidateAdminCache();
    return { ok: true };
  });

export const adminWithdrawals = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ status: z.enum(["pending", "paid", "rejected"]) }).parse(d))
  .handler(async ({ data }) => {
    const { db } = await ctx(data.initData);
    const { data: rows } = await db.from("withdrawals").select("*").eq("status", data.status).order("created_at", { ascending: false }).limit(100);
    const ids = [...new Set((rows ?? []).map((r) => r.user_id))];
    const stats: Record<string, { total: number; times: number; frozen: number }> = {};
    if (ids.length) {
      const [{ data: paid }, { data: us }] = await Promise.all([
        db.from("withdrawals").select("user_id,amount").in("user_id", ids).eq("status", "paid"),
        db.from("users").select("tg_user_id,admin_frozen").in("tg_user_id", ids),
      ]);
      for (const id of ids) stats[id] = { total: 0, times: 0, frozen: Number(us?.find((u) => u.tg_user_id === id)?.admin_frozen ?? 0) };
      for (const p of paid ?? []) { const x = stats[p.user_id]!; x.total += Number(p.amount); x.times++; }
    }
    return (rows ?? []).map((r) => ({ ...r, stats: stats[r.user_id] ?? { total: 0, times: 0, frozen: 0 } }));
  });

/** Freeze the requested amount on the user's balance (adds to any existing freeze). */
export const adminFreezeWithdrawal = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const { db } = await ctx(data.initData);
    const { data: w } = await db.from("withdrawals").select("user_id,amount").eq("id", data.id).maybeSingle();
    if (!w) throw new Error("Withdrawal not found");
    const { data: u } = await db.from("users").select("admin_frozen,freeze_reason").eq("tg_user_id", w.user_id).single();
    const total = Number(u?.admin_frozen ?? 0) + Number(w.amount);
    await db.from("users").update({ admin_frozen: total, freeze_reason: u?.freeze_reason || "Frozen by admin (withdrawal review)" }).eq("tg_user_id", w.user_id);
    return { frozen: total };
  });

export const adminReviewWithdrawal = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({
    id: z.string().uuid(), action: z.enum(["pay", "reject"]),
    txHash: z.string().max(200).optional(), reason: z.string().max(300).optional(), refund: z.boolean().optional(), auto: z.boolean().optional(),
  }).parse(d))
  .handler(async ({ data }) => {
    const { admin } = await ctx(data.initData);
    const { reviewWithdrawal } = await import("./payout.server");
    const r = await reviewWithdrawal({ id: data.id, action: data.action, adminId: admin.id, txHash: data.txHash, reason: data.reason, refund: data.refund, auto: data.auto });
    return { ok: true, txHash: r.txHash };
  });

/** Delete finished (paid / rejected) withdrawal records — one by id, or all of a status. Pending ones are never deleted. */
export const adminDeleteWithdrawals = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({
    status: z.enum(["paid", "rejected"]),
    id: z.string().uuid().optional(),
  }).parse(d))
  .handler(async ({ data }) => {
    const { db } = await ctx(data.initData);
    let q = db.from("withdrawals").delete().eq("status", data.status);
    if (data.id) q = q.eq("id", data.id);
    const { data: rows, error } = await q.select("id");
    if (error) throw new Error(error.message);
    return { deleted: rows?.length ?? 0 };
  });

export const adminDeposits = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ userId: z.string().max(20) }).parse(d))
  .handler(async ({ data }) => {
    const { db } = await ctx(data.initData);
    let q = db.from("deposits").select("*").order("created_at", { ascending: false }).limit(200);
    if (/^\d+$/.test(data.userId)) q = q.eq("user_id", Number(data.userId));
    const { data: rows } = await q;
    const ids = [...new Set((rows ?? []).map((r) => r.user_id))];
    const { data: us } = ids.length ? await db.from("users").select("tg_user_id,wallet_index").in("tg_user_id", ids) : { data: [] };
    const idx = new Map((us ?? []).map((u) => [u.tg_user_id, u.wallet_index as number | null]));
    return (rows ?? []).map((r) => ({ ...r, wallet_index: idx.get(r.user_id) ?? null }));
  });

/** Users with an admin freeze on their balance. */
export const adminFrozenUsers = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.parse(d))
  .handler(async ({ data }) => {
    const { db } = await ctx(data.initData);
    const { data: rows } = await db.from("users").select("tg_user_id,name,username,usdt_balance,admin_frozen,freeze_reason,wallet_index")
      .gt("admin_frozen", 0).order("admin_frozen", { ascending: false }).limit(500);
    const list = (rows ?? []).map((r) => ({ ...r, admin_frozen: Number(r.admin_frozen), usdt_balance: Number(r.usdt_balance) }));
    return { users: list, total: list.reduce((a, r) => a + r.admin_frozen, 0) };
  });

/** Remove some or all of a user's admin freeze. amount omitted → unfreeze everything. */
export const adminUnfreeze = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ id: z.number().int().positive(), amount: z.number().positive().max(1e9).optional() }).parse(d))
  .handler(async ({ data }) => {
    const { db } = await ctx(data.initData);
    const { data: u } = await db.from("users").select("admin_frozen").eq("tg_user_id", data.id).single();
    if (!u) throw new Error("User not found");
    const left = data.amount === undefined ? 0 : Math.max(0, Math.round((Number(u.admin_frozen) - data.amount) * 1e6) / 1e6);
    await db.from("users").update({ admin_frozen: left, ...(left === 0 ? { freeze_reason: null } : {}) }).eq("tg_user_id", data.id);
    const { notify } = await import("./telegram.server");
    if (left === 0) await notify(data.id, "✅ <b>Balance unfrozen</b>\nYour USDT balance is fully available again.");
    return { frozen: left };
  });

export const adminInspectAddress = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ address: z.string().trim().regex(/^0x[0-9a-fA-F]{40}$/) }).parse(d))
  .handler(async ({ data }) => {
    const { db } = await ctx(data.initData);
    const { inspectEvmAddress, scanUser, USER_SCAN_COLS } = await import("./deposits.server");
    const { findWalletIndex } = await import("./wallet.server");
    // Addresses are never stored: find the owner by re-generating addresses from wallet numbers.
    const { data: top } = await db.from("users").select("wallet_index").order("wallet_index", { ascending: false }).limit(1).maybeSingle();
    const idx = findWalletIndex(data.address, Number(top?.wallet_index ?? 0));
    const { data: owner } = idx === null ? { data: null } : await db.from("users").select(USER_SCAN_COLS).eq("wallet_index", idx).maybeSingle();
    let credited = 0;
    if (owner) credited = (await scanUser(owner)).length;
    const res = await inspectEvmAddress(data.address);
    return { ...res, owner: owner?.tg_user_id ?? null, credited };
  });

export const adminGetSettings = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.parse(d))
  .handler(async ({ data }) => {
    const { db } = await ctx(data.initData);
    const { getSettings } = await import("./core.server");
    const { data: admins } = await db.from("admins").select("tg_user_id").order("created_at");
    const ids = (admins ?? []).map((a) => a.tg_user_id);
    const env = (process.env["ADMIN_TG_ID"] || "").split(/[,\s]+/).filter(Boolean).map(Number);
    const all = [...new Set([...env, ...ids])];
    const { data: names } = all.length ? await db.from("users").select("tg_user_id,name,username").in("tg_user_id", all) : { data: [] };
    return {
      settings: await getSettings(),
      admins: all.map((id) => {
        const n = names?.find((x) => x.tg_user_id === id);
        return { id, name: n?.name ?? null, username: n?.username ?? null, owner: env.includes(id) };
      }),
    };
  });

export const adminSaveSettings = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({
    settings: z.record(z.string(), z.union([z.number(), z.string().max(2000)])),
  }).parse(d))
  .handler(async ({ data }) => {
    const { db } = await ctx(data.initData);
    const allowed = ["welcome_bonus", "coin_rate", "daily_yield_pct", "min_claim_usdt", "gift_min", "gift_max", "referral_coins", "min_deposit_usd", "min_withdrawal_usdt", "free_withdrawal_cap", "withdrawal_fee_type", "withdrawal_fee_value", "ton_address", "memo_prefix", "join_channel", "join_payment_channel", "join_channels_extra", "withdrawals_open", "withdraw_bep20_open", "withdraw_gram_open", "autopay_enabled", "autopay_bep20", "autopay_gram", "autopay_max_usdt", "autopay_max_times", "autopay_min_deposit", "min_account_age_hours", "max_new_accounts_per_ip"];
    const rows = Object.entries(data.settings).filter(([k]) => allowed.includes(k)).map(([key, value]) => ({ key, value }));
    await db.from("app_settings").upsert(rows);
    const { invalidateSettingsCache } = await import("./core.server");
    invalidateSettingsCache();
    return { ok: true };
  });

export const adminBroadcast = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({
    target: z.string().max(20), text: z.string().min(1).max(4000),
    imageUrl: z.string().url().max(500).optional().or(z.literal("")),
    buttons: z.array(z.object({ label: z.string().min(1).max(64), url: z.string().url().max(500) })).max(10),
  }).parse(d))
  .handler(async ({ data }) => {
    const { db, admin } = await ctx(data.initData);
    const { tgApi } = await import("./telegram.server");
    let ids: number[] = [];
    if (data.target === "all") {
      const { data: rows } = await db.from("users").select("tg_user_id").limit(100000);
      ids = (rows ?? []).map((r) => r.tg_user_id);
    } else if (/^\d+$/.test(data.target)) ids = [Number(data.target)];
    else throw new Error("Target must be 'all' or a Telegram ID");
    const reply_markup = data.buttons.length ? { inline_keyboard: data.buttons.map((b) => [{ text: b.label, url: b.url }]) } : undefined;
    // Send in batches of 50; retry once on Telegram rate limit (429).
    const sendOne = async (chat_id: number): Promise<string | null> => {
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          if (data.imageUrl) await tgApi("sendPhoto", { chat_id, photo: data.imageUrl, caption: data.text, parse_mode: "HTML", reply_markup });
          else await tgApi("sendMessage", { chat_id, text: data.text, parse_mode: "HTML", reply_markup });
          return null;
        } catch (e) {
          const msg = (e as Error).message;
          const wait = /\[429\]/.test(msg) ? Number(msg.match(/retry after (\d+)/i)?.[1] ?? 2) : 0;
          if (!wait || attempt === 2) return msg.replace(/^Telegram \w+ failed /, "").slice(0, 160);
          await new Promise((r) => setTimeout(r, (wait + 1) * 1000));
        }
      }
      return "failed";
    };
    let sent = 0, failed = 0, blocked = 0, batches = 0;
    const errors: { id: number; error: string }[] = [];
    for (let i = 0; i < ids.length; i += 50) {
      batches++;
      const batch = ids.slice(i, i + 50);
      // 25 at a time keeps us under Telegram's ~30 msg/s limit.
      for (let j = 0; j < batch.length; j += 25) {
        const res = await Promise.all(batch.slice(j, j + 25).map(async (id) => ({ id, err: await sendOne(id) })));
        for (const r of res) {
          if (!r.err) { sent++; continue; }
          failed++;
          if (/403|blocked|deactivated|chat not found/i.test(r.err)) blocked++;
          if (errors.length < 200) errors.push({ id: r.id, error: r.err });
        }
        await new Promise((r) => setTimeout(r, 1000));
      }
    }
    await db.from("broadcasts").insert({ target: data.target, text: data.text, image_url: data.imageUrl || null, buttons: data.buttons, sent_count: sent, failed_count: failed, sent_by: admin.id });
    return { total: ids.length, sent, failed, blocked, batches, errors };
  });

export const adminSetupWebhook = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ origin: z.string().url() }).parse(d))
  .handler(async ({ data }) => {
    await ctx(data.initData);
    const { tgApi, webhookSecret } = await import("./telegram.server");
    const url = `${new URL(data.origin).origin}/api/public/telegram/webhook`;
    await tgApi("setWebhook", { url, secret_token: webhookSecret(), allowed_updates: ["message", "callback_query"] });
    return { url };
  });

/** Suspicious accounts, computed on read from existing data (nothing stored). */
export const adminSuspicious = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.parse(d))
  .handler(async ({ data }) => {
    const { db } = await ctx(data.initData);
    const s = await (await import("./core.server")).getSettings();
    const cap = Number(s.free_withdrawal_cap ?? 0.25);
    const since = new Date(Date.now() - 7 * 86400000).toISOString();
    const [{ data: users }, { data: wds }, { data: ips }] = await Promise.all([
      db.from("users").select("tg_user_id,name,username,referred_by,joined_at,total_deposit,referral_earnings_coins,usdt_balance").eq("is_banned", false).gte("joined_at", since).order("joined_at", { ascending: false }).limit(2000),
      db.from("withdrawals").select("user_id,amount,created_at").neq("status", "rejected").gte("created_at", since).limit(5000),
      db.from("ip_ban").select("user_id").limit(5000),
    ]);
    const flags = new Map<number, Set<string>>();
    const flag = (id: number, r: string) => { if (!flags.has(id)) flags.set(id, new Set()); flags.get(id)!.add(r); };
    const list = users ?? [];
    const flaggedIp = new Set((ips ?? []).map((r) => Number(r.user_id)));
    const byRef = new Map<number, number[]>();
    for (const u of list) {
      if (u.username === "no-username" && !Number(u.referral_earnings_coins) && !Number(u.total_deposit)) flag(u.tg_user_id, "no username, no activity");
      if (u.referred_by) { const a = byRef.get(u.referred_by) ?? []; a.push(new Date(u.joined_at).getTime()); byRef.set(u.referred_by, a); }
      if (flaggedIp.has(u.tg_user_id)) flag(u.tg_user_id, "flagged IP");
    }
    for (const u of list) {
      if (!u.referred_by) continue;
      const t = new Date(u.joined_at).getTime();
      const near = (byRef.get(u.referred_by) ?? []).filter((x) => Math.abs(x - t) < 120000).length;
      if (near >= 3) flag(u.tg_user_id, `burst of ${near} signups under same referrer`);
    }
    const joined = new Map(list.map((u) => [u.tg_user_id, new Date(u.joined_at).getTime()]));
    const sum = new Map<number, number>();
    for (const w of wds ?? []) {
      const j = joined.get(w.user_id);
      if (j && new Date(w.created_at).getTime() - j < 86400000) sum.set(w.user_id, (sum.get(w.user_id) ?? 0) + Number(w.amount));
    }
    for (const [id, a] of sum) if (a >= cap - 1e-9) flag(id, "hit free cap within 24h of joining");
    return list.filter((u) => flags.has(u.tg_user_id))
      .map((u) => ({ id: u.tg_user_id, name: u.name, username: u.username, joinedAt: u.joined_at, reasons: [...flags.get(u.tg_user_id)!], score: flags.get(u.tg_user_id)!.size }))
      .sort((a, b) => b.score - a.score).slice(0, 200);
  });

export const adminBulkBan = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ ids: z.array(z.number()).min(1).max(500), reason: z.string().max(200).optional() }).parse(d))
  .handler(async ({ data }) => {
    const { db } = await ctx(data.initData);
    const { isAdmin } = await import("./core.server");
    let banned = 0;
    for (const id of data.ids) {
      if (await isAdmin(id)) continue;
      const { error } = await db.rpc("ban_user", { p_user: id, p_reason: data.reason || "bot pattern", p_ip: "" });
      if (!error) banned++;
    }
    return { banned };
  });
