// GRAM (TON) USDT payout — same method as ton-pay.mjs: BIP39 seed → SLIP-10 m/44'/607'/0' → WalletV5R1, TEP-74 jetton transfer via TonCenter.
import { pbkdf2Sync } from "crypto";
import { getED25519MasterKeyFromSeed, deriveED25519HardenedKey, keyPairFromSeed } from "@ton/crypto";
import { WalletContractV5R1 } from "@ton/ton";
import { Address, Cell, beginCell, internal, external, storeMessage, SendMode } from "@ton/core";

const RPC = "https://toncenter.com/api/v2/jsonRPC";
const EXPECTED_WALLET = "UQClwv5NDfVBCgKvI3ngXTFR3KDClEIMtYGfv04AM9YZhiUz";
const USDT_MASTER = "EQCxE6mUtQJKFnGfaROTKOt1lZbDiiX1kCixRv7Nw2Id_sDs";
const MEMO = "OminixAiBot";
const MSG_VALUE = 30000000n, FORWARD_TON = 2000000n, MIN_TON = 40000000n;
const DECIMALS = 6;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function apiKey() {
  const k = process.env["PAY_TONCENTER_API"] || process.env["TON_CENTER_API"] || "";
  if (!k) throw new Error("GRAM payout API key is not configured");
  return k;
}

async function rpc(method: string, params: unknown): Promise<any> {
  const r = await fetch(RPC, { method: "POST", headers: { "Content-Type": "application/json", "X-API-Key": apiKey() }, body: JSON.stringify({ id: "1", jsonrpc: "2.0", method, params }) });
  const j = (await r.json()) as { ok?: boolean; result?: any; error?: string };
  if (!j.ok) throw new Error(`TonCenter: ${j.error || "rpc fail"}`);
  return j.result;
}
const stackNum = (e: any) => { if (!e || e[0] !== "num") throw new Error("Bad TON stack"); return BigInt(e[1]); };

async function wallet() {
  const phrase = (process.env["TON_WALLET_SECRET"] || "").trim();
  if (phrase.split(/\s+/).length < 12) throw new Error("GRAM payout wallet is not configured");
  let st = await getED25519MasterKeyFromSeed(pbkdf2Sync(phrase, "mnemonic", 2048, 64, "sha512"));
  for (const i of [44, 607, 0]) st = await deriveED25519HardenedKey(st, i);
  const kp = keyPairFromSeed(st.key);
  const w = WalletContractV5R1.create({ workchain: 0, publicKey: kp.publicKey });
  if (!w.address.equals(Address.parse(EXPECTED_WALLET))) throw new Error("GRAM payout wallet secret does not match the expected wallet");
  return { w, secretKey: kp.secretKey };
}

async function seqno(addr: Address) {
  return Number(stackNum((await rpc("runGetMethod", { address: addr.toString(), method: "seqno", stack: [] })).stack[0]));
}

/** Sends USDT on TON to `to`. Returns the message hash (or "" if TonCenter gave none). */
export async function sendUsdtTon(to: string, amount: number): Promise<string> {
  let dest: Address;
  try { dest = Address.parse(to.trim()); } catch { throw new Error("Invalid GRAM address"); }
  const value = BigInt(Math.floor(amount * 10 ** DECIMALS));
  if (value <= 0n) throw new Error("Amount is zero");
  const { w, secretKey } = await wallet();
  const owner = w.address;
  const res = await rpc("runGetMethod", { address: USDT_MASTER, method: "get_wallet_address", stack: [["tvm.Slice", beginCell().storeAddress(owner).endCell().toBoc().toString("base64")]] });
  const e = res.stack[0];
  if (!e || e[0] !== "cell") throw new Error("USDT jetton wallet not found");
  const jw = Cell.fromBoc(Buffer.from(e[1].bytes, "base64"))[0]!.beginParse().loadAddress();

  const ton = BigInt((await rpc("getAddressInformation", { address: owner.toString() })).balance);
  if (ton < MIN_TON) throw new Error(`Payout wallet needs at least 0.04 TON for fees (has ${Number(ton) / 1e9})`);
  let usdt = 0n;
  try { usdt = stackNum((await rpc("runGetMethod", { address: jw.toString(), method: "get_wallet_data", stack: [] })).stack[0]); } catch { usdt = 0n; }
  if (usdt < value) throw new Error(`Payout wallet low: ${Number(usdt) / 1e6} USDT, need ${amount}`);

  const comment = beginCell().storeUint(0, 32).storeStringTail(MEMO).endCell();
  const body = beginCell().storeUint(0x0f8a7ea5, 32).storeUint(0, 64).storeCoins(value).storeAddress(dest).storeAddress(owner)
    .storeBit(0).storeCoins(FORWARD_TON).storeBit(1).storeRef(comment).endCell();
  const sq = await seqno(owner);
  const signed = w.createTransfer({ seqno: sq, secretKey, messages: [internal({ to: jw, value: MSG_VALUE, body })], sendMode: SendMode.PAY_GAS_SEPARATELY });
  const extCell = beginCell().store(storeMessage(external({ to: owner, body: signed }))).endCell();
  // No init + zero import fee → this cell hash is the TEP-467 normalized message hash.
  const msgHash = extCell.hash().toString("hex");
  await rpc("sendBoc", { boc: extCell.toBoc().toString("base64") });
  for (let i = 0; i < 5; i++) { await sleep(3000); if ((await seqno(owner).catch(() => sq)) > sq) break; }
  return (await txHashByMessage(msgHash)) || "";
}

/** Real transaction hash (hex) for an external message, via TonCenter v3. "" if not found in time. */
async function txHashByMessage(msgHash: string): Promise<string> {
  for (let i = 0; i < 6; i++) {
    try {
      const r = await fetch(`https://toncenter.com/api/v3/transactionsByMessage?msg_hash=${msgHash}&direction=in&limit=1`, { headers: { "X-API-Key": apiKey() } });
      if (r.ok) {
        const j = (await r.json()) as { transactions?: { hash?: string }[] };
        const h = j.transactions?.[0]?.hash;
        if (h) return /^[0-9a-f]{64}$/i.test(h) ? h.toLowerCase() : Buffer.from(h, "base64").toString("hex");
      }
    } catch { /* retry */ }
    await sleep(2500);
  }
  return "";
}
