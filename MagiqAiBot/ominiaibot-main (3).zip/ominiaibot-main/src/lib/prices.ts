import { getPrices } from "@/lib/app.functions";

export type LivePrices = { values: Record<string, number>; updatedAt: number; stale: boolean };
const MAIN = ["BNB", "ETH", "GRAM"] as const; // TON is now GRAM

async function json(url: string) {
  const r = await fetch(url, { cache: "no-store" });
  if (!r.ok) throw new Error(`${r.status}`);
  return r.json();
}

/**
 * Live prices fetched from the user's own phone first (same method as price-ficher.js:
 * api.binance.com ticker/price), because Binance blocks cloud servers. Falls back to
 * Coinbase from the phone, then the app server.
 */
export async function livePrices(): Promise<LivePrices> {
  const values: Record<string, number> = {};
  try {
    const arr = await json(`https://api.binance.com/api/v3/ticker/price?symbols=${encodeURIComponent(JSON.stringify(MAIN.map((s) => `${s}USDT`)))}`);
    for (const s of MAIN) { const r = (arr as { symbol: string; price: string }[]).find((x) => x.symbol === `${s}USDT`); if (Number(r?.price) > 0) values[s] = Number(r!.price); }
  } catch { /* try next */ }
  await Promise.all(MAIN.filter((s) => !values[s]).map(async (s) => {
    try { const d = await json(`https://api.coinbase.com/v2/prices/${s}-USD/spot`); const v = Number(d?.data?.amount); if (v > 0) values[s] = v; } catch { /* next */ }
  }));
  if (MAIN.every((s) => values[s])) return { values, updatedAt: Date.now(), stale: false };
  const server = await getPrices().catch(() => null);
  if (server) return { ...server, values: { ...server.values, ...values } };
  if (Object.keys(values).length) return { values, updatedAt: Date.now(), stale: false };
  throw new Error("Live price is unavailable right now");
}
