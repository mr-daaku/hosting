import { HDNodeWallet } from "ethers";

function getMnemonic(): string {
  const m = process.env["MNEMONIC"];
  if (!m) throw new Error("MNEMONIC is not configured");
  return m.trim();
}

export function getEvmAddress(mnemonic: string, index: number): string {
  return HDNodeWallet.fromPhrase(mnemonic, undefined, `m/44'/60'/0'/0/${index}`).address;
}

// The slow part (seed from the secret words) runs once per worker; each address is then instant.
let evmBase: HDNodeWallet | null = null;
/** EVM (ETH/BNB) deposit address for a wallet index, generated on the spot from the secret words. */
export function evmAddressFor(index: number): string {
  if (!evmBase) evmBase = HDNodeWallet.fromPhrase(getMnemonic(), undefined, "m/44'/60'/0'/0");
  return evmBase.deriveChild(index).address;
}

export function deriveAll(index: number) {
  return { evm: evmAddressFor(index) };
}

/** Which wallet number owns this EVM address (0..max), or null. */
export function findWalletIndex(address: string, max: number): number | null {
  const a = address.toLowerCase();
  for (let i = 0; i <= max; i++) if (evmAddressFor(i).toLowerCase() === a) return i;
  return null;
}
