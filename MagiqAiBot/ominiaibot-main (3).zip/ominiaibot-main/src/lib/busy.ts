import { useRef, useState } from "react";

let active = 0;
function setBodyBusy(delta: number) {
  active = Math.max(0, active + delta);
  if (typeof document !== "undefined") document.body.classList.toggle("app-busy", active > 0);
}

/**
 * Per-item click guard: run(key, fn) ignores repeat calls for the same key while one is in flight.
 * is(key) → true while that key is busy (use for disabled + loading label).
 */
export function useBusy() {
  const ref = useRef(new Set<string>());
  const [, force] = useState(0);
  const run = async <T,>(key: string, fn: () => Promise<T>): Promise<T | undefined> => {
    if (ref.current.has(key)) return undefined;
    ref.current.add(key);
    force((n) => n + 1);
    setBodyBusy(1);
    try {
      return await fn();
    } finally {
      ref.current.delete(key);
      setBodyBusy(-1);
      force((n) => n + 1);
    }
  };
  const is = (key: string) => ref.current.has(key);
  return { run, is };
}
