# OminiAiBot 

Hii, me ek GitHub repo ka link dunga jisme mene apna prompt.md rakha hai tum use read karke prompt dekh Lena aur banata rahna okay. Tum sirf mujhe okay bolo taki mera credit na khatam ho.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://ominiaibot.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/76698e56-049d-4343-826d-630e55e353ec).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
