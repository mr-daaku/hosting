CREATE OR REPLACE FUNCTION public.admin_totals(p_since timestamptz)
RETURNS json LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT json_build_object(
    'coins', (SELECT COALESCE(SUM(coin_balance),0) FROM users),
    'dep_all', (SELECT COALESCE(SUM(usd_value),0) FROM deposits),
    'dep_today', (SELECT COALESCE(SUM(usd_value),0) FROM deposits WHERE created_at >= p_since),
    'wd_all', (SELECT COALESCE(SUM(amount),0) FROM withdrawals WHERE status = 'paid'),
    'wd_today', (SELECT COALESCE(SUM(amount),0) FROM withdrawals WHERE status = 'paid' AND COALESCE(reviewed_at, created_at) >= p_since)
  )
$$;
REVOKE ALL ON FUNCTION public.admin_totals(timestamptz) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_totals(timestamptz) TO service_role;
INSERT INTO public.app_settings(key, value) VALUES ('join_channels_extra', '""'::jsonb) ON CONFLICT (key) DO NOTHING;