DROP FUNCTION IF EXISTS public.claim_referral(bigint, numeric);

-- Balance change: one atomic update, no history rows.
CREATE OR REPLACE FUNCTION public.apply_balance(p_user bigint, p_kind text, p_coin numeric, p_usdt numeric, p_note text DEFAULT NULL::text, p_ref text DEFAULT NULL::text)
 RETURNS users
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
declare r public.users;
begin
  update users set coin_balance = coin_balance + p_coin, usdt_balance = usdt_balance + p_usdt
  where tg_user_id = p_user returning * into r;
  if r is null then raise exception 'user not found'; end if;
  return r;
end $function$;

-- Deposit credit: dedupe on (tx_hash, asset), one update for balance + total. No referral % bonus.
CREATE OR REPLACE FUNCTION public.credit_deposit(p_user bigint, p_chain text, p_asset text, p_tx text, p_amount numeric, p_usd numeric, p_rate numeric, p_ref_pct numeric)
 RETURNS numeric
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
declare v_coins numeric := round(p_usd * p_rate, 4); v_id uuid;
begin
  insert into deposits(user_id, chain, asset, tx_hash, amount, usd_value, coins_credited)
  values (p_user, p_chain, p_asset, p_tx, p_amount, p_usd, v_coins)
  on conflict (tx_hash, asset) do nothing returning id into v_id;
  if v_id is null then return null; end if;
  update users set total_deposit = total_deposit + p_usd, coin_balance = coin_balance + v_coins where tg_user_id = p_user;
  return v_coins;
end $function$;

-- Referral reward in one atomic statement (coins + referral total + 1 gift box).
CREATE OR REPLACE FUNCTION public.referral_reward(p_referrer bigint, p_coins numeric)
 RETURNS void
 LANGUAGE sql
 SET search_path TO 'public'
AS $function$
  update users set coin_balance = coin_balance + p_coins,
    referral_earnings_coins = referral_earnings_coins + p_coins,
    gift_boxes = gift_boxes + 1
  where tg_user_id = p_referrer and not is_banned;
$function$;

-- App open: user row + friends count + withdrawn/pending sum in ONE call, aggregated in SQL.
CREATE OR REPLACE FUNCTION public.boot_user(p_user bigint)
 RETURNS json
 LANGUAGE sql
 STABLE
 SET search_path TO 'public'
AS $function$
  select json_build_object(
    'me', to_json(u),
    'invited', (select count(*) from referrals r where r.referrer_id = p_user),
    'withdrawn_or_pending', (select coalesce(sum(w.amount), 0) from withdrawals w where w.user_id = p_user and w.status <> 'rejected')
  )
  from users u where u.tg_user_id = p_user;
$function$;

REVOKE ALL ON FUNCTION public.referral_reward(bigint, numeric) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.boot_user(bigint) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.referral_reward(bigint, numeric) TO service_role;
GRANT EXECUTE ON FUNCTION public.boot_user(bigint) TO service_role;

-- Retired (kept only because dropping is blocked; the app never reads them).
COMMENT ON COLUMN public.users.device_fingerprint IS 'DEPRECATED: device checks removed (Prompt19)';
COMMENT ON COLUMN public.users.solana_address IS 'DEPRECATED: only EVM + GRAM deposits';
COMMENT ON COLUMN public.users.tron_address IS 'DEPRECATED: only EVM + GRAM deposits';
COMMENT ON COLUMN public.users.referral_unclaimed_coins IS 'DEPRECATED: referral coins go straight to coin_balance';
COMMENT ON COLUMN public.users.ton_memo IS 'DEPRECATED: memo = memo_prefix + tg_user_id, computed';
COMMENT ON TABLE public.transactions IS 'DEPRECATED: no transaction history (Prompt19); apply_balance no longer writes here';

-- Indexes matching hot queries.
CREATE INDEX IF NOT EXISTS withdrawals_user_id_status_idx ON public.withdrawals (user_id, status);
CREATE INDEX IF NOT EXISTS users_evm_address_idx ON public.users (evm_address);

-- One slow query can never hold the database hostage.
ALTER ROLE service_role SET statement_timeout = '8s';
ALTER ROLE authenticated SET statement_timeout = '8s';
ALTER ROLE anon SET statement_timeout = '5s';