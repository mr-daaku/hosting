alter table public.users add column if not exists admin_frozen numeric not null default 0;
alter table public.users add column if not exists freeze_reason text;
insert into public.app_settings(key, value) values
 ('min_deposit_usd', '0.1'::jsonb), ('min_withdrawal_usdt', '0.1'::jsonb), ('free_withdrawal_cap', '0.25'::jsonb), ('daily_yield_pct', '0.02'::jsonb)
on conflict (key) do update set value = excluded.value;
delete from public.app_settings where key = 'gift_cooldown_hours';