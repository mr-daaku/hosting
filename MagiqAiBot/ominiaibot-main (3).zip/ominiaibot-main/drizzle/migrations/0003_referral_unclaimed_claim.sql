ALTER TABLE public.users ADD COLUMN IF NOT EXISTS referral_unclaimed_coins numeric NOT NULL DEFAULT 0;

CREATE OR REPLACE FUNCTION public.credit_deposit(p_user bigint, p_chain text, p_asset text, p_tx text, p_amount numeric, p_usd numeric, p_rate numeric, p_ref_pct numeric)
RETURNS numeric LANGUAGE plpgsql SET search_path = public AS $$
declare v_coins numeric := round(p_usd * p_rate, 4); v_id uuid; v_ref bigint; v_banned boolean; v_bonus numeric;
begin
  insert into deposits(user_id, chain, asset, tx_hash, amount, usd_value, coins_credited)
  values (p_user, p_chain, p_asset, p_tx, p_amount, p_usd, v_coins)
  on conflict (tx_hash, asset) do nothing returning id into v_id;
  if v_id is null then return null; end if;
  update users set total_deposit = total_deposit + p_usd where tg_user_id = p_user;
  perform apply_balance(p_user, 'deposit', v_coins, 0, p_asset || ' on ' || p_chain, p_tx);
  select referred_by, is_banned into v_ref, v_banned from users where tg_user_id = p_user;
  if v_ref is not null and not v_banned and p_ref_pct > 0 then
    v_bonus := round(v_coins * p_ref_pct / 100, 4);
    update users set referral_earnings_coins = referral_earnings_coins + v_bonus,
      referral_unclaimed_coins = referral_unclaimed_coins + v_bonus where tg_user_id = v_ref;
    update referrals set total_deposit_bonus_earned = total_deposit_bonus_earned + v_bonus where referred_id = p_user;
  end if;
  return v_coins;
end $$;

CREATE OR REPLACE FUNCTION public.claim_referral(p_user bigint, p_rate numeric)
RETURNS numeric LANGUAGE plpgsql SET search_path = public AS $$
declare v_coins numeric; v_usdt numeric;
begin
  update users set referral_unclaimed_coins = 0 where tg_user_id = p_user and referral_unclaimed_coins > 0
  returning referral_unclaimed_coins into v_coins;
  select coalesce(sum(0),0) into v_usdt; -- placeholder
  return null;
end $$;

CREATE OR REPLACE FUNCTION public.claim_referral(p_user bigint, p_rate numeric)
RETURNS numeric LANGUAGE plpgsql SET search_path = public AS $$
declare v_coins numeric; v_usdt numeric;
begin
  select referral_unclaimed_coins into v_coins from users where tg_user_id = p_user for update;
  if v_coins is null or v_coins <= 0 or p_rate <= 0 then return 0; end if;
  v_usdt := round(v_coins / p_rate, 6);
  update users set referral_unclaimed_coins = 0 where tg_user_id = p_user;
  perform apply_balance(p_user, 'referral_claim', 0, v_usdt, 'Referral income claimed');
  return v_usdt;
end $$;

REVOKE ALL ON FUNCTION public.credit_deposit FROM public, anon, authenticated;
REVOKE ALL ON FUNCTION public.claim_referral FROM public, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.credit_deposit TO service_role;
GRANT EXECUTE ON FUNCTION public.claim_referral TO service_role;