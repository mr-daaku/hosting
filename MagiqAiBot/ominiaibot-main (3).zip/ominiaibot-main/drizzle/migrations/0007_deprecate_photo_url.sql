COMMENT ON COLUMN public.users.photo_url IS 'DEPRECATED: photos are no longer saved (Prompt24)';
UPDATE public.users SET photo_url = NULL WHERE photo_url IS NOT NULL;