ALTER TABLE public.withdrawals DROP CONSTRAINT IF EXISTS withdrawals_status_check;
ALTER TABLE public.withdrawals ADD CONSTRAINT withdrawals_status_check CHECK (status IN ('pending','processing','paid','rejected'));
UPDATE public.users SET photo_url = NULL WHERE photo_url IS NOT NULL;