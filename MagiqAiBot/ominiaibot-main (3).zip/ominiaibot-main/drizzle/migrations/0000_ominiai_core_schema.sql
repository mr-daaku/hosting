create sequence public.wallet_index_seq minvalue 0 start 0;

create table public.users (
  tg_user_id bigint primary key,
  wallet_index int not null unique default nextval('public.wallet_index_seq'),
  name text not null default '',
  username text not null default 'no-username',
  photo_url text,
  device_fingerprint text,
  coin_balance numeric not null default 0 check (coin_balance >= 0),
  usdt_balance numeric not null default 0 check (usdt_balance >= 0),
  usdt_frozen numeric not null default 0 check (usdt_frozen >= 0),
  total_deposit numeric not null default 0,
  total_withdrawal numeric not null default 0,
  referral_earnings_coins numeric not null default 0,
  joined_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  last_yield_at timestamptz not null default now(),
  last_gift_at timestamptz,
  is_banned boolean not null default false,
  ban_reason text,
  referred_by bigint references public.users(tg_user_id),
  evm_address text, tron_address text, solana_address text, ton_memo text
);
create table public.wallets (
  id uuid primary key default gen_random_uuid(),
  user_id bigint not null references public.users(tg_user_id) on delete cascade,
  chain text not null, address text not null, memo text, idx int not null,
  unique (user_id, chain)
);
create table public.device_fingerprints (
  fingerprint text not null,
  user_id bigint not null references public.users(tg_user_id) on delete cascade,
  first_seen_at timestamptz not null default now(),
  primary key (fingerprint, user_id)
);
create table public.deposits (
  id uuid primary key default gen_random_uuid(),
  user_id bigint not null references public.users(tg_user_id),
  chain text not null, asset text not null, tx_hash text not null,
  amount numeric not null, usd_value numeric not null, coins_credited numeric not null,
  status text not null default 'confirmed', created_at timestamptz not null default now(),
  unique (tx_hash, asset)
);
create table public.withdrawals (
  id uuid primary key default gen_random_uuid(),
  user_id bigint not null references public.users(tg_user_id),
  chain text not null, asset text not null, address text not null,
  amount numeric not null, fee numeric not null default 0,
  status text not null default 'pending' check (status in ('pending','paid','rejected')),
  tx_hash text, reject_reason text, refunded boolean not null default false,
  created_at timestamptz not null default now(), reviewed_at timestamptz, reviewed_by bigint
);
create table public.referrals (
  referred_id bigint primary key references public.users(tg_user_id),
  referrer_id bigint not null references public.users(tg_user_id),
  signup_bonus_paid boolean not null default false,
  total_deposit_bonus_earned numeric not null default 0,
  created_at timestamptz not null default now()
);
create table public.transactions (
  id uuid primary key default gen_random_uuid(),
  user_id bigint not null references public.users(tg_user_id),
  kind text not null, coin_delta numeric not null default 0, usdt_delta numeric not null default 0,
  note text, ref_id text, created_at timestamptz not null default now()
);
create table public.app_settings (key text primary key, value jsonb not null);
create table public.admins (tg_user_id bigint primary key, created_at timestamptz not null default now());
create table public.broadcasts (
  id uuid primary key default gen_random_uuid(), target text not null, text text not null,
  image_url text, buttons jsonb, sent_count int not null default 0, failed_count int not null default 0,
  sent_by bigint, created_at timestamptz not null default now()
);
create index on public.transactions (user_id, created_at desc);
create index on public.deposits (user_id, created_at desc);
create index on public.withdrawals (status, created_at desc);
create index on public.referrals (referrer_id);
create index on public.device_fingerprints (fingerprint);

do $$ declare t text; begin
  foreach t in array array['users','wallets','device_fingerprints','deposits','withdrawals','referrals','transactions','app_settings','admins','broadcasts'] loop
    execute format('grant all on public.%I to service_role', t);
    execute format('alter table public.%I enable row level security', t);
  end loop;
end $$;
grant usage, select on sequence public.wallet_index_seq to service_role;

create or replace function public.apply_balance(p_user bigint, p_kind text, p_coin numeric, p_usdt numeric, p_note text default null, p_ref text default null)
returns public.users language plpgsql set search_path = public as $$
declare r public.users;
begin
  update users set coin_balance = coin_balance + p_coin, usdt_balance = usdt_balance + p_usdt
  where tg_user_id = p_user returning * into r;
  if r is null then raise exception 'user not found'; end if;
  insert into transactions(user_id, kind, coin_delta, usdt_delta, note, ref_id) values (p_user, p_kind, p_coin, p_usdt, p_note, p_ref);
  return r;
end $$;

create or replace function public.credit_deposit(p_user bigint, p_chain text, p_asset text, p_tx text, p_amount numeric, p_usd numeric, p_rate numeric, p_ref_pct numeric)
returns numeric language plpgsql set search_path = public as $$
declare v_coins numeric := round(p_usd * p_rate, 4); v_id uuid; v_ref bigint; v_banned boolean; v_bonus numeric;
begin
  insert into deposits(user_id, chain, asset, tx_hash, amount, usd_value, coins_credited)
  values (p_user, p_chain, p_asset, p_tx, p_amount, p_usd, v_coins)
  on conflict (tx_hash, asset) do nothing returning id into v_id;
  if v_id is null then return null; end if;
  update users set total_deposit = total_deposit + p_usd where tg_user_id = p_user;
  perform apply_balance(p_user, 'deposit', v_coins, 0, p_asset || ' on ' || p_chain, p_tx);
  select referred_by, is_banned into v_ref, v_banned from users where tg_user_id = p_user;
  if v_ref is not null and not v_banned and p_ref_pct > 0 then
    v_bonus := round(v_coins * p_ref_pct / 100, 4);
    perform apply_balance(v_ref, 'referral_deposit_bonus', v_bonus, 0, 'Friend deposit ' || p_user, p_tx);
    update users set referral_earnings_coins = referral_earnings_coins + v_bonus where tg_user_id = v_ref;
    update referrals set total_deposit_bonus_earned = total_deposit_bonus_earned + v_bonus where referred_id = p_user;
  end if;
  return v_coins;
end $$;

revoke all on function public.apply_balance from public, anon, authenticated;
revoke all on function public.credit_deposit from public, anon, authenticated;
grant execute on function public.apply_balance to service_role;
grant execute on function public.credit_deposit to service_role;

insert into public.app_settings(key, value) values
 ('welcome_bonus', '100'), ('coin_rate', '100'), ('daily_yield_pct', '0.02'),
 ('gift_min', '1'), ('gift_max', '10'), ('gift_cooldown_hours', '24'),
 ('referral_coins', '10'), ('referral_deposit_pct', '5'),
 ('min_deposit_usd', '1'), ('min_withdrawal_usdt', '1'),
 ('withdrawal_fee_type', '"flat"'), ('withdrawal_fee_value', '0'),
 ('ton_address', '"UQCVxhjBVJQ7ufjD1lLSZW967R1DrFvFuOtVhsECnU_lqArV"'), ('memo_prefix', '"OMA-"');