CREATE OR REPLACE FUNCTION public.credit_deposit(p_user bigint, p_chain text, p_asset text, p_tx text, p_amount numeric, p_usd numeric, p_rate numeric, p_ref_pct numeric)
 RETURNS numeric LANGUAGE plpgsql SET search_path TO 'public'
AS $function$
declare v_coins numeric := round(p_usd * p_rate, 4); v_id uuid; v_ref bigint; v_banned boolean; v_rbanned boolean; v_bonus numeric;
begin
  insert into deposits(user_id, chain, asset, tx_hash, amount, usd_value, coins_credited)
  values (p_user, p_chain, p_asset, p_tx, p_amount, p_usd, v_coins)
  on conflict (tx_hash, asset) do nothing returning id into v_id;
  if v_id is null then return null; end if;
  update users set total_deposit = total_deposit + p_usd where tg_user_id = p_user;
  perform apply_balance(p_user, 'deposit', v_coins, 0, p_asset || ' on ' || p_chain, p_tx);
  select referred_by, is_banned into v_ref, v_banned from users where tg_user_id = p_user;
  if v_ref is not null and not v_banned and p_ref_pct > 0 then
    select is_banned into v_rbanned from users where tg_user_id = v_ref;
    if not coalesce(v_rbanned, true) then
      v_bonus := round(v_coins * p_ref_pct / 100, 4);
      perform apply_balance(v_ref, 'referral_deposit_bonus', v_bonus, 0, 'Friend deposit bonus', p_tx);
      update users set referral_earnings_coins = referral_earnings_coins + v_bonus where tg_user_id = v_ref;
      update referrals set total_deposit_bonus_earned = total_deposit_bonus_earned + v_bonus where referred_id = p_user;
    end if;
  end if;
  return v_coins;
end $function$;

-- Move any unclaimed referral coins into the coin balance, then clear.
DO $$ DECLARE r record; BEGIN
  FOR r IN SELECT tg_user_id, referral_unclaimed_coins FROM public.users WHERE referral_unclaimed_coins > 0 LOOP
    PERFORM public.apply_balance(r.tg_user_id, 'referral_bonus', r.referral_unclaimed_coins, 0, 'Referral income moved to coins', NULL);
  END LOOP;
  UPDATE public.users SET referral_unclaimed_coins = 0 WHERE referral_unclaimed_coins > 0;
END $$;

INSERT INTO public.app_settings(key, value) VALUES ('allow_multi_accounts', '"on"') ON CONFLICT (key) DO NOTHING;