CREATE TABLE public.device_ban (
  device_fingerprint text PRIMARY KEY,
  user_id bigint NOT NULL,
  ban boolean NOT NULL DEFAULT false
);
GRANT ALL ON public.device_ban TO service_role;
ALTER TABLE public.device_ban ENABLE ROW LEVEL SECURITY;

-- First account on a device owns the fingerprint; any other account on it is banned. Returns true when banned.
CREATE OR REPLACE FUNCTION public.check_device(p_user bigint, p_fp text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE owner bigint;
BEGIN
  INSERT INTO device_ban(device_fingerprint, user_id) VALUES (p_fp, p_user)
  ON CONFLICT (device_fingerprint) DO NOTHING;
  SELECT user_id INTO owner FROM device_ban WHERE device_fingerprint = p_fp;
  IF owner IS DISTINCT FROM p_user THEN
    UPDATE users SET is_banned = true, ban_reason = 'duplicate device' WHERE tg_user_id = p_user AND NOT is_banned;
    RETURN true;
  END IF;
  RETURN false;
END $$;
REVOKE ALL ON FUNCTION public.check_device(bigint, text) FROM public, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.check_device(bigint, text) TO service_role;