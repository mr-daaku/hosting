CREATE TABLE IF NOT EXISTS public.ip_ban (
  ip text PRIMARY KEY,
  banned boolean NOT NULL DEFAULT false,
  user_id bigint,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.ip_ban TO service_role;
ALTER TABLE public.ip_ban ENABLE ROW LEVEL SECURITY;

-- Bounded rate limit counters: one row per key, overwritten each window.
CREATE TABLE IF NOT EXISTS public.rate_limits (
  key text PRIMARY KEY,
  count int NOT NULL DEFAULT 0,
  window_start timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.rate_limits TO service_role;
ALTER TABLE public.rate_limits ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.rate_hit(p_key text, p_max int, p_window_sec int)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE c int;
BEGIN
  INSERT INTO rate_limits(key, count, window_start) VALUES (p_key, 1, now())
  ON CONFLICT (key) DO UPDATE SET
    count = CASE WHEN rate_limits.window_start < now() - make_interval(secs => p_window_sec) THEN 1 ELSE rate_limits.count + 1 END,
    window_start = CASE WHEN rate_limits.window_start < now() - make_interval(secs => p_window_sec) THEN now() ELSE rate_limits.window_start END
  RETURNING count INTO c;
  RETURN c <= p_max;
END $$;
REVOKE ALL ON FUNCTION public.rate_hit(text, int, int) FROM public, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.rate_hit(text, int, int) TO service_role;

-- Ban + auto-reject pending withdrawals with refund (one place).
CREATE OR REPLACE FUNCTION public.ban_user(p_user bigint, p_reason text, p_ip text DEFAULT NULL)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE r record;
BEGIN
  UPDATE users SET is_banned = true, ban_reason = p_reason WHERE tg_user_id = p_user AND NOT is_banned;
  FOR r IN UPDATE withdrawals SET status = 'rejected', reject_reason = 'banned account', refunded = true, reviewed_at = now()
           WHERE user_id = p_user AND status = 'pending' RETURNING amount LOOP
    UPDATE users SET usdt_balance = usdt_balance + r.amount, usdt_frozen = greatest(0, usdt_frozen - r.amount) WHERE tg_user_id = p_user;
  END LOOP;
  IF p_ip IS NOT NULL AND p_ip <> '' THEN
    INSERT INTO ip_ban(ip, banned, user_id, note) VALUES (p_ip, false, p_user, p_reason) ON CONFLICT (ip) DO NOTHING;
  END IF;
END $$;
REVOKE ALL ON FUNCTION public.ban_user(bigint, text, text) FROM public, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.ban_user(bigint, text, text) TO service_role;

-- Device + IP check in one round trip. Returns true when the user is (now) banned.
CREATE OR REPLACE FUNCTION public.check_device_ip(p_user bigint, p_fp text, p_ip text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE owner bigint;
BEGIN
  IF p_ip IS NOT NULL AND EXISTS (SELECT 1 FROM ip_ban WHERE ip = p_ip AND banned) THEN
    PERFORM ban_user(p_user, 'banned ip', NULL);
    RETURN true;
  END IF;
  INSERT INTO device_ban(device_fingerprint, user_id) VALUES (p_fp, p_user) ON CONFLICT (device_fingerprint) DO NOTHING;
  SELECT user_id INTO owner FROM device_ban WHERE device_fingerprint = p_fp;
  IF owner IS DISTINCT FROM p_user THEN
    PERFORM ban_user(p_user, 'duplicate device', p_ip);
    RETURN true;
  END IF;
  RETURN false;
END $$;
REVOKE ALL ON FUNCTION public.check_device_ip(bigint, text, text) FROM public, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.check_device_ip(bigint, text, text) TO service_role;

-- Withdrawal hold: locks the user row so parallel requests can never double-debit.
CREATE OR REPLACE FUNCTION public.withdraw_hold(p_user bigint, p_chain text, p_asset text, p_address text, p_amount numeric, p_fee numeric, p_free_cap numeric, p_needs_cap boolean)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE u users; v_id uuid; used numeric;
BEGIN
  SELECT * INTO u FROM users WHERE tg_user_id = p_user FOR UPDATE;
  IF u IS NULL OR u.is_banned THEN RAISE EXCEPTION 'Account restricted'; END IF;
  IF EXISTS (SELECT 1 FROM withdrawals WHERE user_id = p_user AND status <> 'rejected' AND created_at > now() - interval '24 hours') THEN
    RAISE EXCEPTION 'You can withdraw once every 24 hours.';
  END IF;
  IF u.usdt_balance - u.admin_frozen < p_amount - 1e-9 THEN RAISE EXCEPTION 'Not enough balance'; END IF;
  IF p_needs_cap THEN
    SELECT coalesce(sum(amount), 0) INTO used FROM withdrawals WHERE user_id = p_user AND status <> 'rejected';
    IF used + p_amount > p_free_cap + 1e-9 THEN RAISE EXCEPTION 'Free withdrawal limit reached. Please make a deposit first.'; END IF;
  END IF;
  INSERT INTO withdrawals(user_id, chain, asset, address, amount, fee) VALUES (p_user, p_chain, p_asset, p_address, p_amount, p_fee) RETURNING id INTO v_id;
  UPDATE users SET usdt_balance = usdt_balance - p_amount, usdt_frozen = usdt_frozen + p_amount WHERE tg_user_id = p_user;
  RETURN v_id;
END $$;
REVOKE ALL ON FUNCTION public.withdraw_hold(bigint, text, text, text, numeric, numeric, numeric, boolean) FROM public, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.withdraw_hold(bigint, text, text, text, numeric, numeric, numeric, boolean) TO service_role;

INSERT INTO public.app_settings(key, value) VALUES ('min_account_age_hours', '12'), ('max_new_accounts_per_ip', '5') ON CONFLICT (key) DO NOTHING;