<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->
- Live prices load in the browser first (Binance/CoinGecko block our cloud server with 451/403); server crediting falls back to Coinbase then OKX.

- GRAM (ex-TON) deposits: compare addresses in raw "wc:hex" form (TonCenter returns EQ…, settings hold UQ…); USDT-GRAM tx key = trace id hex (same as TonAPI event_id) so TonCenter v3 and TonAPI fallback never double-credit.

- Deposit addresses are never read from a wallets table: EVM = derive from users.wallet_index (cached m/44'/60'/0'/0 base node, deriveChild) via getDepositAddress; GRAM = fixed settings address + memo `memo_prefix + tg id`. Why: instant, no per-user wallet rows.
- App open is one request: getMe calls bootstrapUser itself (no separate bootstrap call). Why: halves round trips on open.
- No transaction history, no device fingerprints, no multi-account bans, no referral deposit %; tables transactions/wallets/device_fingerprints are retired (drop is blocked, so they stay empty + commented DEPRECATED). Why: Prompt19.

- Prompt links: when the user sends just "Hii", open the next prompt file (last was promptN → read promptN+1 at https://github.com/mr-daaku/hosting/blob/main/OminiAiBot/); if missing, read the highest-numbered prompt in that folder. Why: user's request (Prompt20).
- /datas is a temporary owner-only CSV export (password = BOT_TOKEN); user will delete it later. Why: backup data while DB is unstable.

- App open reads the DB once: getMe → boot_user RPC (user row + invited count + withdrawn/pending sum in SQL); settings/admin list are cached per worker. Why: minimum DB load (Prompt21).
- Client keeps last getMe result in localStorage (omini-me-cache) and seeds it as stale on open. Why: instant open, never blank when server is down.
