# Roadmap
- [x] Prompt4: min claim, compact claim row, top spacing, cached rates, EN/RU/ZH/AR, icon, badge hide
- [x] Prompt5: NodeReal/TonCenter deposit scanning, channels
- [x] Prompt6: min deposit 0.01, below-minimum deposits recorded + shown, paid withdrawals posted to Payment Channel
- [x] Prompt7: deposit credit fix (price feed 403) + admin Check Deposit tab
- [x] Prompt8: Binance price + cache, join popup only if not joined, admin withdraw stats + freeze, history filters
- [x] Prompt10: live price from phone (Binance) + server fallback Coinbase/OKX, /api/public/prices-check
- [x] Prompt11: TON→GRAM rename + GRAMUSDT price, GRAM/USDT-GRAM deposit scan fix, native min in $, withdraw request bot message, admin frozen list + unfreeze, wallet index in deposits
- [x] Prompt13: refer claim, no fingerprint, EVM+GRAM only, online removed, less DB load, broadcast 50-batch + result
- [ ] Real Telegram test of deposits and channel post (needs user's device/account)

- [x] Prompt15: referral coins direct, multi-account toggle + ban, 24h withdraw, BEP20 autopay via bot buttons, /me summary
- [x] Prompt16: /start sirf welcome, short withdraw alert, admin Auto pay, newer-account ban, faster open
- [ ] Re-run Admin → Settings "Setup webhook" after publish (button taps)
- [x] Prompt17: faster open, button guards, /me removed
- [x] Prompt18 (code part): one-request app open, Retry on error screen, no missing DB function call
- [x] Prompt19 (code part): instant deposit addresses, no history/device/wallet tables used, multi-account ban removed, 5% deposit bonus removed, admin delete paid/rejected withdrawals
- [x] Prompt19 DB part: apply_balance no history, credit_deposit no referral %, retired tables/columns marked DEPRECATED + emptied, retired settings removed
- [x] Prompt21: DB restarted (data intact: 11,855 users; recovered 1000 users all present), boot_user one-call open, atomic referral_reward, cached admin list, phone-side last-data cache, join check remembered 24h, query defaults, indexes, 8s query timeout, /api/public/health
- [ ] Publish
