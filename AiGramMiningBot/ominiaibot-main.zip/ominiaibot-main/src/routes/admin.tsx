import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { ArrowLeft, Search, Plus, Trash2 } from "lucide-react";
import { Shell, CoinImg, card } from "@/components/app/Shell";
import { useMe, useTg } from "@/lib/tg";
import { useBusy } from "@/lib/busy";
import { CHAINS, chainById, LOGO, fmt } from "@/lib/assets";
import {
  adminDashboard, adminSearchUsers, adminGetUser, adminUpdateUser, adminWithdrawals, adminReviewWithdrawal, adminFreezeWithdrawal,
  adminDeposits, adminFrozenUsers, adminUnfreeze, adminInspectAddress, adminGetSettings, adminSaveSettings, adminBroadcast, adminSetupWebhook, adminDeleteWithdrawals,
  adminManualDeposit, adminAddAdmin, adminRemoveAdmin,
} from "@/lib/admin.functions";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin panel — OminiAi" },
      { name: "description", content: "Manage OminiAi users, deposits, withdrawals, broadcasts and settings." },
      { property: "og:title", content: "Admin panel — OminiAi" },
      { property: "og:description", content: "OminiAi administration." },
      { name: "robots", content: "noindex" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => <Shell hideNav><Admin /></Shell>,
});

const TABS = ["Dashboard", "Users", "Withdrawals", "Frozen", "Deposits", "Check Deposit", "Broadcast", "Settings"] as const;
const input = "w-full rounded-xl border border-border bg-muted px-3 py-2 text-sm outline-none focus:border-primary";
const btn = "rounded-xl px-4 py-2 text-sm font-bold disabled:opacity-50";

function useInit() { return useTg().initData; }
function err(e: unknown) { toast.error((e as Error).message); }

function Admin() {
  const { data } = useMe();
  const [tab, setTab] = useState<(typeof TABS)[number]>("Dashboard");
  if (!data) return null;
  if (!data.isAdmin) return <p className="mt-20 text-center text-muted-foreground">You do not have admin access.</p>;
  return (
    <div>
      <div className="mb-3 flex items-center gap-3">
        <Link to="/" aria-label="Back"><ArrowLeft className="h-5 w-5" /></Link>
        <h1 className="text-2xl font-bold">Admin</h1>
      </div>
      <div className="-mx-4 mb-4 flex gap-2 overflow-x-auto px-4 pb-1">
        {TABS.map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold ${tab === t ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>{t}</button>
        ))}
      </div>
      {tab === "Dashboard" && <Dashboard />}
      {tab === "Users" && <Users />}
      {tab === "Withdrawals" && <Withdrawals />}
      {tab === "Frozen" && <Frozen />}
      {tab === "Deposits" && <Deposits />}
      {tab === "Check Deposit" && <CheckDeposit />}
      {tab === "Broadcast" && <Broadcast />}
      {tab === "Settings" && <SettingsTab />}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: ReactNode }) {
  return <div className={card}><p className="text-xs text-muted-foreground">{label}</p><p className="mt-1 font-display text-xl font-bold">{value}</p></div>;
}

function Dashboard() {
  const initData = useInit();
  const q = useQuery({ queryKey: ["adm-dash"], queryFn: () => adminDashboard({ data: { initData } }) });
  if (q.isLoading) return <p className="text-muted-foreground">Loading…</p>;
  if (q.error) return <p className="text-destructive">{(q.error as Error).message}</p>;
  const d = q.data!;
  return (
    <div className="grid grid-cols-2 gap-3">
      <Stat label="Total users" value={d.users.toLocaleString()} />
      <Stat label="New today" value={d.today.toLocaleString()} />
      <Stat label="Banned" value={d.banned.toLocaleString()} />
      <Stat label="Total deposits" value={`$${fmt(d.deposits)}`} />
      <Stat label="Total withdrawals" value={`$${fmt(d.withdrawals)}`} />
      <Stat label="Coins in circulation" value={<span className="flex items-center gap-1"><CoinImg size={18} />{fmt(d.coins, 0)}</span>} />
      <Stat label="Pending withdrawals" value={<span className={d.pending ? "text-gold" : ""}>{d.pending}</span>} />
    </div>
  );
}

function Users() {
  const initData = useInit();
  const [q, setQ] = useState("");
  const [term, setTerm] = useState("");
  const [sel, setSel] = useState<number | null>(null);
  const list = useQuery({ queryKey: ["adm-users", term], queryFn: () => adminSearchUsers({ data: { initData, q: term } }), enabled: !!term.trim() });
  if (sel) return <UserDetail id={sel} onBack={() => setSel(null)} />;
  return (
    <div className="space-y-3">
      <form onSubmit={(e) => { e.preventDefault(); setTerm(q.trim()); }} className="flex gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Telegram ID, username or name" className={input} />
        <button className={`${btn} bg-primary text-primary-foreground`} aria-label="Search"><Search className="h-4 w-4" /></button>
      </form>
      {!term && <p className="text-sm text-muted-foreground">Search for a user to see their details.</p>}
      {term && list.data && !list.data.length && <p className="text-sm text-muted-foreground">No users found.</p>}
      {(list.data ?? []).map((u) => (
        <button key={u.tg_user_id} onClick={() => setSel(u.tg_user_id)} className={`${card} flex w-full items-center justify-between py-3 text-left`}>
          <div><p className="font-semibold">{u.name} {u.is_banned && <span className="text-xs text-destructive">banned</span>}</p><p className="text-xs text-muted-foreground">@{u.username} · {u.tg_user_id}</p></div>
          <div className="text-right text-xs"><p>{fmt(Number(u.coin_balance), 0)} coins</p><p>{fmt(Number(u.usdt_balance), 4)} USDT</p></div>
        </button>
      ))}
    </div>
  );
}

function UserDetail({ id, onBack }: { id: number; onBack: () => void }) {
  const initData = useInit();
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["adm-user", id], queryFn: () => adminGetUser({ data: { initData, id } }) });
  const [coin, setCoin] = useState("");
  const [usdt, setUsdt] = useState("");
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [frz, setFrz] = useState<string | null>(null);
  const [frzReason, setFrzReason] = useState<string | null>(null);
  const [dep, setDep] = useState({ chain: "bsc", asset: "USDT", tx: "", amount: "" });
  if (!q.data) return <p className="text-muted-foreground">Loading…</p>;
  const { user: u, invited, evm, gramMemo } = q.data;
  const depChain = chainById(dep.chain);

  const run = async (payload: { initData: string; id: number; coinDelta?: number; usdtDelta?: number; banned?: boolean; banReason?: string; freeze?: number; freezeReason?: string }) => {
    setBusy(true);
    try { await adminUpdateUser({ data: payload }); toast.success("Saved"); setCoin(""); setUsdt(""); qc.invalidateQueries({ queryKey: ["adm-user", id] }); qc.invalidateQueries({ queryKey: ["adm-users"] }); }
    catch (e) { err(e); } finally { setBusy(false); }
  };
  const manualDeposit = async () => {
    setBusy(true);
    try {
      const r = await adminManualDeposit({ data: { initData, id, chain: dep.chain as "bsc", asset: dep.asset, tx: dep.tx.trim(), amount: Number(dep.amount) } });
      toast.success(`Credited $${r.usd} → ${r.coins} coins`);
      setDep((d) => ({ ...d, tx: "", amount: "" }));
      qc.invalidateQueries({ queryKey: ["adm-user", id] });
    } catch (e) { err(e); } finally { setBusy(false); }
  };
  const row = (k: string, v: ReactNode) => <div className="flex justify-between gap-3 py-1 text-sm"><span className="text-muted-foreground">{k}</span><span className="break-all text-right font-medium">{v}</span></div>;

  return (
    <div className="space-y-3">
      <button onClick={onBack} className="inline-flex items-center gap-1 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" /> Back</button>
      <div className={card}>
        <p className="text-lg font-bold">{u.name}</p>
        {row("Telegram ID", u.tg_user_id)}{row("Username", `@${u.username}`)}{row("Wallet index", u.wallet_index)}
        {row("Joined", new Date(u.joined_at).toLocaleString())}{row("Last seen", new Date(u.last_seen_at).toLocaleString())}
        {row("Coins", fmt(Number(u.coin_balance), 2))}{row("USDT", Number(u.usdt_balance).toFixed(6))}{row("Pending withdrawals", Number(u.usdt_frozen).toFixed(4))}
        {row("Frozen by admin", `${Number(u.admin_frozen).toFixed(4)} USDT${u.freeze_reason ? ` (${u.freeze_reason})` : ""}`)}
        {row("Total deposit", `$${fmt(Number(u.total_deposit))}`)}{row("Total withdrawal", `$${fmt(Number(u.total_withdrawal))}`)}
        {row("Referred by", u.referred_by ?? "—")}{row("Invited", invited)}{row("Referral earnings", `${fmt(Number(u.referral_earnings_coins), 0)} coins`)}
        {row("Status", u.is_banned ? <span className="text-destructive">Banned ({u.ban_reason})</span> : <span className="text-success">Active</span>)}
      </div>
      <div className={card}>
        <p className="mb-1 font-semibold">Deposit addresses</p>
        {row("EVM", evm)}{row("GRAM memo", gramMemo)}
      </div>
      <div className={`${card} space-y-2`}>
        <p className="font-semibold">Adjust balance (use minus to remove)</p>
        <div className="flex gap-2"><input value={coin} onChange={(e) => setCoin(e.target.value)} placeholder="Coins e.g. 50 or -20" className={input} />
          <button disabled={busy || !Number(coin)} onClick={() => run({ initData, id, coinDelta: Number(coin) })} className={`${btn} bg-primary text-primary-foreground`}>Apply</button></div>
        <div className="flex gap-2"><input value={usdt} onChange={(e) => setUsdt(e.target.value)} placeholder="USDT e.g. 5 or -1.5" className={input} />
          <button disabled={busy || !Number(usdt)} onClick={() => run({ initData, id, usdtDelta: Number(usdt) })} className={`${btn} bg-primary text-primary-foreground`}>Apply</button></div>
      </div>
      <div className={`${card} space-y-2`}>
        <p className="font-semibold">Freeze balance</p>
        <p className="text-xs text-muted-foreground">Frozen USDT stays in the total balance but cannot be withdrawn. Set 0 to unfreeze.</p>
        <input value={frz ?? String(Number(u.admin_frozen))} onChange={(e) => setFrz(e.target.value)} inputMode="decimal" placeholder="Frozen USDT" className={input} />
        <input value={frzReason ?? (u.freeze_reason ?? "")} onChange={(e) => setFrzReason(e.target.value)} placeholder="Reason (shown to admins)" className={input} />
        <button disabled={busy} aria-busy={busy} onClick={() => { const n = Number(frz ?? u.admin_frozen); if (!Number.isFinite(n) || n < 0) return err(new Error("Invalid amount")); run({ initData, id, freeze: n, freezeReason: frzReason ?? u.freeze_reason ?? "" }); }} className={`${btn} w-full bg-secondary text-secondary-foreground`}>Save freeze</button>
      </div>
      <div className={`${card} space-y-2`}>
        <p className="font-semibold">Manual deposit</p>
        <p className="text-xs text-muted-foreground">Use when automatic detection missed a transfer. Recorded by tx hash, so it will never be credited twice.</p>
        <div className="grid grid-cols-2 gap-2">
          <select value={dep.chain} onChange={(e) => { const c = chainById(e.target.value); setDep((d) => ({ ...d, chain: e.target.value, asset: c?.assets[0]?.symbol ?? "USDT" })); }} className={input}>
            {CHAINS.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <select value={dep.asset} onChange={(e) => setDep((d) => ({ ...d, asset: e.target.value }))} className={input}>
            {(depChain?.assets ?? []).map((a) => <option key={a.symbol} value={a.symbol}>{a.label}</option>)}
          </select>
        </div>
        <input value={dep.tx} onChange={(e) => setDep((d) => ({ ...d, tx: e.target.value }))} placeholder="Tx hash" className={`${input} font-mono`} />
        <input value={dep.amount} onChange={(e) => setDep((d) => ({ ...d, amount: e.target.value }))} inputMode="decimal" placeholder={`Amount in ${dep.asset}`} className={input} />
        <button disabled={busy || !dep.tx.trim() || !Number(dep.amount)} onClick={manualDeposit} className={`${btn} w-full bg-primary text-primary-foreground`}>Credit deposit</button>
      </div>
      <div className={`${card} space-y-2`}>
        {u.is_banned ? (
          <button disabled={busy} aria-busy={busy} onClick={() => run({ initData, id, banned: false })} className={`${btn} w-full bg-success text-primary-foreground`}>Unban user</button>
        ) : (
          <>
            <input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Ban reason (optional)" className={input} />
            <button disabled={busy} aria-busy={busy} onClick={() => run({ initData, id, banned: true, banReason: reason || "manual" })} className={`${btn} w-full bg-destructive text-destructive-foreground`}>Ban user</button>
          </>
        )}
      </div>
    </div>
  );
}

function Withdrawals() {
  const initData = useInit();
  const qc = useQueryClient();
  const [status, setStatus] = useState<"pending" | "paid" | "rejected">("pending");
  const q = useQuery({ queryKey: ["adm-wd", status], queryFn: () => adminWithdrawals({ data: { initData, status } }) });
  const [form, setForm] = useState<Record<string, { tx?: string; reason?: string; refund?: boolean }>>({});
  const b = useBusy();
  const [act, setAct] = useState<Record<string, "pay" | "reject">>({});
  const review = (id: string, action: "pay" | "reject") => b.run(`wd:${id}`, async () => {
    const f = form[id] ?? {};
    try {
      await adminReviewWithdrawal({ data: { initData, id, action, txHash: f.tx, reason: f.reason, refund: f.refund ?? true } });
      toast.success(action === "pay" ? "Marked as paid" : "Rejected");
      await qc.invalidateQueries({ queryKey: ["adm-wd"] });
    } catch (e) { err(e); }
  });
  const [paying, setPaying] = useState<string | null>(null);
  const autoPay = async (id: string) => {
    if (paying) return;
    setPaying(id);
    try {
      const r = await adminReviewWithdrawal({ data: { initData, id, action: "pay", auto: true } });
      toast.success(`Paid${(r as { txHash?: string | null })?.txHash ? ` · tx ${(r as { txHash?: string | null }).txHash!.slice(0, 10)}…` : ""}`);
      qc.invalidateQueries({ queryKey: ["adm-wd"] });
    } catch (e) { err(e); } finally { setPaying(null); }
  };
  const freeze = (id: string) => b.run(`fz:${id}`, async () => {
    try { const r = await adminFreezeWithdrawal({ data: { initData, id } }); toast.success(`Frozen total: ${r.frozen} USDT`); qc.invalidateQueries({ queryKey: ["adm-wd"] }); qc.invalidateQueries({ queryKey: ["adm-frozen"] }); } catch (e) { err(e); }
  });
  const unfreeze = (id: number) => b.run(`uf:${id}`, async () => {
    try { await adminUnfreeze({ data: { initData, id } }); toast.success("Balance unfrozen"); qc.invalidateQueries({ queryKey: ["adm-wd"] }); qc.invalidateQueries({ queryKey: ["adm-frozen"] }); } catch (e) { err(e); }
  });
  const set = (id: string, v: object) => setForm((s) => ({ ...s, [id]: { ...s[id], ...v } }));
  const deleteOne = (id: string, st: "paid" | "rejected") => b.run(`del:${id}`, async () => {
    if (!confirm("Delete this withdrawal record?")) return;
    try { await adminDeleteWithdrawals({ data: { initData, status: st, id } }); toast.success("Deleted"); await qc.invalidateQueries({ queryKey: ["adm-wd"] }); } catch (e) { err(e); }
  });
  const deleteAll = (st: "paid" | "rejected") => b.run("del:all", async () => {
    if (!confirm(`Delete ALL ${st} withdrawal records? This cannot be undone.`)) return;
    try { const r = await adminDeleteWithdrawals({ data: { initData, status: st } }); toast.success(`Deleted ${r.deleted} record(s)`); await qc.invalidateQueries({ queryKey: ["adm-wd"] }); } catch (e) { err(e); }
  });
  const [viewUser, setViewUser] = useState<number | null>(null);
  const st = useQuery({ queryKey: ["adm-settings"], queryFn: () => adminGetSettings({ data: { initData } }) });
  const open = String((st.data?.settings as unknown as Record<string, unknown> | undefined)?.["withdrawals_open"] ?? "on") !== "off";
  const [toggling, setToggling] = useState(false);
  const cfg = (st.data?.settings as unknown as Record<string, unknown> | undefined) ?? {};
  const toggleKey = async (key: string, next: boolean, label: string) => {
    setToggling(true);
    try { await adminSaveSettings({ data: { initData, settings: { [key]: next ? "on" : "off" } } }); toast.success(`${label} ${next ? "opened" : "closed"}`); await st.refetch(); }
    catch (e) { err(e); } finally { setToggling(false); }
  };
  const toggle = async (next: boolean) => {
    setToggling(true);
    try { await adminSaveSettings({ data: { initData, settings: { withdrawals_open: next ? "on" : "off" } } }); toast.success(next ? "Withdrawals opened" : "Withdrawals closed"); await st.refetch(); }
    catch (e) { err(e); } finally { setToggling(false); }
  };
  return (
    <div className="space-y-3">
      <div className={`${card} flex items-center gap-3`}>
        <div className="flex-1">
          <p className="font-semibold">Withdrawals are {st.data ? (open ? <span className="text-success">OPEN</span> : <span className="text-destructive">CLOSED</span>) : "…"}</p>
          <p className="text-xs text-muted-foreground">When closed, users can't request a withdrawal and see a pop-up message.</p>
        </div>
        <div className="flex gap-2">
          <button disabled={toggling || !st.data || open} onClick={() => toggle(true)} className={`${btn} bg-success text-primary-foreground`}>Open</button>
          <button disabled={toggling || !st.data || !open} onClick={() => toggle(false)} className={`${btn} bg-destructive text-destructive-foreground`}>Close</button>
        </div>
      </div>
      {([["withdraw_bep20_open", "BSC-USDT (BEP20)"], ["withdraw_gram_open", "GRAM-USDT"]] as const).map(([k, label]) => {
        const on = String(cfg[k] ?? "on") !== "off";
        return (
          <div key={k} className={`${card} flex items-center gap-3`}>
            <p className="flex-1 font-semibold">{label}: {st.data ? (on ? <span className="text-success">OPEN</span> : <span className="text-destructive">CLOSED</span>) : "…"}</p>
            <div className="flex gap-2">
              <button disabled={toggling || !st.data || on} onClick={() => toggleKey(k, true, label)} className={`${btn} bg-success text-primary-foreground`}>Open</button>
              <button disabled={toggling || !st.data || !on} onClick={() => toggleKey(k, false, label)} className={`${btn} bg-destructive text-destructive-foreground`}>Close</button>
            </div>
          </div>
        );
      })}
      {viewUser !== null && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-background/80 backdrop-blur-sm sm:items-center" onClick={() => setViewUser(null)}>
          <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-t-3xl border border-border bg-background p-4 sm:rounded-3xl" onClick={(e) => e.stopPropagation()}>
            <UserDetail id={viewUser} onBack={() => setViewUser(null)} />
          </div>
        </div>
      )}
      <div className="flex gap-2 rounded-full bg-muted p-1">
        {(["pending", "paid", "rejected"] as const).map((s) => (
          <button key={s} onClick={() => setStatus(s)} className={`flex-1 rounded-full py-2 text-sm font-semibold capitalize ${status === s ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>{s}</button>
        ))}
      </div>
      {status !== "pending" && (q.data ?? []).length > 0 && (
        <button disabled={b.is("del:all")} aria-busy={b.is("del:all")} onClick={() => deleteAll(status)} className={`${btn} w-full bg-destructive text-destructive-foreground`}>
          {b.is("del:all") ? "Deleting…" : `Delete all ${status} withdrawals`}
        </button>
      )}
      {q.data && q.data.length === 0 && <p className="text-sm text-muted-foreground">No {status} withdrawals.</p>}
      {(q.data ?? []).map((w) => {
        const c = chainById(w.chain);
        return (
          <div key={w.id} className={`${card} space-y-1 text-sm`}>
            <div className="flex justify-between font-semibold"><span>{Number(w.amount)} USDT → {w.asset} {c?.name}</span><span className="text-muted-foreground">fee {Number(w.fee)}</span></div>
            <div className="flex items-center justify-between gap-2">
              <p className="text-xs text-muted-foreground">User {w.user_id} · {new Date(w.created_at).toLocaleString()}</p>
              <button onClick={() => setViewUser(w.user_id)} className="shrink-0 rounded-lg bg-muted px-2 py-1 text-xs font-semibold text-primary">View account</button>
            </div>
            <p className="text-xs">Total withdrawn: <b>{w.stats.total.toFixed(4)} USDT</b> · Times: <b>{w.stats.times}</b> · Frozen: <b className="text-gold">{w.stats.frozen} USDT</b></p>
            <p className="break-all font-mono text-xs">{w.address}</p>
            {w.tx_hash && <a href={`${c?.explorerTx ?? ""}${w.tx_hash}`} target="_blank" rel="noreferrer" className="block break-all font-mono text-xs text-primary underline">{w.tx_hash}</a>}
            {w.reject_reason && <p className="text-xs text-destructive">{w.reject_reason}{w.refunded ? " (refunded)" : ""}</p>}
            {status !== "pending" && (
              <button disabled={b.is(`del:${w.id}`) || b.is("del:all")} aria-busy={b.is(`del:${w.id}`)} onClick={() => deleteOne(w.id, status)} className="mt-1 rounded-lg bg-destructive/15 px-3 py-1 text-xs font-semibold text-destructive disabled:opacity-60">
                {b.is(`del:${w.id}`) ? "Deleting…" : "Delete"}
              </button>
            )}
            {status === "pending" && (
              <div className="space-y-2 pt-2">
                <input placeholder={w.chain === "ton" ? "Payout tx hash" : "Tx hash (optional)"} className={input} onChange={(e) => set(w.id, { tx: e.target.value })} />
                <div className="flex gap-2">
                  <button disabled={b.is(`fz:${w.id}`)} aria-busy={b.is(`fz:${w.id}`)} onClick={() => freeze(w.id)} className={`${btn} flex-1 bg-secondary text-secondary-foreground`}>{b.is(`fz:${w.id}`) ? "Freezing…" : `Freeze (${Number(w.amount)} USDT)`}</button>
                  {w.stats.frozen > 0 && <button disabled={b.is(`uf:${w.user_id}`)} aria-busy={b.is(`uf:${w.user_id}`)} onClick={() => unfreeze(w.user_id)} className={`${btn} flex-1 bg-muted text-foreground`}>{b.is(`uf:${w.user_id}`) ? "Unfreezing…" : "Unfreeze all"}</button>}
                </div>
                {(
                  <button disabled={paying === w.id || b.is(`wd:${w.id}`)} aria-busy={paying === w.id} onClick={() => { if (paying || b.is(`wd:${w.id}`)) return; if (confirm(`Auto send ${Number(w.amount)} USDT (${w.chain === "ton" ? "GRAM" : "BEP20"}) from payout wallet?`)) { set(w.id, { tx: "" }); void autoPay(w.id); } }} className={`${btn} w-full bg-success text-primary-foreground`}>{paying === w.id ? "Sending…" : "⚡ Auto pay (send USDT now)"}</button>
                )}
                <button disabled={b.is(`wd:${w.id}`) || paying === w.id} aria-busy={b.is(`wd:${w.id}`)} onClick={() => { setAct((s) => ({ ...s, [w.id]: "pay" })); void review(w.id, "pay"); }} className={`${btn} w-full bg-primary text-primary-foreground`}>{b.is(`wd:${w.id}`) && act[w.id] === "pay" ? "Marking paid…" : w.chain !== "ton" ? "Mark paid (with tx hash above)" : "Approve & mark paid"}</button>
                <input placeholder="Reject reason" className={input} onChange={(e) => set(w.id, { reason: e.target.value })} />
                <label className="flex items-center gap-2 text-xs"><input type="checkbox" defaultChecked onChange={(e) => set(w.id, { refund: e.target.checked })} /> Refund USDT to user</label>
                <button disabled={b.is(`wd:${w.id}`) || paying === w.id} aria-busy={b.is(`wd:${w.id}`)} onClick={() => { setAct((s) => ({ ...s, [w.id]: "reject" })); void review(w.id, "reject"); }} className={`${btn} w-full bg-destructive text-destructive-foreground`}>{b.is(`wd:${w.id}`) && act[w.id] === "reject" ? "Rejecting…" : "Reject"}</button>
              </div>
            )}
          </div>
        );
      })}
      {q.data && !q.data.length && <p className="text-sm text-muted-foreground">Nothing here.</p>}
    </div>
  );
}

function CheckDeposit() {
  const initData = useInit();
  const [addr, setAddr] = useState("");
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<Awaited<ReturnType<typeof adminInspectAddress>> | null>(null);
  const run = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true);
    try { const r = await adminInspectAddress({ data: { initData, address: addr.trim() } }); setRes(r); if (r.credited) toast.success(`${r.credited} new deposit(s) credited`); }
    catch (x) { err(x); } finally { setBusy(false); }
  };
  return (
    <div className="space-y-3">
      <form onSubmit={run} className="flex gap-2">
        <input value={addr} onChange={(e) => setAddr(e.target.value)} placeholder="0x… deposit address" className={input} />
        <button disabled={busy} aria-busy={busy} className={`${btn} bg-primary text-primary-foreground`} aria-label="Check"><Search className="h-4 w-4" /></button>
      </form>
      {res && (
        <p className="text-xs text-muted-foreground">
          {res.owner ? `Owner: user ${res.owner}` : "No app user has this address"} · {res.rows.length} transfer(s) on BNB Chain + Ethereum
          {res.errors.map((x) => <span key={x} className="block text-destructive">{x}</span>)}
        </p>
      )}
      {res?.rows.map((r) => {
        const c = chainById(r.chain);
        return (
          <div key={r.tx + r.asset + r.direction} className={`${card} space-y-1 text-sm`}>
            <div className="flex items-center justify-between font-semibold">
              <span>{r.direction === "in" ? "⬇ In" : "⬆ Out"} · {r.amount} {r.asset} · {c?.name ?? r.chain}</span>
              <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${!r.official ? "bg-destructive/15 text-destructive" : r.recorded ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground"}`}>
                {!r.official ? "Unofficial" : r.recorded ? (r.recorded === "below_minimum" ? "Below min" : r.recorded) : r.direction === "in" ? "Not credited" : "—"}
              </span>
            </div>
            <p className="break-all text-xs text-muted-foreground">From {r.from} → {r.to}{r.time ? ` · ${new Date(r.time).toLocaleString()}` : ""}</p>
            <a href={`${c?.explorerTx ?? ""}${r.tx}`} target="_blank" rel="noreferrer" className="block break-all font-mono text-xs text-primary underline">{r.tx}</a>
          </div>
        );
      })}
    </div>
  );
}

function Frozen() {
  const initData = useInit();
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["adm-frozen"], queryFn: () => adminFrozenUsers({ data: { initData } }) });
  const [amt, setAmt] = useState<Record<number, string>>({});
  const fb = useBusy();
  const run = async (id: number, partial: boolean) => {
    const v = Number(amt[id]);
    if (partial && !(v > 0)) { toast.error("Enter an amount to unfreeze"); return; }
    await fb.run(`fr:${id}`, async () => { try {
      const r = await adminUnfreeze({ data: { initData, id, ...(partial ? { amount: v } : {}) } });
      toast.success(r.frozen > 0 ? `Still frozen: ${r.frozen} USDT` : "Balance unfrozen");
      qc.invalidateQueries({ queryKey: ["adm-frozen"] }); qc.invalidateQueries({ queryKey: ["adm-wd"] });
    } catch (e) { err(e); } });
  };
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <Stat label="Users with frozen balance" value={q.data?.users.length ?? "…"} />
        <Stat label="Total frozen" value={q.data ? `${fmt(q.data.total, 4)} USDT` : "…"} />
      </div>
      {(q.data?.users ?? []).map((u) => (
        <div key={u.tg_user_id} className={`${card} space-y-2 text-sm`}>
          <div className="flex justify-between font-semibold"><span>{u.name ?? "User"}{u.username ? ` @${u.username}` : ""}</span><span className="text-gold">{u.admin_frozen} USDT</span></div>
          <p className="text-xs text-muted-foreground">ID {u.tg_user_id} · Wallet #{u.wallet_index ?? "—"} · Balance {fmt(u.usdt_balance, 4)} USDT{u.freeze_reason ? ` · ${u.freeze_reason}` : ""}</p>
          <div className="flex gap-2">
            <input inputMode="decimal" placeholder="Amount" value={amt[u.tg_user_id] ?? ""} onChange={(e) => setAmt((s) => ({ ...s, [u.tg_user_id]: e.target.value }))} className={input} />
            <button disabled={fb.is(`fr:${u.tg_user_id}`)} aria-busy={fb.is(`fr:${u.tg_user_id}`)} onClick={() => run(u.tg_user_id, true)} className={`${btn} shrink-0 bg-secondary text-secondary-foreground`}>Unfreeze</button>
            <button disabled={fb.is(`fr:${u.tg_user_id}`)} aria-busy={fb.is(`fr:${u.tg_user_id}`)} onClick={() => run(u.tg_user_id, false)} className={`${btn} shrink-0 bg-primary text-primary-foreground`}>All</button>
          </div>
        </div>
      ))}
      {q.data && !q.data.users.length && <p className="text-sm text-muted-foreground">No frozen balances.</p>}
    </div>
  );
}

function Deposits() {
  const initData = useInit();
  const [q, setQ] = useState("");
  const [term, setTerm] = useState("");
  const list = useQuery({ queryKey: ["adm-dep", term], queryFn: () => adminDeposits({ data: { initData, userId: term } }) });
  return (
    <div className="space-y-3">
      <form onSubmit={(e) => { e.preventDefault(); setTerm(q); }} className="flex gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Filter by Telegram ID" className={input} />
        <button className={`${btn} bg-primary text-primary-foreground`} aria-label="Search"><Search className="h-4 w-4" /></button>
      </form>
      {(list.data ?? []).map((d) => {
        const c = chainById(d.chain);
        const logo = c?.assets.find((a) => a.symbol === d.asset)?.logo ?? LOGO.USDT;
        return (
          <div key={d.id} className={`${card} space-y-1 text-sm`}>
            <div className="flex items-center justify-between font-semibold">
              <span className="flex items-center gap-2"><CoinImg src={logo} size={18} />{Number(d.amount)} {d.asset} · {c?.name}</span>
              <span className="flex items-center gap-2">
                {d.status && d.status !== "credited" && d.status !== "confirmed" && (
                  <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${d.status === "fake" ? "bg-destructive/15 text-destructive" : "bg-muted text-muted-foreground"}`}>{d.status === "below_minimum" ? "Below min" : d.status}</span>
                )}
                ${fmt(Number(d.usd_value))}
              </span>
            </div>
            <p className="flex items-center gap-1 text-xs text-muted-foreground">User {d.user_id} · Wallet #{d.wallet_index ?? "—"} · +{fmt(Number(d.coins_credited), 0)} <CoinImg size={12} /> · {new Date(d.created_at).toLocaleString()}</p>
            <a href={`${c?.explorerTx ?? ""}${d.tx_hash}`} target="_blank" rel="noreferrer" className="block break-all font-mono text-xs text-primary underline">{d.tx_hash}</a>
          </div>
        );
      })}
      {list.data && !list.data.length && <p className="text-sm text-muted-foreground">No deposits yet.</p>}
    </div>
  );
}

function Broadcast() {
  const initData = useInit();
  const [target, setTarget] = useState("all");
  const [text, setText] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [buttons, setButtons] = useState<{ label: string; url: string }[]>([]);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ total: number; sent: number; failed: number; blocked: number; batches: number; errors: { id: number; error: string }[] } | null>(null);
  const send = async () => {
    setBusy(true); setResult(null);
    try {
      const r = await adminBroadcast({ data: { initData, target: target.trim(), text, imageUrl: imageUrl.trim(), buttons: buttons.filter((b) => b.label && b.url) } });
      setResult(r);
      toast.success(`Sent ${r.sent}, failed ${r.failed}`);
    } catch (e) { err(e); } finally { setBusy(false); }
  };
  return (
    <div className={`${card} space-y-3`}>
      <div><p className="mb-1 text-xs text-muted-foreground">Send to ("all" or a Telegram ID)</p><input value={target} onChange={(e) => setTarget(e.target.value)} className={input} /></div>
      <div><p className="mb-1 text-xs text-muted-foreground">Message (HTML: &lt;b&gt;, &lt;i&gt;, &lt;a href&gt;)</p><textarea value={text} onChange={(e) => setText(e.target.value)} rows={6} className={input} /></div>
      <div><p className="mb-1 text-xs text-muted-foreground">Image URL (optional)</p><input value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} placeholder="https://…" className={input} /></div>
      <div className="space-y-2">
        <p className="text-xs text-muted-foreground">Buttons</p>
        {buttons.map((b, i) => (
          <div key={i} className="flex gap-2">
            <input value={b.label} placeholder="Label" onChange={(e) => setButtons((s) => s.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)))} className={input} />
            <input value={b.url} placeholder="https://…" onChange={(e) => setButtons((s) => s.map((x, j) => (j === i ? { ...x, url: e.target.value } : x)))} className={input} />
            <button onClick={() => setButtons((s) => s.filter((_, j) => j !== i))} aria-label="Remove button"><Trash2 className="h-4 w-4 text-destructive" /></button>
          </div>
        ))}
        <button onClick={() => setButtons((s) => [...s, { label: "", url: "" }])} className="inline-flex items-center gap-1 text-sm text-primary"><Plus className="h-4 w-4" /> Add button</button>
      </div>
      <button disabled={busy || !text} onClick={send} className={`${btn} w-full bg-primary py-3 text-primary-foreground`}>{busy ? "Sending…" : "Send broadcast"}</button>
      {result && (
        <div className="rounded-2xl bg-muted p-3 text-sm">
          <p className="font-semibold">Broadcast result</p>
          <p>Total: {result.total} · Batches (50 each): {result.batches}</p>
          <p className="text-success">Sent: {result.sent}</p>
          <p className="text-destructive">Failed: {result.failed} (blocked/deleted bot: {result.blocked})</p>
          {result.errors.length > 0 && <details className="mt-1"><summary className="cursor-pointer text-xs text-muted-foreground">Failed IDs (first {result.errors.length})</summary>
            <ul className="mt-1 max-h-40 overflow-auto text-xs">{result.errors.map((e) => <li key={e.id} className="font-mono">{e.id}: {e.error}</li>)}</ul></details>}
        </div>
      )}
    </div>
  );
}

const FIELDS: [string, string][] = [
  ["welcome_bonus", "Welcome bonus (coins)"], ["coin_rate", "Coins per $1 deposit"], ["daily_yield_pct", "Estimated daily yield %"],
  ["min_claim_usdt", "Minimum claim (USDT)"],
  ["gift_min", "Gift min coins"], ["gift_max", "Gift max coins"],
  ["referral_coins", "Referral reward (coins)"],
  ["min_deposit_usd", "Min deposit (USD)"], ["min_withdrawal_usdt", "Min withdrawal (USDT)"],
  ["free_withdrawal_cap", "Free withdrawal cap without deposit (USDT)"], ["withdrawal_fee_value", "Withdrawal fee value"],
];

function SettingsTab() {
  const initData = useInit();
  const q = useQuery({ queryKey: ["adm-settings"], queryFn: () => adminGetSettings({ data: { initData } }) });
  const [vals, setVals] = useState<Record<string, string>>({});
  const [newAdmin, setNewAdmin] = useState("");
  const [busy, setBusy] = useState(false);
  const sb = useBusy();
  useEffect(() => {
    if (!q.data) return;
    const s = q.data.settings as unknown as Record<string, unknown>;
    setVals(Object.fromEntries(Object.entries(s).map(([k, v]) => [k, String(v)])));
  }, [q.data]);
  if (!q.data) return <p className="text-muted-foreground">Loading…</p>;

  const save = async () => {
    setBusy(true);
    try {
      const settings: Record<string, number | string> = {};
      for (const [k] of FIELDS) { const n = Number(vals[k]); if (!Number.isFinite(n) || n < 0) throw new Error(`Invalid value for ${k}`); settings[k] = n; }
      settings["withdrawal_fee_type"] = vals["withdrawal_fee_type"] === "percent" ? "percent" : "flat";
      settings["ton_address"] = vals["ton_address"] ?? "";
      settings["memo_prefix"] = vals["memo_prefix"] ?? "OMA-";
      settings["join_channel"] = (vals["join_channel"] ?? "").trim();
      settings["join_payment_channel"] = (vals["join_payment_channel"] ?? "").trim();
      await adminSaveSettings({ data: { initData, settings } });
      toast.success("Settings saved");
      q.refetch();
    } catch (e) { err(e); } finally { setBusy(false); }
  };
  const addAdmin = async () => {
    const n = Number(newAdmin.trim());
    if (!Number.isInteger(n) || n <= 0) return err(new Error("Enter a valid Telegram ID"));
    try { await adminAddAdmin({ data: { initData, id: n } }); toast.success("Admin added"); setNewAdmin(""); q.refetch(); } catch (e) { err(e); }
  };
  const removeAdmin = async (id: number) => {
    try { await adminRemoveAdmin({ data: { initData, id } }); toast.success("Admin removed"); q.refetch(); } catch (e) { err(e); }
  };
  const setupBot = async () => {
    try { const r = await adminSetupWebhook({ data: { initData, origin: window.location.origin } }); toast.success(`Bot connected: ${r.url}`); } catch (e) { err(e); }
  };

  return (
    <div className="space-y-3">
      <div className={`${card} grid grid-cols-2 gap-3`}>
        {FIELDS.map(([k, label]) => (
          <label key={k} className="text-xs text-muted-foreground">{label}
            <input value={vals[k] ?? ""} onChange={(e) => setVals((s) => ({ ...s, [k]: e.target.value }))} inputMode="decimal" className={`${input} mt-1 text-foreground`} />
          </label>
        ))}
        <label className="text-xs text-muted-foreground">Fee type
          <select value={vals["withdrawal_fee_type"] ?? "flat"} onChange={(e) => setVals((s) => ({ ...s, withdrawal_fee_type: e.target.value }))} className={`${input} mt-1 text-foreground`}>
            <option value="flat">Flat (USDT)</option><option value="percent">Percent</option>
          </select>
        </label>
      </div>
      <div className={`${card} space-y-3`}>
        <label className="block text-xs text-muted-foreground">GRAM deposit address<input value={vals["ton_address"] ?? ""} onChange={(e) => setVals((s) => ({ ...s, ton_address: e.target.value }))} className={`${input} mt-1 font-mono text-foreground`} /></label>
        <label className="block text-xs text-muted-foreground">Memo prefix (applies to new users)<input value={vals["memo_prefix"] ?? ""} onChange={(e) => setVals((s) => ({ ...s, memo_prefix: e.target.value }))} className={`${input} mt-1 text-foreground`} /></label>
      </div>
      <div className={`${card} space-y-3`}>
        <p className="font-semibold">Join gate (optional)</p>
        <label className="block text-xs text-muted-foreground">Channel (@username or t.me link)<input value={vals["join_channel"] ?? ""} onChange={(e) => setVals((s) => ({ ...s, join_channel: e.target.value }))} placeholder="@OminiAiNews" className={`${input} mt-1 text-foreground`} /></label>
        <label className="block text-xs text-muted-foreground">Payment channel (@username or t.me link)<input value={vals["join_payment_channel"] ?? ""} onChange={(e) => setVals((s) => ({ ...s, join_payment_channel: e.target.value }))} placeholder="@OminiAiPayments" className={`${input} mt-1 text-foreground`} /></label>
        <p className="rounded-xl bg-muted p-2 text-xs text-muted-foreground">⚠️ Important: you must manually add <b>@OminixAiBot</b> as an <b>admin</b> in each channel above, otherwise membership cannot be verified. Leave both empty to disable the pop-up.</p>
      </div>
      <button disabled={busy} aria-busy={busy} onClick={save} className={`${btn} w-full bg-primary py-3 text-primary-foreground`}>{busy ? "Saving…" : "Save settings"}</button>

      <div className={`${card} space-y-2`}>
        <p className="font-semibold">Admins</p>
        {q.data.admins.map((a) => (
          <div key={a.id} className="flex items-center justify-between rounded-xl bg-muted px-3 py-2 text-sm">
            <div className="min-w-0"><p className="truncate font-semibold">{a.name ?? "Unknown user"}{a.owner && <span className="ml-2 text-xs text-primary">owner</span>}</p><p className="text-xs text-muted-foreground">{a.username ? `@${a.username} · ` : ""}{a.id}</p></div>
            {!a.owner && <button disabled={sb.is(`rm:${a.id}`)} aria-busy={sb.is(`rm:${a.id}`)} onClick={() => sb.run(`rm:${a.id}`, () => removeAdmin(a.id))} aria-label="Remove admin"><Trash2 className="h-4 w-4 text-destructive" /></button>}
          </div>
        ))}
        <div className="flex gap-2">
          <input value={newAdmin} onChange={(e) => setNewAdmin(e.target.value)} inputMode="numeric" placeholder="Telegram ID" className={input} />
          <button disabled={sb.is("add")} aria-busy={sb.is("add")} onClick={() => sb.run("add", addAdmin)} className={`${btn} bg-primary text-primary-foreground`} aria-label="Add admin"><Plus className="h-4 w-4" /></button>
        </div>
      </div>

      <button disabled={sb.is("bot")} aria-busy={sb.is("bot")} onClick={() => sb.run("bot", setupBot)} className={`${btn} w-full bg-secondary py-3 text-secondary-foreground`}>{sb.is("bot") ? "Connecting…" : "Connect bot (/start replies)"}</button>
    </div>
  );
}
