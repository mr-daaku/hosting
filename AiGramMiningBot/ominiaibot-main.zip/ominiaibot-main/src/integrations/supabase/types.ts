export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      admins: {
        Row: {
          created_at: string
          tg_user_id: number
        }
        Insert: {
          created_at?: string
          tg_user_id: number
        }
        Update: {
          created_at?: string
          tg_user_id?: number
        }
        Relationships: []
      }
      app_settings: {
        Row: {
          key: string
          value: Json
        }
        Insert: {
          key: string
          value: Json
        }
        Update: {
          key?: string
          value?: Json
        }
        Relationships: []
      }
      broadcasts: {
        Row: {
          buttons: Json | null
          created_at: string
          failed_count: number
          id: string
          image_url: string | null
          sent_by: number | null
          sent_count: number
          target: string
          text: string
        }
        Insert: {
          buttons?: Json | null
          created_at?: string
          failed_count?: number
          id?: string
          image_url?: string | null
          sent_by?: number | null
          sent_count?: number
          target: string
          text: string
        }
        Update: {
          buttons?: Json | null
          created_at?: string
          failed_count?: number
          id?: string
          image_url?: string | null
          sent_by?: number | null
          sent_count?: number
          target?: string
          text?: string
        }
        Relationships: []
      }
      deposits: {
        Row: {
          amount: number
          asset: string
          chain: string
          coins_credited: number
          created_at: string
          id: string
          status: string
          tx_hash: string
          usd_value: number
          user_id: number
        }
        Insert: {
          amount: number
          asset: string
          chain: string
          coins_credited: number
          created_at?: string
          id?: string
          status?: string
          tx_hash: string
          usd_value: number
          user_id: number
        }
        Update: {
          amount?: number
          asset?: string
          chain?: string
          coins_credited?: number
          created_at?: string
          id?: string
          status?: string
          tx_hash?: string
          usd_value?: number
          user_id?: number
        }
        Relationships: [
          {
            foreignKeyName: "deposits_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["tg_user_id"]
          },
        ]
      }
      referrals: {
        Row: {
          created_at: string
          referred_id: number
          referrer_id: number
          signup_bonus_paid: boolean
          total_deposit_bonus_earned: number
        }
        Insert: {
          created_at?: string
          referred_id: number
          referrer_id: number
          signup_bonus_paid?: boolean
          total_deposit_bonus_earned?: number
        }
        Update: {
          created_at?: string
          referred_id?: number
          referrer_id?: number
          signup_bonus_paid?: boolean
          total_deposit_bonus_earned?: number
        }
        Relationships: [
          {
            foreignKeyName: "referrals_referred_id_fkey"
            columns: ["referred_id"]
            isOneToOne: true
            referencedRelation: "users"
            referencedColumns: ["tg_user_id"]
          },
          {
            foreignKeyName: "referrals_referrer_id_fkey"
            columns: ["referrer_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["tg_user_id"]
          },
        ]
      }
      transactions: {
        Row: {
          coin_delta: number
          created_at: string
          id: string
          kind: string
          note: string | null
          ref_id: string | null
          usdt_delta: number
          user_id: number
        }
        Insert: {
          coin_delta?: number
          created_at?: string
          id?: string
          kind: string
          note?: string | null
          ref_id?: string | null
          usdt_delta?: number
          user_id: number
        }
        Update: {
          coin_delta?: number
          created_at?: string
          id?: string
          kind?: string
          note?: string | null
          ref_id?: string | null
          usdt_delta?: number
          user_id?: number
        }
        Relationships: [
          {
            foreignKeyName: "transactions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["tg_user_id"]
          },
        ]
      }
      users: {
        Row: {
          admin_frozen: number
          ban_reason: string | null
          coin_balance: number
          freeze_reason: string | null
          gift_boxes: number
          is_banned: boolean
          joined_at: string
          last_gift_at: string | null
          last_seen_at: string
          last_yield_at: string
          name: string
          referral_earnings_coins: number
          referred_by: number | null
          tg_user_id: number
          total_deposit: number
          total_withdrawal: number
          usdt_balance: number
          usdt_frozen: number
          username: string
          wallet_index: number
        }
        Insert: {
          admin_frozen?: number
          ban_reason?: string | null
          coin_balance?: number
          freeze_reason?: string | null
          gift_boxes?: number
          is_banned?: boolean
          joined_at?: string
          last_gift_at?: string | null
          last_seen_at?: string
          last_yield_at?: string
          name?: string
          referral_earnings_coins?: number
          referred_by?: number | null
          tg_user_id: number
          total_deposit?: number
          total_withdrawal?: number
          usdt_balance?: number
          usdt_frozen?: number
          username?: string
          wallet_index?: number
        }
        Update: {
          admin_frozen?: number
          ban_reason?: string | null
          coin_balance?: number
          freeze_reason?: string | null
          gift_boxes?: number
          is_banned?: boolean
          joined_at?: string
          last_gift_at?: string | null
          last_seen_at?: string
          last_yield_at?: string
          name?: string
          referral_earnings_coins?: number
          referred_by?: number | null
          tg_user_id?: number
          total_deposit?: number
          total_withdrawal?: number
          usdt_balance?: number
          usdt_frozen?: number
          username?: string
          wallet_index?: number
        }
        Relationships: [
          {
            foreignKeyName: "users_referred_by_fkey"
            columns: ["referred_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["tg_user_id"]
          },
        ]
      }
      withdrawals: {
        Row: {
          address: string
          amount: number
          asset: string
          chain: string
          created_at: string
          fee: number
          id: string
          refunded: boolean
          reject_reason: string | null
          reviewed_at: string | null
          reviewed_by: number | null
          status: string
          tx_hash: string | null
          user_id: number
        }
        Insert: {
          address: string
          amount: number
          asset: string
          chain: string
          created_at?: string
          fee?: number
          id?: string
          refunded?: boolean
          reject_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: number | null
          status?: string
          tx_hash?: string | null
          user_id: number
        }
        Update: {
          address?: string
          amount?: number
          asset?: string
          chain?: string
          created_at?: string
          fee?: number
          id?: string
          refunded?: boolean
          reject_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: number | null
          status?: string
          tx_hash?: string | null
          user_id?: number
        }
        Relationships: [
          {
            foreignKeyName: "withdrawals_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["tg_user_id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      apply_balance: {
        Args: {
          p_coin: number
          p_kind: string
          p_note?: string
          p_ref?: string
          p_usdt: number
          p_user: number
        }
        Returns: {
          admin_frozen: number
          ban_reason: string | null
          coin_balance: number
          freeze_reason: string | null
          gift_boxes: number
          is_banned: boolean
          joined_at: string
          last_gift_at: string | null
          last_seen_at: string
          last_yield_at: string
          name: string
          referral_earnings_coins: number
          referred_by: number | null
          tg_user_id: number
          total_deposit: number
          total_withdrawal: number
          usdt_balance: number
          usdt_frozen: number
          username: string
          wallet_index: number
        }
        SetofOptions: {
          from: "*"
          to: "users"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      boot_user: { Args: { p_user: number }; Returns: Json }
      credit_deposit: {
        Args: {
          p_amount: number
          p_asset: string
          p_chain: string
          p_rate: number
          p_ref_pct: number
          p_tx: string
          p_usd: number
          p_user: number
        }
        Returns: number
      }
      referral_reward: {
        Args: { p_coins: number; p_referrer: number }
        Returns: undefined
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
