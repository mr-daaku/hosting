import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const auth = z.object({ initData: z.string().min(1).max(8000) });

/** App open: creates/updates the user and returns the home data in one request. */
export const getMe = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.parse(d))
  .handler(async ({ data }) => {
    const { verifyInitData, appLink } = await import("./telegram.server");
    const { getSettings, pendingYield, isAdmin, bootstrapUser } = await import("./core.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { user } = verifyInitData(data.initData);
    await bootstrapUser(data.initData);
    const t0 = Date.now();
    // One database call: user row + friends count + withdrawn/pending sum (settings + admin list are cached).
    const [boot, s, admin] = await Promise.all([
      supabaseAdmin.rpc("boot_user", { p_user: user.id }),
      getSettings(),
      isAdmin(user.id),
    ]);
    if (boot.error) {
      console.error("[boot_user]", user.id, `${Date.now() - t0}ms`, boot.error.message);
      throw new Error("Server busy, please try again");
    }
    const b = boot.data as unknown as { me: import("@/integrations/supabase/types").Tables<"users">; invited: number; withdrawn_or_pending: number } | null;
    if (!b?.me) throw new Error("Account not found");
    const me = b.me;
    const invited = Number(b.invited);
    const coins = Number(me.coin_balance);
    const pct = Number(s.daily_yield_pct);
    const withdrawnOrPending = Number(b.withdrawn_or_pending);
    return {
      me: {
        id: me.tg_user_id, name: me.name, username: me.username, photo: null,
        coins, usdt: Number(me.usdt_balance), frozen: Number(me.usdt_frozen),
        adminFrozen: Number(me.admin_frozen), freezeReason: me.freeze_reason,
        totalDeposit: Number(me.total_deposit), totalWithdrawal: Number(me.total_withdrawal),
        withdrawnOrPending,
        referralEarnings: Number(me.referral_earnings_coins), referredBy: me.referred_by,
        banned: me.is_banned, banReason: me.ban_reason, lastGiftAt: me.last_gift_at,
        giftBoxes: Number(me.gift_boxes ?? 0),
        pending: me.is_banned ? 0 : pendingYield(coins, me.last_yield_at, pct),
        lastYieldAt: me.last_yield_at,
      },
      invited,
      isAdmin: admin,
      refLink: appLink(user.id),
      settings: {
        dailyYieldPct: pct, referralCoins: Number(s.referral_coins),
        minClaim: Number(s.min_claim_usdt ?? 0.01),
        channels: [s.join_channel, s.join_payment_channel].map((c) => String(c ?? "").trim()).filter(Boolean),
        coinRate: Number(s.coin_rate),
        minDepositUsd: Number(s.min_deposit_usd), minWithdrawal: Number(s.min_withdrawal_usdt),
        freeWithdrawalCap: Number(s.free_withdrawal_cap ?? 0.25),
        feeType: s.withdrawal_fee_type, feeValue: Number(s.withdrawal_fee_value),
        withdrawalsOpen: String(s.withdrawals_open ?? "on") !== "off",
        bep20Open: String(s.withdraw_bep20_open ?? "on") !== "off",
        gramOpen: String(s.withdraw_gram_open ?? "on") !== "off",
      },
    };
  });

/**
 * Deposit address for the chosen method.
 * EVM (ETH/BNB/USDT): look up the user's wallet index → generate the address from the secret words.
 * GRAM: one fixed address from settings; the memo is the Telegram user id (built on the phone).
 */
export const getDepositAddress = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({ chain: z.enum(["eth", "bsc", "ton"]) }).parse(d))
  .handler(async ({ data }) => {
    const { verifyInitData } = await import("./telegram.server");
    const { getSettings } = await import("./core.server");
    const { user } = verifyInitData(data.initData);
    if (data.chain === "ton") {
      const s = await getSettings();
      return { address: String(s.ton_address), memoPrefix: String(s.memo_prefix ?? "") };
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { evmAddressFor } = await import("./wallet.server");
    const { data: u } = await supabaseAdmin.from("users").select("wallet_index").eq("tg_user_id", user.id).single();
    if (!u) throw new Error("Account not found");
    const address = evmAddressFor(u.wallet_index);
    return { address, memoPrefix: "" };
  });

export const claimProfit = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.parse(d))
  .handler(async ({ data }) => {
    const { verifyInitData } = await import("./telegram.server");
    const { getSettings, pendingYield, applyBalance } = await import("./core.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { user } = verifyInitData(data.initData);
    const { data: me } = await supabaseAdmin.from("users").select("*").eq("tg_user_id", user.id).single();
    if (!me || me.is_banned) throw new Error("Account restricted");
    const s = await getSettings();
    const amount = Math.floor(pendingYield(Number(me.coin_balance), me.last_yield_at, Number(s.daily_yield_pct)) * 1e6) / 1e6;
    const minimum = Number(s.min_claim_usdt ?? 0.01);
    if (amount < minimum) throw new Error(`Minimum claim is ${minimum} USDT`);
    const { data: upd } = await supabaseAdmin.from("users").update({ last_yield_at: new Date().toISOString() })
      .eq("tg_user_id", user.id).eq("last_yield_at", me.last_yield_at).select("tg_user_id");
    if (!upd?.length) throw new Error("Please try again");
    await applyBalance(user.id, "yield_claim", 0, amount, "Estimated daily profit claim");
    const { notify } = await import("./telegram.server");
    await notify(user.id, `💰 <b>Profit claimed</b>\n+${amount.toFixed(6)} USDT added to your balance.`);
    return { amount };
  });

export const openGift = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.parse(d))
  .handler(async ({ data }) => {
    const { verifyInitData } = await import("./telegram.server");
    const { getSettings, applyBalance } = await import("./core.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { user } = verifyInitData(data.initData);
    const { data: me } = await supabaseAdmin.from("users").select("is_banned,last_gift_at,gift_boxes").eq("tg_user_id", user.id).single();
    if (!me || me.is_banned) throw new Error("Account restricted");
    if (!me.last_gift_at) {
      const { data: upd } = await supabaseAdmin.from("users").update({ last_gift_at: new Date().toISOString() })
        .eq("tg_user_id", user.id).is("last_gift_at", null).select("tg_user_id");
      if (!upd?.length) throw new Error("You have already opened your gift");
    } else {
      const boxes = Number(me.gift_boxes ?? 0);
      if (boxes <= 0) throw new Error("No gift boxes left — invite friends to earn more");
      const { data: upd } = await supabaseAdmin.from("users").update({ gift_boxes: boxes - 1 })
        .eq("tg_user_id", user.id).eq("gift_boxes", boxes).select("tg_user_id");
      if (!upd?.length) throw new Error("No gift boxes left — invite friends to earn more");
    }
    const s = await getSettings();
    const min = Math.ceil(Number(s.gift_min)), max = Math.floor(Number(s.gift_max));
    const coins = min + Math.floor(Math.random() * (max - min + 1));
    await applyBalance(user.id, "gift", coins, 0, "Gift");
    return { coins };
  });

export const getPrices = createServerFn({ method: "GET" }).handler(async () => {
  const { prices } = await import("./deposits.server");
  return prices();
});

export const checkDeposit = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.parse(d))
  .handler(async ({ data }) => {
    const { verifyInitData } = await import("./telegram.server");
    const { scanUser } = await import("./deposits.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { user } = verifyInitData(data.initData);
    const { USER_SCAN_COLS } = await import("./deposits.server");
    const { data: u } = await supabaseAdmin.from("users").select(USER_SCAN_COLS).eq("tg_user_id", user.id).single();
    if (!u || u.is_banned) throw new Error("Account restricted");
    const { getSettings } = await import("./core.server");
    const all = await scanUser(u);
    const below = all.filter((c) => "below" in c && c.below);
    const credited = all.filter((c) => !("below" in c && c.below) && c.coins > 0);
    const s = await getSettings();
    return {
      credited: credited.map((c) => ({ chain: c.chain, asset: c.asset, amount: c.amount, usd: c.usd, coins: c.coins })),
      belowMinimum: below.map((c) => ({ asset: c.asset, amount: c.amount, usd: c.usd })),
      minDeposit: Number(s.min_deposit_usd),
    };
  });

export const requestWithdrawal = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.extend({
    chain: z.string().max(20), asset: z.string().max(10),
    address: z.string().trim().min(10).max(120), amount: z.number().positive().max(1e9),
  }).parse(d))
  .handler(async ({ data }) => {
    const { verifyInitData } = await import("./telegram.server");
    const { getSettings, applyBalance } = await import("./core.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { WITHDRAW_OPTIONS, chainById } = await import("./assets");
    const { user } = verifyInitData(data.initData);
    const c = chainById(data.chain);
    if (!c || !WITHDRAW_OPTIONS.some((o) => o.chain === data.chain && o.asset === data.asset)) throw new Error("Only USDT BEP20 or USDT GRAM withdrawals are supported");
    const s = await getSettings();
    if (String(s.withdrawals_open ?? "on") === "off") throw new Error("Withdrawals are currently closed. Please try again later.");
    if (String((data.chain === "ton" ? s.withdraw_gram_open : s.withdraw_bep20_open) ?? "on") === "off") throw new Error("This withdrawal method is not available right now.");
    if (data.amount < Number(s.min_withdrawal_usdt)) throw new Error(`Minimum withdrawal is ${s.min_withdrawal_usdt} USDT`);
    const { data: me } = await supabaseAdmin.from("users").select("is_banned,usdt_frozen,usdt_balance,admin_frozen,total_deposit").eq("tg_user_id", user.id).single();
    if (!me || me.is_banned) throw new Error("Account restricted");
    const { data: last } = await supabaseAdmin.from("withdrawals").select("created_at").eq("user_id", user.id).neq("status", "rejected").order("created_at", { ascending: false }).limit(1).maybeSingle();
    if (last) {
      const next = new Date(last.created_at).getTime() + 86400000;
      if (next > Date.now()) {
        const h = Math.ceil((next - Date.now()) / 3600000);
        throw new Error(`You can withdraw once every 24 hours. Next withdrawal in about ${h} hour${h === 1 ? "" : "s"}.`);
      }
    }
    const available = Number(me.usdt_balance) - Number(me.admin_frozen);
    if (data.amount > available + 1e-9) throw new Error(`Only ${Math.max(0, available).toFixed(4)} USDT is available to withdraw`);
    if (Number(me.total_deposit) < Math.max(Number(s.min_deposit_usd) || 0, 1e-9)) {
      const cap = Number(s.free_withdrawal_cap ?? 0.25);
      const { data: wds } = await supabaseAdmin.from("withdrawals").select("amount").eq("user_id", user.id).neq("status", "rejected");
      const used = (wds ?? []).reduce((a, w) => a + Number(w.amount), 0);
      if (used + data.amount > cap + 1e-9)
        throw new Error(used >= cap ? `You have used your free withdrawal limit of $${cap}. Please make a deposit first to withdraw more.` : `Without a deposit you can withdraw up to $${cap} in total. Remaining: $${(cap - used).toFixed(4)}`);
    }
    const fee = s.withdrawal_fee_type === "percent" ? (data.amount * Number(s.withdrawal_fee_value)) / 100 : Number(s.withdrawal_fee_value);
    if (fee >= data.amount) throw new Error("Amount is too small to cover the fee");
    await applyBalance(user.id, "withdrawal_hold", 0, -data.amount, `${data.asset} ${c.name}`);
    const { data: w, error } = await supabaseAdmin.from("withdrawals").insert({
      user_id: user.id, chain: data.chain, asset: data.asset, address: data.address, amount: data.amount, fee,
    }).select("id").single();
    if (error) { await applyBalance(user.id, "withdrawal_refund", 0, data.amount, "Request failed"); throw new Error(error.message); }
    await supabaseAdmin.from("users").update({ usdt_frozen: Number(me.usdt_frozen) + data.amount }).eq("tg_user_id", user.id);
    // Bot messages: confirm to the user, alert every admin. Never block the request on Telegram errors.
    try {
      const { notify } = await import("./telegram.server");
      const esc = (v: string) => v.replace(/[&<>]/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[ch]!);
      const net = data.chain === "ton" ? "GRAM" : "BEP20 (BSC)";
      const net_amt = Math.round((data.amount - fee) * 1e6) / 1e6;
      await notify(user.id, `🕒 <b>Withdrawal request submitted</b>\n💰 Amount: <b>${data.amount} USDT</b>${fee ? ` (fee ${fee}, you receive ${net_amt})` : ""}\n🔗 Network: ${net}\n📬 To: <code>${esc(data.address)}</code>\n\nIt will be reviewed shortly. You will get a message when it is processed.`);
      const who = user.username ? `@${esc(user.username)}` : esc(String(user.first_name ?? "User"));
      const { alertAdminsNewWithdrawal } = await import("./payout.server");
      await alertAdminsNewWithdrawal({ id: w.id, user_id: user.id, chain: data.chain, amount: data.amount, fee, address: data.address }, who);
    } catch (e) { console.error("withdrawal notify", e); }
    return { id: w.id };
  });

export const getHistory = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.parse(d))
  .handler(async ({ data }) => {
    const { verifyInitData } = await import("./telegram.server");
    const { getSettings } = await import("./core.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { user } = verifyInitData(data.initData);
    const [wd, refs, s] = await Promise.all([
      supabaseAdmin.from("withdrawals").select("id,chain,asset,address,amount,fee,status,tx_hash,reject_reason,created_at").eq("user_id", user.id).order("created_at", { ascending: false }).limit(30),
      supabaseAdmin.from("referrals").select("referred_id,created_at").eq("referrer_id", user.id).order("created_at", { ascending: false }).limit(50),
      getSettings(),
    ]);
    const ids = (refs.data ?? []).map((r) => r.referred_id);
    const { data: names } = ids.length ? await supabaseAdmin.from("users").select("tg_user_id,name").in("tg_user_id", ids) : { data: [] };
    const reward = Number(s.referral_coins);
    return {
      withdrawals: wd.data ?? [],
      friends: (refs.data ?? []).map((r) => {
        const n = names?.find((x) => x.tg_user_id === r.referred_id);
        return { id: r.referred_id, name: n?.name ?? String(r.referred_id), photo: null, earned: reward, joined: r.created_at };
      }),
    };
  });

/** "@name", "name" or "https://t.me/name" → chat id + join link. */
function parseChannel(raw: string) {
  const v = raw.trim();
  if (/^-100\d+$/.test(v)) return { chatId: v, link: null as string | null };
  const name = v.replace(/^https?:\/\/(t\.me|telegram\.me)\//i, "").replace(/^@/, "").split(/[/?]/)[0] ?? "";
  return { chatId: `@${name}`, link: `https://t.me/${name}` };
}

export const verifyChannels = createServerFn({ method: "POST" })
  .inputValidator((d) => auth.parse(d))
  .handler(async ({ data }) => {
    const { verifyInitData, tgApi } = await import("./telegram.server");
    const { getSettings } = await import("./core.server");
    const { user } = verifyInitData(data.initData);
    const s = await getSettings();
    const list = [s.join_channel, s.join_payment_channel].map((c) => String(c ?? "").trim()).filter(Boolean);
    const results = await Promise.all(list.map(async (raw) => {
      try {
        const m = (await tgApi("getChatMember", { chat_id: parseChannel(raw).chatId, user_id: user.id })) as { status?: string };
        return { channel: raw, joined: ["creator", "administrator", "member", "restricted"].includes(String(m.status)) };
      } catch (e) {
        console.error("getChatMember failed (is the bot an admin of the channel?)", raw, e);
        return { channel: raw, joined: false };
      }
    }));
    return { ok: results.every((r) => r.joined), results };
  });
