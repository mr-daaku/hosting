import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getMe } from "./app.functions";

/** Telegram user id straight from the Telegram app (no server call). */
export function tgUserId(): number | null {
  const id = window.Telegram?.WebApp?.initDataUnsafe?.user?.id;
  return typeof id === "number" ? id : null;
}
import { applyLanguage } from "./i18n";

declare global {
  interface Window {
    Telegram?: { WebApp?: any };
  }
}

type Ctx = { initData: string; status: "loading" | "ready" | "outside" | "error"; error?: string };
const TgCtx = createContext<Ctx>({ initData: "", status: "loading" });

const ME_CACHE = "omini-me-cache";
type MeData = Awaited<ReturnType<typeof getMe>>;

/** Last-known home data from this phone (shown instantly on open, then refreshed). */
function readMeCache(userId: number | null): MeData | undefined {
  try {
    const raw = localStorage.getItem(ME_CACHE);
    if (!raw || userId == null) return undefined;
    const c = JSON.parse(raw) as { id: number; data: MeData };
    return c.id === userId ? c.data : undefined;
  } catch { return undefined; }
}
function writeMeCache(data: MeData) {
  try { localStorage.setItem(ME_CACHE, JSON.stringify({ id: data.me.id, data })); } catch { /* storage full/blocked */ }
}

export function TgProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<Ctx>({ initData: "", status: "loading" });
  const qc = useQueryClient();

  useEffect(() => {
    let cancelled = false;
    let tries = 0;
    const start = async () => {
      const wa = window.Telegram?.WebApp;
      if (!wa && tries++ < 20) return void setTimeout(start, 150);
      const initData: string = wa?.initData ?? "";
      if (!initData) return setState({ initData: "", status: "outside" });
      try {
        wa.ready?.();
        wa.expand?.();
        const mobile = ["android", "ios"].includes(String(wa.platform));
        if (mobile && typeof wa.requestFullscreen === "function" && wa.isVersionAtLeast?.("8.0")) wa.requestFullscreen();
        wa.disableVerticalSwipes?.();
        wa.setHeaderColor?.("#1a2140");
        wa.setBackgroundColor?.("#1a2140");
      } catch { /* older clients: expand() already applied */ }
      // Show last session's data at once (marked stale so it refreshes in the background).
      const cached = readMeCache(tgUserId());
      if (cached && !qc.getQueryData(["me"])) qc.setQueryData(["me"], cached, { updatedAt: 0 });
      // Account setup happens inside the first getMe request (one round trip on open).
      if (!cancelled) setState({ initData, status: "ready" });
    };
    start();
    return () => { cancelled = true; };
  }, [qc]);

  return <TgCtx.Provider value={state}>{children}</TgCtx.Provider>;
}

export const useTg = () => useContext(TgCtx);

export function useMe(opts: { live?: boolean } = {}) {
  const { initData, status } = useTg();
  return useQuery({
    queryKey: ["me"],
    queryFn: async () => {
      const d = await getMe({ data: { initData } });
      writeMeCache(d);
      return d;
    },
    enabled: status === "ready",
    staleTime: 30_000,
    // Poll only where live numbers matter; nothing polls by default.
    refetchInterval: opts.live ? 60_000 : false,
  });
}

export function useRefreshMe() {
  const qc = useQueryClient();
  return () => qc.invalidateQueries({ queryKey: ["me"] });
}

export function haptic(kind: "success" | "error" | "light" = "light") {
  const h = window.Telegram?.WebApp?.HapticFeedback;
  if (!h) return;
  if (kind === "light") h.impactOccurred?.("light");
  else h.notificationOccurred?.(kind);
}

export function openLink(url: string) {
  const wa = window.Telegram?.WebApp;
  if (url.startsWith("https://t.me/") && wa?.openTelegramLink) wa.openTelegramLink(url);
  else if (wa?.openLink) wa.openLink(url);
  else window.open(url, "_blank");
}

export type Theme = "dark" | "light";
export function useTheme(): [Theme, (t: Theme) => void] {
  const [theme, setTheme] = useState<Theme>("dark");
  useEffect(() => {
    const t = (localStorage.getItem("omini-theme") as Theme) || "dark";
    setTheme(t);
  }, []);
  const set = (t: Theme) => {
    setTheme(t);
    localStorage.setItem("omini-theme", t);
    document.documentElement.classList.toggle("light", t === "light");
  };
  return [theme, set];
}

/** Apply the saved theme once on load. */
export function useApplyTheme() {
  useEffect(() => {
    document.documentElement.classList.toggle("light", localStorage.getItem("omini-theme") === "light");
    applyLanguage(localStorage.getItem("omini-language") || "en");
  }, []);
}
