import { HDNodeWallet, Interface, getAddress, isAddress, parseUnits, formatUnits } from "ethers";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { applyBalance, getSettings } from "./core.server";
import { notify, postToChannel, tgApi } from "./telegram.server";

// Same method as the autopay-bsc bot: index-0 wallet from PAY_WALLET_SECRET, legacy tx on BSC.
const CHAIN_ID = 56;
const USDT = "0x55d398326f99059ff775485246999027b3197955";
const RPCS = ["https://bsc-dataseed.binance.org/", "https://bsc-rpc.publicnode.com", "https://bsc-dataseed1.binance.org/"];
const IFACE = new Interface(["function balanceOf(address owner) view returns (uint256)", "function transfer(address to, uint256 amount) returns (bool)"]);
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const esc = (v: string) => v.replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[c]!);

async function rpc(method: string, params: unknown[]): Promise<any> {
  let last: unknown;
  for (const url of RPCS) {
    try {
      const res = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }) });
      if (!res.ok) throw new Error(`http ${res.status}`);
      const j = (await res.json()) as { result?: unknown; error?: { message?: string } };
      if (j.error) throw new Error(j.error.message || "rpc error");
      return j.result;
    } catch (e) { last = e; }
  }
  throw last instanceof Error ? last : new Error("BSC RPC failed");
}

function payWallet() {
  const phrase = (process.env["PAY_WALLET_SECRET"] || "").trim();
  if (phrase.split(/\s+/).length < 12) throw new Error("Payout wallet is not configured");
  return HDNodeWallet.fromPhrase(phrase, undefined, "m/44'/60'/0'/0/0");
}

/** Sends USDT (BEP20) and waits for the receipt. Returns the tx hash. */
export async function sendUsdtBep20(to: string, amount: number): Promise<string> {
  if (!isAddress(to)) throw new Error("Invalid BEP20 address");
  const wallet = payWallet();
  const value = parseUnits(amount.toFixed(6), 18);
  if (value <= 0n) throw new Error("Amount is zero");
  const bal = BigInt(await rpc("eth_call", [{ to: USDT, data: IFACE.encodeFunctionData("balanceOf", [wallet.address]) }, "latest"]));
  if (bal < value) throw new Error(`Payout wallet low: ${formatUnits(bal, 18)} USDT, need ${amount}`);
  const bnb = BigInt(await rpc("eth_getBalance", [wallet.address, "latest"]));
  if (bnb === 0n) throw new Error("Payout wallet has no BNB for gas");
  const data = IFACE.encodeFunctionData("transfer", [getAddress(to), value]);
  const [nonceHex, gasPriceHex] = await Promise.all([rpc("eth_getTransactionCount", [wallet.address, "pending"]), rpc("eth_gasPrice", [])]);
  let gasLimit = 100000n;
  try { gasLimit = (BigInt(await rpc("eth_estimateGas", [{ from: wallet.address, to: USDT, data }])) * 12n) / 10n; } catch { /* default */ }
  const raw = await wallet.signTransaction({ type: 0, chainId: CHAIN_ID, to: USDT, nonce: Number(BigInt(nonceHex)), gasPrice: BigInt(gasPriceHex), gasLimit, data });
  const hash: string = await rpc("eth_sendRawTransaction", [raw]);
  for (let i = 0; i < 10; i++) {
    await sleep(3000);
    const r = await rpc("eth_getTransactionReceipt", [hash]).catch(() => null);
    if (r) { if (r.status !== "0x1") throw new Error(`Transaction reverted: ${hash}`); return hash; }
  }
  return hash; // broadcast, confirmation still pending — hash is on BscScan
}

export async function adminIds() {
  const { data } = await supabaseAdmin.from("admins").select("tg_user_id");
  const env = (process.env["ADMIN_TG_ID"] || "").split(/[,\s]+/).filter(Boolean).map(Number);
  return [...new Set([...env, ...(data ?? []).map((a) => Number(a.tg_user_id))])].filter((x) => x > 0);
}

/** Bot message to every admin with Paid / Reject buttons. */
export async function alertAdminsNewWithdrawal(w: { id: string; user_id: number; chain: string; amount: number; fee: number; address: string }, _who?: string) {
  const bep = w.chain !== "ton";
  const [{ data: u }, { count: times }] = await Promise.all([
    supabaseAdmin.from("users").select("total_deposit,total_withdrawal").eq("tg_user_id", w.user_id).maybeSingle(),
    supabaseAdmin.from("withdrawals").select("id", { count: "exact", head: true }).eq("user_id", w.user_id).eq("status", "paid"),
  ]);
  const text = `🔔 <b>New withdrawal request</b>\n🆔 User ID: <code>${w.user_id}</code>\n💰 Amount: <b>${w.amount} USDT</b>\n🔗 Method: ${bep ? "USDT BEP20 (BSC)" : "USDT GRAM"}\n📬 Address: <code>${esc(w.address)}</code>\n\n🔁 Total times withdrawn: ${times ?? 0}\n⬆️ Total withdraw: ${Number(u?.total_withdrawal ?? 0)} USDT\n⬇️ Total deposit: $${Number(u?.total_deposit ?? 0)}`;
  const kb = { inline_keyboard: [[{ text: "✅ Paid", callback_data: `wd:pay:${w.id}` }], [{ text: "❌ Reject", callback_data: `wd:rej:${w.id}` }, { text: "↩️ Reject + refund", callback_data: `wd:rejr:${w.id}` }]] };
  for (const id of await adminIds()) {
    try { await tgApi("sendMessage", { chat_id: id, text, parse_mode: "HTML", reply_markup: kb }); } catch (e) { console.error("admin alert", id, e); }
  }
}

/**
 * Single path for paying/rejecting a withdrawal (admin panel and bot buttons).
 * Locks the row pending → processing so it can never be paid twice.
 */
export async function reviewWithdrawal(opts: { id: string; action: "pay" | "reject"; adminId: number; txHash?: string | undefined; reason?: string | undefined; refund?: boolean | undefined; auto?: boolean | undefined }) {
  const db = supabaseAdmin;
  const { data: w, error: lockErr } = await db.from("withdrawals").update({ status: "processing", reviewed_by: opts.adminId }).eq("id", opts.id).eq("status", "pending").select("*").maybeSingle();
  if (lockErr) throw new Error(`Lock failed: ${lockErr.message}`);
  if (!w) throw new Error("Already reviewed");
  const amt = Number(w.amount);
  let tx = opts.txHash?.trim() || "";
  // Auto send only when the Auto pay button asked for it.
  if (opts.action === "pay" && !tx && opts.auto === true) {
    try {
      const net = Math.max(0, amt - Number(w.fee));
      if (w.chain === "ton") { const { sendUsdtTon } = await import("./tonpay.server"); tx = await sendUsdtTon(w.address, net); }
      else tx = await sendUsdtBep20(w.address, net);
    }
    catch (e) { await db.from("withdrawals").update({ status: "pending" }).eq("id", w.id); throw e; }
  }
  await db.from("withdrawals").update({
    status: opts.action === "pay" ? "paid" : "rejected", tx_hash: tx || null, reject_reason: opts.reason || null,
    refunded: opts.action === "reject" && !!opts.refund, reviewed_at: new Date().toISOString(),
  }).eq("id", w.id);
  const { data: u } = await db.from("users").select("usdt_frozen,total_withdrawal,name").eq("tg_user_id", w.user_id).single();
  await db.from("users").update({
    usdt_frozen: Math.max(0, Number(u?.usdt_frozen ?? 0) - amt),
    ...(opts.action === "pay" ? { total_withdrawal: Number(u?.total_withdrawal ?? 0) + amt } : {}),
  }).eq("tg_user_id", w.user_id);
  if (opts.action === "reject" && opts.refund) await applyBalance(w.user_id, "withdrawal_refund", 0, amt, opts.reason || "Rejected", w.id);

  const ton = w.chain === "ton";
  const txLink = tx ? (ton ? `https://tonscan.org/tx/${encodeURIComponent(tx)}` : `https://bscscan.com/tx/${encodeURIComponent(tx)}`) : "";
  if (opts.action === "pay") {
    await notify(w.user_id, `✅ <b>Withdrawal paid</b>\n${amt} USDT sent to your ${ton ? "GRAM" : "BEP20"} address.${tx ? `\n🧾 Tx: <a href="${txLink}"><code>${esc(tx)}</code></a>` : ""}`);
    const s = await getSettings();
    const id = String(w.user_id);
    const maskedId = id.length > 4 ? `${id.slice(0, 2)}${"•".repeat(id.length - 4)}${id.slice(-2)}` : "••••";
    const nm = String(u?.name ?? "User").trim();
    const maskedName = nm.length > 2 ? `${nm.slice(0, 2)}${"•".repeat(Math.min(4, nm.length - 2))}` : `${nm}••`;
    const proof = txLink || (ton ? "https://tonscan.org/address/UQClwv5NDfVBCgKvI3ngXTFR3KDClEIMtYGfv04AM9YZhiUz" : "https://bscscan.com/address/0x1f20eb36a47f0db1a6356ae70ad24b8bcffd4167");
    await postToChannel(s.join_payment_channel,
      `💸 <b>Withdrawal Paid</b>\n\n👤 User: ${esc(maskedName)} (ID ${maskedId})\n💰 Amount: <b>${amt} USDT</b>\n🔗 Network: ${ton ? "GRAM" : "BEP20 (BSC)"}\n🧾 Tx: ${esc(proof)}\n\n✅ Paid by OminiAi`);
  } else {
    await notify(w.user_id, `❌ <b>Withdrawal rejected</b>\n${amt} USDT${opts.reason ? ` — ${esc(opts.reason)}` : ""}.${opts.refund ? " The amount was returned to your balance." : ""}`);
  }
  return { ok: true, txHash: tx || null, amount: amt, chain: w.chain, userId: w.user_id };
}
